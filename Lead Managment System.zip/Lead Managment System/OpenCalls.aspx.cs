﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

public partial class OpenCalls : System.Web.UI.Page
{
	protected void Page_PreInit(Object sender, EventArgs e)
	{
		ClsProj.GetMasterPage(this);

	}
    protected void Page_Load(object sender, EventArgs e)
    {

		if (!Page.IsPostBack)
		{
			if (Session["UserID"] != null)
			{
				if (Session["UserType"] != null)
				{
					ShowUpcomingCall();
				}
			}

			//DropDownList ddlLeadStatus = null;
			//ClsLead.BindLeadStatus(ddlLeadStatus);
		}
	}


	public void ShowUpcomingCall()
	{
		int intuser = clsPrecaution.GetInt_Zero(Session["UserID"].ToString());
		int intusertype = clsPrecaution.GetInt_Zero(Session["UserType"].ToString());

		string strquery = "";


		tbl_Lead objfollow = new tbl_Lead();
		objfollow.WhereClause = "UserID=" + intuser + "and ( LStatusID = 1 or LStatusID=2 or LStatusID=3 or LStatusID=6 ) and IsDelete = 0";
		DataTable dtbl = objfollow.Select();
		Gridview1.DataSource = dtbl;
		Gridview1.DataBind();
		//ClsLead.SelectAllLead(GridView1);
	}

	protected void Gridview1_RowDataBound(object sender, GridViewRowEventArgs e)
	{
		if (e.Row.RowType == DataControlRowType.DataRow)
		{
			tbl_LeadStatus objLeadstatus = new tbl_LeadStatus();
			DataTable dtbl = objLeadstatus.Select();

			if (dtbl.Rows.Count > 0)
			{
				DropDownList ddlLeadStatus = (DropDownList)e.Row.FindControl("ddlLeadStatus");
				HiddenField hdnval = (HiddenField)e.Row.FindControl("hdnprice");  // this is statusid

				ddlLeadStatus.DataSource = dtbl;
				ddlLeadStatus.DataTextField = "StatusName";
				ddlLeadStatus.DataValueField = "LStatusID";
				ddlLeadStatus.DataBind();
				ddlLeadStatus.Items.Insert(0, "Select Status");
				if (hdnval.Value != "0")
				{
					ddlLeadStatus.Items.FindByValue(hdnval.Value).Selected = true;
				}
			}
		}

	}

	protected void ddlLeadStatus_SelectedIndexChanged(object sender, EventArgs e)
	{
		DropDownList ddlSellist = (DropDownList)sender;
		GridViewRow gvrow = (GridViewRow)ddlSellist.NamingContainer;
		int index = gvrow.RowIndex;
		Label lblLeadID = (Label)Gridview1.Rows[index].FindControl("lblLeadId");

		int sid = clsPrecaution.GetInt_Zero(ddlSellist.SelectedItem.Value);
		string strleadname = clsPrecaution.GetStr_Empty(ddlSellist.SelectedItem.Text);
		if (sid == 7)
		{
			Response.Redirect("AddCallBack.aspx?ld=" + lblLeadID.Text + "&ls=" + sid + "&sn=" + strleadname);
		}
		else if (sid == 8)
		{
			Response.Redirect("AddAppointment.aspx?ld=" + lblLeadID.Text + "&ls=" + sid + "&sn=" + strleadname);
		}
		else
		{
			Response.Redirect("AddActivityCalls.aspx?ld=" + lblLeadID.Text + "&ls=" + sid + "&sn=" + strleadname);
		}
	}

	private void BindGrid()
	{
		string strWhere = "";

		if (txtUserName.Text.Length > 1)                           //Search Textbox
		{
			strWhere += " AND UserName like '%" + txtUserName.Text + "%'";
		}

		if (txtLeadName.Text.Length > 1)                           //Search Textbox
		{
			strWhere += " AND LeadName like '%" + txtLeadName.Text + "%'";
		}

		if (txtEmail1.Text.Length > 1)                           //Search Textbox
		{
			strWhere += " AND Email1 like '%" + txtEmail1.Text + "%'";
		}

		if (txtLastCallDate.Text.Length > 1)                           //Search Textbox
		{
			strWhere += " AND LastCallDate like '%" + txtLastCallDate.Text + "%'";
		}

		if (txtLastCallTime.Text.Length > 1)                           //Search Textbox
		{
			strWhere += " AND LastCallTime like '%" + txtLastCallTime.Text + "%'";
		}

		if (txtNextCallTime.Text.Length > 1)                           //Search Textbox
		{
			strWhere += " AND NextCallTime like '%" + txtNextCallTime.Text + "%'";
		}

		if (txtSource.Text.Length > 1)                           //Search Textbox
		{
			strWhere += " AND Source like '%" + txtSource.Text + "%'";
		}

		string strQuery = "select * from tbl_Lead where 1=1" + strWhere;

		DataTable dt = new DataTable();

		dt = ClsProj.GetCondata(strQuery);

		Gridview1.DataSource = dt;
		Gridview1.DataBind();


	}



	protected void btnSearch_Click(object sender, EventArgs e)
	{
		BindGrid();
	}

	protected void btnEdit_Click(object sender, EventArgs e)
	{
		LinkButton objlknbtn = (LinkButton)sender;
		int ID = Convert.ToInt32(objlknbtn.CommandArgument);
		Response.Redirect("AddCalls.aspx?LeadID=" + ID);
	}

	protected void btnDelete_Click(object sender, EventArgs e)
	{
		LinkButton lnkbtn = (LinkButton)sender;
		int ID = Convert.ToInt32(lnkbtn.CommandArgument);
		Hashtable hstbl = new Hashtable();
		hstbl.Add("IsDelete", 1);
		tbl_Lead objlead = new tbl_Lead();
		objlead.Data = hstbl;
		objlead.WhereClause = "LeadID=" + ID;
		objlead.Update();
		if (Session["UserID"] != null)
		{
			if (Session["UserType"] != null)
			{
				ShowUpcomingCall();
			}
		}
	}

	protected void Gridview1_PageIndexChanging(object sender, GridViewPageEventArgs e)
	{
		Gridview1.PageIndex = e.NewPageIndex;
		ShowUpcomingCall();
	}
}
