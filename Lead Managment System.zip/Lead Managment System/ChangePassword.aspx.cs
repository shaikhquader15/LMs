﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing.Text;

public partial class ChangePassword : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			if (Session["UserID"] != null)
			{
				EditProfile();
			}
		}
	}


	public void EditProfile()
	{
		int UserID = clsPrecaution.GetInt_Zero(Session["UserID"].ToString());

		tbl_User obj = new tbl_User();
		obj.WhereClause = "UserID=" + UserID;
		DataTable dtbl = obj.Select();
		if (dtbl.Rows.Count > 0)
		{
			//txtfname.Text = clsPrecaution.GetStr_Null(dtbl.Rows[0]["FirstName"]);
			//txtlname.Text = clsPrecaution.GetStr_Null(dtbl.Rows[0]["LastName"]);
			//txtusername.Text = clsPrecaution.GetStr_Null(dtbl.Rows[0]["UserName"]);
			//txtemail.Text = clsPrecaution.GetStr_Null(dtbl.Rows[0]["EmailAddress"]);
			txtoldpswd.Text = clsPrecaution.GetStr_Null(dtbl.Rows[0]["Password"]);
			//txtconpass.Text = clsPrecaution.GetStr_Null(dtbl.Rows[0]["Password"]);
			//txtaddress.Text = clsPrecaution.GetStr_Null(dtbl.Rows[0]["Address"]);
			//txtcontact.Text = clsPrecaution.GetStr_Null(dtbl.Rows[0]["Contact"]);
			txtpass.Text = string.Empty;
			txtconpass.Text = string.Empty;


		}
	}







	protected void btnupdate_Click(object sender, EventArgs e)
	{
		string message = "";
		int UserID = clsPrecaution.GetInt_Zero(Session["UserID"].ToString());
		string strpswd = clsPrecaution.GetStr_Empty(txtpass.Text);
		string strcompswd = clsPrecaution.GetStr_Empty(txtconpass.Text);
		if (strpswd == strcompswd)
		{
			Hashtable hstbl = new Hashtable();
			hstbl.Add("Password", strpswd);

			tbl_User objuser = new tbl_User();
			objuser.Data = hstbl;
			objuser.WhereClause = "UserID=" + UserID;
			objuser.Update();
			lblmsg.ForeColor = System.Drawing.Color.Green;
			//lblmsg.Text = "Password Updated Successfully";


			message = "Password Updated Successfully";
			
		}
		else
		{
			lblmsg.ForeColor = System.Drawing.Color.Red;
			//lblmsg.Text = "Password does not Match";

			message = "Password does not Match";

		}
		ShowMessage(message);
		

		EditProfile();
	}


	public void ShowMessage(String message)
	{
		System.Text.StringBuilder sb = new System.Text.StringBuilder();

		sb.Append("<script type = 'text/javascript'>");

		sb.Append("window.onload=function(){");

		sb.Append("alert('");

		sb.Append(message);

		sb.Append("')};");

		sb.Append("</script>");

		ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
	}

}