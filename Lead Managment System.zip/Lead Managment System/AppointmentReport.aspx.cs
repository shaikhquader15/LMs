﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AppointmentReport : System.Web.UI.Page
{
	protected void Page_PreInit(Object sender, EventArgs e)
	{
		ClsProj.GetMasterPage(this);

	}
	protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Session["UserID"] != null)
            {
                if (Session["UserType"] != null)
                {
                    if (Session["UserName"] != null)
                    {
                        bindReport();
                        bindGridReport();
                       
                    }
                }
            }
        }
    }

    public void bindReport()
    {
        tbl_SalesTeam objLead = new tbl_SalesTeam();
        DataTable dtbl1 = objLead.Select();
        ddlCalling.DataSource = dtbl1;
        ddlCalling.DataTextField = "SUserName";
        ddlCalling.DataValueField = "SUserID";
        ddlCalling.DataBind();
        ddlCalling.Items.Insert(0, "Select UserName");
    }

    public void bindGridReport()
    {
        tbl_SalesTeam obj = new tbl_SalesTeam();
        DataTable dtrep = obj.Select();
        Gridview_s.DataSource = dtrep;
        Gridview_s.DataBind();
    }

    private void Search()
    {
        string strWhere = "";
        if (ddlCalling.SelectedIndex > 0)
        {

            strWhere += " AND SUserID=" + ddlCalling.SelectedValue;
        }

        //if (ddlStatus.SelectedIndex > 0)
        //{
        //    strWhere += " AND LStatusID= " + ddlStatus.SelectedValue;
        //}

        //if (ddlSource.SelectedIndex > 0)
        //{
        //    strWhere += " AND SourceID= " + ddlSource.SelectedValue;
        //}


        strWhere += " AND CallDate between '" + txtSD.Text + "' AND '" + txtED.Text + "'";



        string strQuery = "select * from tbl_SalesTeam where 1=1" + strWhere;

        DataTable dt = new DataTable();

        dt = ClsProj.GetCondata(strQuery);

        Gridview_s.DataSource = dt;
        Gridview_s.DataBind();
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Search();
    }
}