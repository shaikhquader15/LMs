﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddLeadStaus : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			EditLeadStatus();
			BindStatus();
		}
	}




	protected void btnsave_Click(object sender, EventArgs e)
	{
		string strlead = clsPrecaution.GetStr_Empty(txtleadname.Text);
		int ddlstatusid = clsPrecaution.GetInt_Zero(ddlStatus.SelectedValue);



		if (btnsave.Text == "Save")
			{
				ClsLeadStatus.AddLeadStatus(strlead, ddlstatusid);
				Response.Redirect("LeadMaster.aspx");
			}
			else
			{
				if (Request.QueryString["LStatusID"] != null)
				{
					int LstatusID = clsPrecaution.GetInt_Zero(Request.QueryString["LStatusID"]);
					ClsLeadStatus.UpdateLeadStatus(LstatusID, strlead, ddlstatusid);
					Response.Redirect("LeadMaster.aspx");
				}
			}
		

		
	}

	public void EditLeadStatus()
	{
		tbl_LeadStatus objedit = new tbl_LeadStatus();
		int LstatusID = clsPrecaution.GetInt_Zero(Request.QueryString["LStatusID"]);
		objedit.WhereClause = "LStatusID=" + LstatusID;
		DataTable dtlead = objedit.Select();


		if (dtlead.Rows.Count > 0)
		{
			txtleadname.Text = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["StatusName"]);
			ddlStatus.SelectedIndex = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["StatusID"]);
			
			btnsave.Text = "Update";


		}
	}

	public void BindStatus()
	{
		tbl_Status objstatus = new tbl_Status();
		DataTable dt = objstatus.Select();
		ddlStatus.DataSource = dt;
		ddlStatus.DataTextField = "StatusName";
		ddlStatus.DataValueField = "StatusID";
		ddlStatus.DataBind();
		ddlStatus.Items.Insert(0, "Select Status");
		ddlStatus.SelectedIndex = 0;
	}
}

