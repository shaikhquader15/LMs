$(document).ready(function () {
    if ($(window).width() > 979) {
        if ($('body').hasClass('sidebar_hidden')) {
            $('.sidebar_button').toggleClass('sidebar_button_right sidebar_button_left');

        }
    } else {
        $('body').addClass('sidebar_hidden');

        $('.sidebar_button').removeClass('sidebar_button_right').addClass('sidebar_button_left');
    }

    var i = 0;

    function runEffect() {
        var options = {};
        if (i === 0) {
            i = 1;

            $(".sidebar").animate({marginLeft: "-242px"});
            $("#maincontainer").animate({marginLeft: "0px"});
        }
        else {
            i = 0;
            $(".sidebar").animate({marginLeft: "0px"});
            $("#maincontainer").animate({marginLeft: "242px"});
        }
    }

    $(".sidebar_button").click(function () {
        $('.sidebar_button').removeClass('sidebar_button_right sidebar_button_left');
        if (i === 0) {

            $('.sidebar_button').addClass('sidebar_button_left');

        }
        else {
            $('.sidebar_button').addClass('sidebar_button_right');


        }
        runEffect();
        return false;
    });

    $('.sidebar .accordion-toggle').click(function (e) {
        e.preventDefault()
    });
    /* Scroll to Top
     =========================
     */
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.scrollup').fadeIn();
        } else {
            $('.scrollup').fadeOut();
        }
    });

    $('.scrollup').click(function () {
        $("html, body").animate({ scrollTop: 0 }, 600);
        return false;
    });

});