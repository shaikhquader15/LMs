﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DashboardSE : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			if (Session["UserID"] != null)
			{
				//GetRecord();
				//ShowUpcomingCall();
				int UserID = clsPrecaution.GetInt_Zero(Session["UserID"]);

				int intnewsales = ClsProj.GetDataValue("tbl_SalesTeam", "SUserID=" + UserID + " and ( SstatusID = 4)");
				lblNewsales.Text = Convert.ToString(intnewsales);
				Session["TotalNewSalesCalls"] = Convert.ToString(intnewsales);

				int intUpcomingCalls = ClsProj.GetDataValue("tbl_SalesTeam", "SUserID=" + UserID + " and ( SstatusID = 1)"); 
				lblTotalCalls.Text = Convert.ToString(intUpcomingCalls);
				Session["TotalFolowCalls"] = Convert.ToString(intUpcomingCalls);


				int intFollowCalls = ClsProj.GetDataValue("tbl_SalesTeam", "SUserID=" + UserID + " and ( SstatusID = 2)");
				lblFollow.Text = Convert.ToString(intFollowCalls);
				Session["TotatNotInterestedCalls"] = Convert.ToString(intFollowCalls);

				int intPendingCalls = ClsProj.GetDataValue("tbl_SalesTeam", "SUserID=" + UserID + " and ( SstatusID = 3)");
				lblPending.Text = Convert.ToString(intPendingCalls);
				Session["TotalPosponedCalls"] = Convert.ToString(intPendingCalls);

				int intconverted = ClsProj.GetDataValue("tbl_SalesTeam", "SUserID=" + UserID + " and ( SstatusID = 5)");
				lblconverted.Text = Convert.ToString(intconverted);
				Session["TotalConvertedCalls"] = Convert.ToString(intconverted);

				//int intOpenCalls = ClsProj.GetDataValue("tbl_Lead", "UserID=" + UserID + " and ( LStatusID=1 or LStatusID=2 or LStatusID=3 or LStatusID=6 )");
				//lblOpen.Text = Convert.ToString(intOpenCalls);

				//int intInvalidCalls = ClsProj.GetDataValue("tbl_Lead", "UserID=" + UserID + " and (LStatusID =4 or LStatusID=5 or LStatusID=9 or LStatusID=10)");
				//lblInvalid.Text = Convert.ToString(intInvalidCalls);

				//int intConvertedCalls = ClsProj.GetDataValue("tbl_Lead", "UserID=" + UserID + " and (LStatusID = 8)");
				//lblConverted.Text = Convert.ToString(intConvertedCalls);

				ShowFollowUpCall();
			}
			if (Session["UserType"] != null)
			{
				if (Session["UserName"] != null)
				{
					lbluser.Text = Session["UserName"].ToString();
				}
				if (Session["LastLogin"] != null)
				{
					lbllogintime.Text = Session["LastLogin"].ToString();
				}
				if (Session["IPAddress"] != null)
				{
					lblip.Text = Session["IPAddress"].ToString();
				}

			}
		}
	}





	public void ShowUpcomingCall()
	{
		//string str = "";
		int UserID = clsPrecaution.GetInt_Zero(Session["UserID"]);
		//tbl_Lead seldata = new tbl_Lead();
		//seldata.OrderBy = "LeadID";
		//seldata.WhereClause = "LStatusID=1 or LStatusID=2 or LStatusID=3 or LStatusID=4 or LStatusID=5 or LStatusID=6 or LStatusID=7 or LStatusID=8 or LStatusID=9 or LStatusID=10";
		string strquery = @"select tbl_Lead.LeadID, tbl_Lead.SourceID,tbl_Lead.LStatusID,tbl_Lead.LeadName,tbl_Lead.Email1,tbl_Lead.Contact1,tbl_Source.SourceName From tbl_Lead
		inner Join tbl_Source on tbl_Lead.SourceID = tbl_Source.SourceID
		where tbl_Lead.LStatusID=0";

		DataTable dtbl = new DataTable();
		dtbl = ClsProj.GetCondata(strquery);

		//int intUpcomingCalls = ClsProj.GetDataValue("tbl_Lead","1");

		if (dtbl.Rows.Count > 0)
		{
			int lstatusid = clsPrecaution.GetInt_Zero(dtbl.Rows[0]["LStatusID"]);
			int result = ClsProj.TotalCalls(1, 1);
			//int result = dtbl.Rows.Count;
			lblTotalCalls.Text = clsPrecaution.GetStr_Null(result);
		}

		//int  result=clsPrecaution.TotalCalls(UserID, 1);
		//lblTotalCalls.Text =clsPrecaution.GetStr_Null(result);
		//lblTotalCalls.Text = labelA.Text + labelb.Text;
		//ClsLead.SelectAllLead(GridView1);
	}

	public void ShowFollowUpCall()
	{

		//string str = "";
		int UserID = clsPrecaution.GetInt_Zero(Session["UserID"]);
		//tbl_Lead seldata = new tbl_Lead();
		//seldata.OrderBy = "LeadID";
		//seldata.WhereClause = "LStatusID=1 or LStatusID=2 or LStatusID=3 or LStatusID=4 or LStatusID=5 or LStatusID=6 or LStatusID=7 or LStatusID=8 or LStatusID=9 or LStatusID=10";
		string strquery = "SELECT  * FROM tbl_Lead  WHERE LStatusID=7 and UserID=1 order by LStatusID ";

		DataTable dtbl = new DataTable();
		dtbl = ClsProj.GetCondata(strquery);
		if (dtbl.Rows.Count > 0)
		{
			int lstatusid = clsPrecaution.GetInt_Zero(dtbl.Rows[0]["LStatusID"]);
			//int result = clsPrecaution.TotalCalls(UserID, lstatusid);
			int result = dtbl.Rows.Count;
			lblFollow.Text = clsPrecaution.GetStr_Null(result);
		}

		//int  result=clsPrecaution.TotalCalls(UserID, 1);
		//lblTotalCalls.Text =clsPrecaution.GetStr_Null(result);
		//lblTotalCalls.Text = labelA.Text + labelb.Text;
		//ClsLead.SelectAllLead(GridView1);
	}
}