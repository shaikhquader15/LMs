﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

public partial class SalesLog : System.Web.UI.Page
{
	protected void Page_PreInit(Object sender, EventArgs e)
	{
		ClsProj.GetMasterPage(this);

	}
	protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            ShowLog();
			BindSaleStage();

		}
    }



    public void ShowLog()
    {
        int LeadID = clsPrecaution.GetInt_Zero(Request.QueryString["LeadID"]);

        tbl_SalesLog objSL = new tbl_SalesLog();
        objSL.WhereClause = "LeadID=" + LeadID;
        DataTable dtbl = objSL.Select();
        Gridview1.DataSource = dtbl;
        Gridview1.DataBind();
    }

	public void BindSaleStage()
	{
		tbl_SalesStageMaster objssm = new tbl_SalesStageMaster();
		objssm.OrderBy = "SStageID";
		DataTable dt = objssm.Select();
		ddlStage.DataSource = dt;
		ddlStage.DataTextField = "SStageName";
		ddlStage.DataValueField = "SStageID";
		ddlStage.DataBind();
		ddlStage.Items.Insert(0, "Select Stage");
	}

	protected void btnUpdate_Click(object sender, EventArgs e)
	{
		int intleadid = clsPrecaution.GetInt_Zero(Request.QueryString["LeadID"]);
		int intStageid = clsPrecaution.GetInt_Zero(ddlStage.SelectedValue);
		string strstagename = clsPrecaution.GetStr_Empty(ddlStage.SelectedItem.Text);

		Hashtable hst = new Hashtable();
		hst.Add("LStageID", intStageid);
		hst.Add("LStageName", strstagename);

		tbl_SalesStageMaster objssm = new tbl_SalesStageMaster();
		objssm.Data = hst;
		objssm.WhereClause = "LeadID=" + intleadid;
		objssm.Update();
	}
}