﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddSaleStatus : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			EditSaleStatus();
		}
	}

	protected void btnsave_Click(object sender, EventArgs e)
	{
		
			string strsales = clsPrecaution.GetStr_Empty(txtsalename.Text);


			if (btnsave.Text == "Save")
			{
				ClsSalesStatus.AddSalesStatus(strsales);
				Response.Redirect("SalesStatus.aspx");
			}
			else
			{
				if (Request.QueryString["SstatusID"] != null)
				{
					int SstatusID = clsPrecaution.GetInt_Zero(Request.QueryString["SstatusID"]);
					ClsSalesStatus.UpdateSalesStatus(SstatusID, strsales);
					Response.Redirect("SalesStatus.aspx");
				}
			}
		
	}
	public void EditSaleStatus()
	{
		tbl_SaleStatus objedit = new tbl_SaleStatus();
		int SstatusID = clsPrecaution.GetInt_Zero(Request.QueryString["SstatusID"]);
		objedit.WhereClause = "SstatusID=" + SstatusID;
		DataTable dtlead = objedit.Select();


		if (dtlead.Rows.Count > 0)
		{
			txtsalename.Text = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["SstatusName"]);
			btnsave.Text = "Update";

		}
	}


}
