﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!Page.IsPostBack)
        {
            lblerror.Visible = false;
            BindUserType();
			txtpassword.Text = "";
			txtusername.Text = "";
		}
    }

    public void BindUserType()
    {
        ClsUser.bindUserType(ddltypeuser);
    }

    protected void btnlogin_Click(object sender, EventArgs e)
    {
		int typeuser = clsPrecaution.GetInt_Zero(ddltypeuser.SelectedItem.Value);
		if (txtusername.Text!="" & txtpassword.Text!="" & typeuser > 0)
        {
			
		
			
			DataTable dtlogin = new DataTable();
            tbl_User objlogin = new tbl_User();
            objlogin.WhereClause = "UserName='" + txtusername.Text + "'and Password='" + txtpassword.Text + "'and UserType='" + ddltypeuser.SelectedItem.Value + "'";
            dtlogin = objlogin.Select();
            if (dtlogin.Rows.Count > 0)
            {
                string strusername = clsPrecaution.GetStr_Empty(dtlogin.Rows[0]["UserName"]);
                int UserId = clsPrecaution.GetInt_Zero(dtlogin.Rows[0]["UserID"]);
                int UserType = clsPrecaution.GetInt_Zero(dtlogin.Rows[0]["UserType"]);
				String IPAddress = clsPrecaution.GetStr_Empty(dtlogin.Rows[0]["IPAddress"]);
				String LastLogin = clsPrecaution.GetStr_Empty(dtlogin.Rows[0]["LastLogin"]);


				string ipaddress;

				ipaddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

				if (ipaddress == "" || ipaddress == null)
				{
					ipaddress = Request.ServerVariables["REMOTE_ADDR"];
				}


				String strDate = clsPrecaution.GetStr_Empty(DateTime.Now.ToString("yyyy-MM-dd"));
				string dttime = ClsProj.GetMMDD_Current(strDate);


				Hashtable hstbl = new Hashtable();
				hstbl.Add("IPAddress", ipaddress);
				hstbl.Add("LastLogin", strDate);

				tbl_User obj = new tbl_User();
				obj.Data = hstbl;
				obj.WhereClause = "UserID=" + UserId;
				obj.Update();


				Session["UserType"] = UserType;
				Session["UserName"] = strusername;
				Session["UserID"] = UserId;
				Session["IPAddress"] = IPAddress;
				Session["LastLogin"] = LastLogin;

				if (UserType == 1)
				{

					Response.Redirect("AdminDashboard.aspx");
				}
				else if (UserType == 2)
				{

					Response.Redirect("DashboardLM.aspx");
				}
				else if (UserType == 3)
				{

					Response.Redirect("DashboardSM.aspx");
				}
				else if (UserType == 4)
				{

					Response.Redirect("DashboardLE.aspx");
				}
				else if (UserType == 5)
				{

					Response.Redirect("DashboardSE.aspx");
				}
			}
			else
            {
                lblerror.Visible = true;
               
                lblerror.Text = "Unable to Login";
			}
			
		}
        else
        {
            lblerror.Text = "All Fields are Mandatory";
			lblerror.ForeColor = System.Drawing.Color.Red;
        }
       
    }
}