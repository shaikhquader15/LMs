﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddActivityCalls : System.Web.UI.Page
{
	protected void Page_PreInit(Object sender, EventArgs e)
	{
		ClsProj.GetMasterPage(this);

	}
	int LeadID = 0;
    String strleadname = "";
    int StatusID = 0;

    String strStatusName = "";
	string strcontact = "";
	string strsource = "";
	protected void Page_Load(object sender, EventArgs e)
    {
		if (!Page.IsPostBack)
		{
			Leadname();
			BindLeadStage();
			BindEmailFormat();
			BindLeadEmail();

			DateTime d = new DateTime();
			d = DateTime.Now;

			txtcalldate.Text = DateTime.Now.ToString("yyyy-MM-dd");
			txtcalltime.Text = d.ToString("HH:mm:ss");

			//txtcalldate.Text = DateTime.Now.ToString();
			//txtcalltime.Text = DateTime.Now.ToString("hh:mm tt", System.Globalization.DateTimeFormatInfo.InvariantInfo);		
			//clsPrecaution.GetStr_Empty(DateTime.Now);
		}
    }


    public void Leadname()
    {
        if (Request.QueryString["ld"] != null)
        {
            LeadID = Convert.ToInt32(Request.QueryString["ld"]);
        }
        lblleadname.Text = ClsLead.GetLeadName(LeadID);
        strleadname = ClsLead.GetLeadName(LeadID);
    }

    public void StatusName()
    {
        if (Request.QueryString["ls"] != null)
        {
            StatusID = clsPrecaution.GetInt_Zero(Request.QueryString["ls"]);
        }
        strStatusName = ClsLead.GetStatusName(StatusID);

    }

    protected void btnUpdate_Click(object sender, EventArgs e)
	{
		int UserID = clsPrecaution.GetInt_Zero(Session["UserID"]);
		
		int StatusID = 0;
		if (Request.QueryString["ld"] != null)
		{
			LeadID = Convert.ToInt32(Request.QueryString["ld"]);
		}
		if (Request.QueryString["ls"] != null)
		{
			StatusID = clsPrecaution.GetInt_Zero(Request.QueryString["ls"]);
		}

		tbl_Lead objlead = new tbl_Lead();
		objlead.WhereClause = "LeadID=" + LeadID;
		DataTable dt = objlead.Select();
		if (dt.Rows.Count > 0)
		{
			strcontact = clsPrecaution.GetStr_Empty(dt.Rows[0]["Contact1"]);
			strsource = clsPrecaution.GetStr_Empty(dt.Rows[0]["SourceName"]);
		}
		strleadname = ClsLead.GetLeadName(LeadID);
		strStatusName = ClsLead.GetStatusName(StatusID);


		String strlcaldate = clsPrecaution.GetStr_Null(txtcalldate.Text);
	
		String strcaltime = clsPrecaution.GetStr_Null(txtcalltime.Text);
		String strremark = clsPrecaution.GetStr_Null(txtremark.Text);
		int strstageid = clsPrecaution.GetInt_Zero(ddlStage.SelectedValue);
		string strstagename = clsPrecaution.GetStr_Empty(ddlStage.SelectedItem.Text);

		clsLeadLog.InsertLeadDeatilsAddActivityCalls(LeadID, strleadname, StatusID, strStatusName, strcontact, strsource,strlcaldate, strcaltime, strremark, strstageid, strstagename,"");

        ClsLead.GetLeadDetailsByLeadID(LeadID, StatusID, strlcaldate, strcaltime, strremark, strstageid, strstagename);
        
		int intOpenCalls = ClsProj.GetDataValue("tbl_Lead", "UserID=" + UserID + " and ( LStatusID=1 or LStatusID=2 or LStatusID=3 or LStatusID=6 )");
		//lblOpen.Text = Convert.ToString(intOpenCalls);
		Session["TotalOpenCalls"] = Convert.ToString(intOpenCalls);

		//ClsLead.UpdateLeads();
		Response.Redirect("UpcomingCalls.aspx");
	}


	public void BindLeadStage()
	{
		ClsLeadStageMaster.StageDropdown(ddlStage);
	}

	public void BindEmailFormat()
	{
		tbl_EmailFormat objef = new tbl_EmailFormat();
		DataTable dtbl = objef.Select();
		ddlemailformat.DataSource = dtbl;
		ddlemailformat.DataTextField = "StageName";
		ddlemailformat.DataValueField = "StageID";
		ddlemailformat.DataBind();
		ddlemailformat.Items.Insert(0, "Select Email Format");

	}


	protected void ddlemailformat_SelectedIndexChanged(object sender, EventArgs e)
	{
		int intemailfor = clsPrecaution.GetInt_Zero(ddlemailformat.SelectedItem.Value);
		tbl_EmailFormat objem = new tbl_EmailFormat();
		objem.WhereClause = "StageID=" + intemailfor;
		DataTable dtbl = objem.Select();
		if (dtbl.Rows.Count > 0)
		{
			txtdesc.Text = clsPrecaution.GetStr_Empty(dtbl.Rows[0]["Description"]);
		}

	}


	public void BindLeadEmail()
	{
		int leadid = 0;
		if (Request.QueryString["ld"] != null)
		{
			 leadid = clsPrecaution.GetInt_Zero(Request.QueryString["ld"]);
		}
		tbl_Lead objlead = new tbl_Lead();
		objlead.WhereClause = "LeadID=" + leadid;
		DataTable dtbl = objlead.Select();
		if (dtbl.Rows.Count > 0)
		{
			txtemailadd.Text = clsPrecaution.GetStr_Empty(dtbl.Rows[0]["Email1"]);
		}


	}
}