﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Setting : System.Web.UI.Page
{
	protected void Page_PreInit(Object sender, EventArgs e)
	{
		ClsProj.GetMasterPage(this);

	}
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
		
		BindDropdownRinging();
		BindDropdownBusy();
		BindDropdownNotReachable();
		BindDropdownNotDisconnect();
		BindDropdownWrongNumber();
		BindDropdownSwitchOff();
		BindDropdownCallback();
		BindDropdownAppointment();
		BindDropdownDND();
		BindDropdownNotInt();
		BindSalesFollowup();
		BindSalesNotInt();
		BindSalesPostponed();
		BindSalesNewsales();
		BindSalesConverted();
		}
	}



	public void BindDropdownRinging()
	{
		tbl_LeadStatus objstatus = new tbl_LeadStatus();
		objstatus.OrderBy = "LStatusID";
		DataTable dtbl = objstatus.Select();
		ddlStatus.DataSource = dtbl;
		ddlStatus.DataTextField = "StatusName";
		ddlStatus.DataValueField = "LStatusID";
		ddlStatus.DataBind();
		ddlStatus.Items.Insert(0, "Select Status");
	}

	public void BindDropdownBusy()
	{
		tbl_LeadStatus objstatus = new tbl_LeadStatus();
		objstatus.OrderBy = "LStatusID";
		DataTable dtbl = objstatus.Select();
		ddlbusy.DataSource = dtbl;
		ddlbusy.DataTextField = "StatusName";
		ddlbusy.DataValueField = "LStatusID";
		ddlbusy.DataBind();
		ddlbusy.Items.Insert(0, "Select Status");
	}

	public void BindDropdownNotReachable()
	{
		tbl_LeadStatus objstatus = new tbl_LeadStatus();
		objstatus.OrderBy = "LStatusID";
		DataTable dtbl = objstatus.Select();
		ddlnotreachable.DataSource = dtbl;
		ddlnotreachable.DataTextField = "StatusName";
		ddlnotreachable.DataValueField = "LStatusID";
		ddlnotreachable.DataBind();
		ddlnotreachable.Items.Insert(0, "Select Status");
	}

	public void BindDropdownNotDisconnect()
	{
		tbl_LeadStatus objstatus = new tbl_LeadStatus();
		objstatus.OrderBy = "LStatusID";
		DataTable dtbl = objstatus.Select();
		ddldisconn.DataSource = dtbl;
		ddldisconn.DataTextField = "StatusName";
		ddldisconn.DataValueField = "LStatusID";
		ddldisconn.DataBind();
		ddldisconn.Items.Insert(0, "Select Status");
	}

	public void BindDropdownWrongNumber()
	{
		tbl_LeadStatus objstatus = new tbl_LeadStatus();
		objstatus.OrderBy = "LStatusID";
		DataTable dtbl = objstatus.Select();
		ddlWrongNum.DataSource = dtbl;
		ddlWrongNum.DataTextField = "StatusName";
		ddlWrongNum.DataValueField = "LStatusID";
		ddlWrongNum.DataBind();
		ddlWrongNum.Items.Insert(0, "Select Status");
	}

	public void BindDropdownSwitchOff()
	{
		tbl_LeadStatus objstatus = new tbl_LeadStatus();
		objstatus.OrderBy = "LStatusID";
		DataTable dtbl = objstatus.Select();
		ddlswitchoff.DataSource = dtbl;
		ddlswitchoff.DataTextField = "StatusName";
		ddlswitchoff.DataValueField = "LStatusID";
		ddlswitchoff.DataBind();
		ddlswitchoff.Items.Insert(0, "Select Status");
	}

	public void BindDropdownCallback()
	{
		tbl_LeadStatus objstatus = new tbl_LeadStatus();
		objstatus.OrderBy = "LStatusID";
		DataTable dtbl = objstatus.Select();
		ddlcallback.DataSource = dtbl;
		ddlcallback.DataTextField = "StatusName";
		ddlcallback.DataValueField = "LStatusID";
		ddlcallback.DataBind();
		ddlcallback.Items.Insert(0, "Select Status");
	}

	public void BindDropdownAppointment()
	{
		tbl_LeadStatus objstatus = new tbl_LeadStatus();
		objstatus.OrderBy = "LStatusID";
		DataTable dtbl = objstatus.Select();
		ddlappointment.DataSource = dtbl;
		ddlappointment.DataTextField = "StatusName";
		ddlappointment.DataValueField = "LStatusID";
		ddlappointment.DataBind();
		ddlappointment.Items.Insert(0, "Select Status");
	}

	public void BindDropdownDND()
	{
		tbl_LeadStatus objstatus = new tbl_LeadStatus();
		objstatus.OrderBy = "LStatusID";
		DataTable dtbl = objstatus.Select();
		ddldnd.DataSource = dtbl;
		ddldnd.DataTextField = "StatusName";
		ddldnd.DataValueField = "LStatusID";
		ddldnd.DataBind();
		ddldnd.Items.Insert(0, "Select Status");
	}


	public void BindDropdownNotInt()
	{
		tbl_LeadStatus objstatus = new tbl_LeadStatus();
		objstatus.OrderBy = "LStatusID";
		DataTable dtbl = objstatus.Select();
		ddlNotInt.DataSource = dtbl;
		ddlNotInt.DataTextField = "StatusName";
		ddlNotInt.DataValueField = "LStatusID";
		ddlNotInt.DataBind();
		ddlNotInt.Items.Insert(0, "Select Status");
	}

	public void BindSalesFollowup()
	{
		ClsSalesStatus.BindSaleStatus(ddlSfollow);
	}


	public void BindSalesNotInt()
	{
		ClsSalesStatus.BindSaleStatus(ddlSnotint);
	}


	
	public void BindSalesPostponed()
	{
		ClsSalesStatus.BindSaleStatus(ddlpostponed);
	}

	public void BindSalesNewsales()
	{
		ClsSalesStatus.BindSaleStatus(ddlNewsales);
	}


	public void BindSalesConverted()
	{
		ClsSalesStatus.BindSaleStatus(ddlconverted);
	}


	public void SettingCallbackStatus()
	{
		int intcalback = clsPrecaution.GetInt_Zero(ddlcallback.SelectedValue);
		String strcalback = clsPrecaution.GetStr_Empty(ddlcallback.SelectedItem.Text);
		if (intcalback > 0)
		{
			ClsSetting.GetLeadStatus("Callback", intcalback);
		}
	}

	public void SettingRingingStatus()
	{
		int intcalringing = clsPrecaution.GetInt_Zero(ddlStatus.SelectedValue);
		String strcalback = clsPrecaution.GetStr_Empty(ddlStatus.SelectedItem.Text);
		if (intcalringing > 0)
		{
			ClsSetting.GetLeadStatus("Ringing", intcalringing);
		}
	}

	public void SettingBusyStatus()
	{
		int intcalbusy = clsPrecaution.GetInt_Zero(ddlbusy.SelectedValue);
		String strcalback = clsPrecaution.GetStr_Empty(ddlbusy.SelectedItem.Text);
		if (intcalbusy > 0)
		{
			ClsSetting.GetLeadStatus("Busy", intcalbusy);
		}
	}

	public void SettingNotreachableStatus()
	{
		int intcalNot = clsPrecaution.GetInt_Zero(ddlnotreachable.SelectedValue);
		String strcalback = clsPrecaution.GetStr_Empty(ddlnotreachable.SelectedItem.Text);
		if (intcalNot > 0)
		{
			ClsSetting.GetLeadStatus("Not Reachable", intcalNot);
		}
	}

	public void SettingDisconnectStatus()
	{
		int intdisconnect = clsPrecaution.GetInt_Zero(ddldisconn.SelectedValue);
		String strcalback = clsPrecaution.GetStr_Empty(ddldisconn.SelectedItem.Text);
		if (intdisconnect > 0)
		{
			ClsSetting.GetLeadStatus("Disconnect", intdisconnect);
		}
	}


	public void SettingWrongNumberStatus()
	{
		int intwrongnum = clsPrecaution.GetInt_Zero(ddlWrongNum.SelectedValue);
		String strcalback = clsPrecaution.GetStr_Empty(ddlWrongNum.SelectedItem.Text);
		if (intwrongnum > 0)
		{
			ClsSetting.GetLeadStatus("Wrong Number", intwrongnum);
		}
	}

	public void SettingSwitchOffStatus()
	{
		int intswitchoff = clsPrecaution.GetInt_Zero(ddlswitchoff.SelectedValue);
		String strcalback = clsPrecaution.GetStr_Empty(ddlswitchoff.SelectedItem.Text);
		if (intswitchoff > 0)
		{
			ClsSetting.GetLeadStatus("Switch Off", intswitchoff);
		}
	}

	public void SettingAppointmentStatus()
	{
		int intappointment = clsPrecaution.GetInt_Zero(ddlappointment.SelectedValue);
		String strcalback = clsPrecaution.GetStr_Empty(ddlappointment.SelectedItem.Text);
		if (intappointment > 0)
		{
			ClsSetting.GetLeadStatus("Appointment", intappointment);
		}
	}

	public void SettingdndStatus()
	{
		int intdnd = clsPrecaution.GetInt_Zero(ddldnd.SelectedValue);
		String strcalback = clsPrecaution.GetStr_Empty(ddldnd.SelectedItem.Text);
		if (intdnd > 0)
		{
			ClsSetting.GetLeadStatus("DND", intdnd);
		}
	}


	public void SettingLeadNotIntStatus()
	{
		int intnotint = clsPrecaution.GetInt_Zero(ddlNotInt.SelectedValue);
		String strcalback = clsPrecaution.GetStr_Empty(ddlNotInt.SelectedItem.Text);
		if (intnotint > 0)
		{
			ClsSetting.GetLeadStatus("Lead Not Interested", intnotint);
		}
	}


	public void SettingNewSalesStatus()
	{
		int intnewsales = clsPrecaution.GetInt_Zero(ddlNewsales.SelectedValue);
		String strcalback = clsPrecaution.GetStr_Empty(ddlNewsales.SelectedItem.Text);
		if (intnewsales > 0)
		{
			ClsSetting.GetLeadStatus("New Sales", intnewsales);
		}
	}

	public void SettingSalesFollowupStatus()
	{
		int intsalesfollowup = clsPrecaution.GetInt_Zero(ddlSfollow.SelectedValue);
		String strcalback = clsPrecaution.GetStr_Empty(ddlSfollow.SelectedItem.Text);
		if (intsalesfollowup > 0)
		{
			ClsSetting.GetLeadStatus("Follow Up", intsalesfollowup);
		}
	}

	public void SettingSalesNotIntStatus()
	{
		int intsalesfollowup = clsPrecaution.GetInt_Zero(ddlSnotint.SelectedValue);
		String strcalback = clsPrecaution.GetStr_Empty(ddlSnotint.SelectedItem.Text);
		if (intsalesfollowup > 0)
		{
			ClsSetting.GetLeadStatus("Sales Not Interested", intsalesfollowup);
		}
	}

	public void SettingPostponedStatus()
	{
		int intpostponed = clsPrecaution.GetInt_Zero(ddlpostponed.SelectedValue);
		String strcalback = clsPrecaution.GetStr_Empty(ddlpostponed.SelectedItem.Text);
		if (intpostponed > 0)
		{
			ClsSetting.GetLeadStatus("Postponed", intpostponed);
		}
	}



	public void SettingConvertedStatus()
	{
		int intconverted = clsPrecaution.GetInt_Zero(ddlconverted.SelectedValue);
		String strcalback = clsPrecaution.GetStr_Empty(ddlconverted.SelectedItem.Text);
		if (intconverted > 0)
		{
			ClsSetting.GetLeadStatus("Converted", intconverted);
		}
	}
	protected void btnUpdate_Click(object sender, EventArgs e)
	{
		SettingCallbackStatus();
		SettingRingingStatus();
		SettingBusyStatus();
		SettingNotreachableStatus();
		SettingDisconnectStatus();
		SettingWrongNumberStatus();
		SettingSwitchOffStatus();
		SettingAppointmentStatus();
		SettingdndStatus();
		SettingLeadNotIntStatus();
		SettingNewSalesStatus();
		SettingSalesFollowupStatus();
		SettingSalesNotIntStatus();
		SettingPostponedStatus();
		SettingConvertedStatus();
	}
}