﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterSM : System.Web.UI.MasterPage
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			if (Session["UserID"] != null)
			{
				int UserID = clsPrecaution.GetInt_Zero(Session["UserID"]);
			//GetRecord();
			//ShowUpcomingCall();
			//int intUpcomingCalls = ClsProj.GetDataValue("tbl_Lead", "UserID=" + UserID + " and ( LStatusID = 0)");
			//lblNot_TotFollowcalls.Text = Convert.ToString(Session["TotalFolowCalls"]);
			//lblNot_NotInterested.Text = Convert.ToString(Session["TotatNotInterestedCalls"]);
			//lblNot_Postponed.Text = Convert.ToString(Session["TotalPosponedCalls"]);
			
				if (Session["UserName"] != null)
				{
					lblUser.Text = Session["UserName"].ToString();
					lblLogUser.Text = Session["UserName"].ToString();
					showImage();
				}

			}
		}
	}


	public void showImage()
	{
		int UserID = clsPrecaution.GetInt_Zero(Session["UserID"].ToString());

		tbl_User obj = new tbl_User();
		obj.WhereClause = "UserID=" + UserID;
		DataTable dtbl = obj.Select();
		if (dtbl.Rows.Count > 0)
		{
			String strPath = clsPrecaution.GetStr_Null(dtbl.Rows[0]["ProfImage"]);
			imgprod.ImageUrl = strPath;
		}
	}
}
