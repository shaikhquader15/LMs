﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ManageUsers : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!Page.IsPostBack)
        {
            showUser();
        }
    }

    public void showUser()
    {

        string strquery = @"select *, tbl_User.UserName,tbl_User.EmailAddress,tbl_User.Contact,tbl_User.Address,tbl_UserType.UserName from tbl_User inner join tbl_UserType on tbl_User.UserType=tbl_UserType.UserType ";

        //tbl_User obj = new tbl_User();
        DataTable dtuser = new DataTable();
        dtuser = ClsProj.GetCondata(strquery);
        Gridview_s.DataSource = dtuser;
        Gridview_s.DataBind();
    }

	protected void btnEdit_Click(object sender, EventArgs e)
	{
		LinkButton objlknbtn = (LinkButton)sender;
		int ID = Convert.ToInt32(objlknbtn.CommandArgument);
		Response.Redirect("AddNewUser.aspx?UserID=" + ID);
	}

	protected void btnDelete_Click(object sender, EventArgs e)
	{
		LinkButton objlknbtn = (LinkButton)sender;
		int userid = Convert.ToInt32(objlknbtn.CommandArgument);
		ClsUser.delUser(userid);
	}

	protected void Gridview_s_PageIndexChanging(object sender, GridViewPageEventArgs e)
	{
		Gridview_s.PageIndex = e.NewPageIndex;
		showUser();
	}
}