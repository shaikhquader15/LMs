﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddSource : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			EditSaleStatus();
		}
	}

	protected void btnsave_Click(object sender, EventArgs e)
	{

		string strsales = clsPrecaution.GetStr_Empty(txtsourcename.Text);


		if (btnsave.Text == "Save")
		{
			ClsSource.AddSource(strsales);
			Response.Redirect("SourceMaster.aspx");
		}
		else
		{
			if (Request.QueryString["SourceID"] != null)
			{
				int sourceid = clsPrecaution.GetInt_Zero(Request.QueryString["SourceID"]);
				ClsSource.UpdateSource(sourceid, strsales);
				Response.Redirect("SourceMaster.aspx");
			}
		}

	}
	public void EditSaleStatus()
	{
		tbl_Source objedit = new tbl_Source();
		int sourceid = clsPrecaution.GetInt_Zero(Request.QueryString["SourceID"]);
		objedit.WhereClause = "SourceID=" + sourceid;
		DataTable dtlead = objedit.Select();


		if (dtlead.Rows.Count > 0)
		{
			txtsourcename.Text = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["SourceName"]);
			btnsave.Text = "Update";

		}
	}

}