﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Customersbystage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            plcCustomers.Controls.Add(new LiteralControl(LeadMenu()));
        }

    }
    public string LeadMenu()
    {
        tbl_Lead objfollow = new tbl_Lead();
        StringBuilder sb = new StringBuilder();
        sb.Append("<ul class=\"nav nav-tabs\">");
        tbl_Status objst = new tbl_Status();
        objst.OrderBy = "StatusID";
        DataTable dt = objst.Select();
        foreach (DataRow dr in dt.Rows)
        {
            sb.Append(" <li role=\"presentation\"><a href=\"#tab" + dr["StatusID"] + "\" role=\"tab\" data-toggle=\"tab\">" + dr["StatusName"] + "</a></li>");
        }
        sb.Append("</ul>");
        sb.Append(" <div class=\"tab-content\">");
        DataTable dtbl= new DataTable();
        foreach (DataRow dr in dt.Rows)
        {
            objfollow.OrderBy = "LeadID";
            objfollow.WhereClause = "LStatusID in (select LStatusID from tbl_LeadStatus where StatusID=" + dr["StatusID"] + ") and IsDelete=0";
           
            dtbl = objfollow.Select();
            
            sb.Append("<div role=\"tabpanel\" class=\"tab-pane\" id=\"tab" + dr["StatusID"].ToString() + "\">");
            sb.Append("<div class=\"panel panel-default\"><div class=\"panel-heading\">" + dr["StatusName"] + "</div>");
            sb.Append("<div class=\"panel-body\">test data</div></div></div>");
        }
        sb.Append("</div>");
            return sb.ToString();
    }
}