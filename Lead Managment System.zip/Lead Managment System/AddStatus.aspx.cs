﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Component;
using System.Data;


public partial class AddStatus : System.Web.UI.Page
{
	
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			EditStatus();
			RbtnCheched();
		}
		
	}

	public void EditStatus()
	{
		tbl_Status objstatus = new tbl_Status();
		int statusid = clsPrecaution.GetInt_Zero(Request.QueryString["StatusId"]);
		objstatus.WhereClause = "StatusID=" + statusid;
		DataTable dt = objstatus.Select();

		if (dt.Rows.Count > 0)
		{
			txtstatus.Text = clsPrecaution.GetStr_Empty(dt.Rows[0]["StatusName"]);
			//txtchkbox.Text = clsPrecaution.GetStr_Empty(dt.Rows[0]["IsApproved"]);
			btnsave.Text = "Update";
		}
	}


	protected void RbtnCheched()
	{
		if (Request.QueryString["StatusID"] != null)
		{

			int id = Convert.ToInt32(Request.QueryString["StatusID"]);
			if (id > 0)
			{
				tbl_Status objRbtn = new tbl_Status();
				DataTable dtbl = new DataTable();
				objRbtn.WhereClause = "StatusID=" + id;
				dtbl = objRbtn.Select();
				if (dtbl.Rows.Count > 0)
				{
					int a = clsPrecaution.GetInt_Zero(dtbl.Rows[0]["IsApproved"]);
					if (a == 1)
					{
						txtchkbox.Checked = true;
					}
					else
					{
						txtchkbox.Checked = false;
					}
				}
			}
		}
	}



	protected void btnsave_Click(object sender, EventArgs e)
	{

		int IsApprove = 0;

		if (txtchkbox.Checked)
		{
			IsApprove = 1;
		}
		else
		{
			IsApprove = 0;
		}

		string statusname = clsPrecaution.GetStr_Empty(txtstatus.Text);
		//int intchkbx = clsPrecaution.GetInt_Zero(txtchkbox.Text);

		if (btnsave.Text == "Save")
		{
			ClsStatus.AddStatus(statusname, IsApprove);
			Response.Redirect("StatusMaster.aspx");
		}

		else
		{
			if (Request.QueryString["StatusID"] != null)
			{
				int statusid = clsPrecaution.GetInt_Zero(Request.QueryString["StatusID"]);
				ClsStatus.UpdateStatus(statusid, statusname, IsApprove);
				Response.Redirect("StatusMaster.aspx");

			}
		}

	}
}