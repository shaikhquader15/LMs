﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SalesFollowUp : System.Web.UI.Page
{
    protected void Page_PreInit(Object sender, EventArgs e)
    {
        ClsProj.GetMasterPage(this);

    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
			
            //ShowUpcomingCall();
            if (Session["UserID"] != null)
            {
                if (Session["UserType"] != null)
                {
                    ShowUpcomingSales();
					ShowReminder();

				}
            }


        }
    }


    public void ShowUpcomingSales()
    {
		int UserID = clsPrecaution.GetInt_Zero(Session["UserID"]);

		tbl_SalesTeam objSt = new tbl_SalesTeam();
        DataTable dtbl = new DataTable();
		objSt.OrderBy = "SstatusID";
		objSt.WhereClause ="SUserID="+ UserID +" and SstatusID=1 and IsSent=1";

		dtbl = objSt.Select();
        Gridview1.DataSource = dtbl;
        Gridview1.DataBind();
    }


	public void ShowReminder()
	{
		String StrLeadName = "";
		String strCallTime = "";
		int UserID = clsPrecaution.GetInt_Zero(Session["UserID"].ToString());
		tbl_SalesTeam obj = new tbl_SalesTeam();
		obj.WhereClause = "SUserID=" + UserID;
		DataTable dtshow = obj.Select();
		if (dtshow.Rows.Count > 0)
		{
			string calltime = clsPrecaution.GetStr_Empty(dtshow.Rows[0]["CallDate"]);
			string strcaltime = ClsProj.GetMMDD_Current(calltime);

			String strDate = clsPrecaution.GetStr_Empty(DateTime.Now.ToString("yyyy-MM-dd"));
			string dttime = ClsProj.GetMMDD_Current(strDate);

			if (strcaltime == dttime)
			{
				String strquery = "select Top 1 * from tbl_SalesTeam where Calldate='" + dttime + "'Order By CallTime Desc";
				DataTable dtre = ClsProj.GetCondata(strquery);
				if (dtre.Rows.Count > 0)
				{
					StrLeadName = clsPrecaution.GetStr_Null(dtre.Rows[0]["LeadName"]);
					strCallTime = clsPrecaution.GetStr_Null(dtre.Rows[0]["CallTime"]);

				}

				lblremindertime.Text = strCallTime;
				lblleadname.Text = StrLeadName;
			}

		}
	}

	protected void Gridview1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            tbl_SaleStatus objST = new tbl_SaleStatus();
            objST.OrderBy = "SstatusID";
            DataTable dtbl = objST.Select();

            if (dtbl.Rows.Count > 0)
            {
                DropDownList ddlSalesTeam = (DropDownList)e.Row.FindControl("ddlSalesTeam");
				HiddenField hdnval = (HiddenField)e.Row.FindControl("hdnprice");

				ddlSalesTeam.DataSource = dtbl;
                ddlSalesTeam.DataTextField = "SstatusName";
                ddlSalesTeam.DataValueField = "SstatusID";
                ddlSalesTeam.DataBind();
                ddlSalesTeam.Items.Insert(0, "Select Status");
				if (hdnval.Value != "0")
				{
					ddlSalesTeam.Items.FindByValue(hdnval.Value).Selected = true;
				}
			}
		}

    }

    protected void ddlSalesTeam_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList ddlSellist = (DropDownList)sender;
        GridViewRow gvrow = (GridViewRow)ddlSellist.NamingContainer;
        int index = gvrow.RowIndex;

        
        Label lblSalesId = (Label)Gridview1.Rows[index].FindControl("lblSalesId");
		//Label lblSalesId = (Label)Gridview1.Rows[index].FindControl("lblSalesId");

		int sid = clsPrecaution.GetInt_Zero(ddlSellist.SelectedItem.Value);
		if (sid == 1 || sid == 2 || sid == 3 || sid == 4 || sid == 5)
		{
            Response.Redirect("AddSalesAppointment.aspx?ld=" + lblSalesId.Text + "&ls=" + sid);
        }
        

        //DropDownList ddlSalesTeam = (DropDownList)Gridview1.Rows[index].FindControl("ddlSalesTeam");
        //Response.Redirect("AddActivityCalls.aspx");
    }


	private void BindGrid()
	{
		int UserID = clsPrecaution.GetInt_Zero(Session["UserID"]);
		string strWhere = "";

		if (txtCaller.Text.Length > 1)                           //Search Textbox
		{
			strWhere += " AND UserName like '%" + txtCaller.Text + "%'";
		}

		if (txtLead.Text.Length > 1)                           //Search Textbox
		{
			strWhere += " AND LeadName like '%" + txtLead.Text + "%'";
		}

		if (txtLCD.Text.Length > 1)                           //Search Textbox
		{
			strWhere += " AND CallDate like '%" + txtLCD.Text + "%'";
		}

		if (txtLCT.Text.Length > 1)                           //Search Textbox
		{
			strWhere += " AND CallTime like '%" + txtLCT.Text + "%'";
		}

		if (txtSales.Text.Length > 1)                           //Search Textbox
		{
			strWhere += " AND SUserName like '%" + txtSales.Text + "%'";
		}

		if (txtAddress.Text.Length > 1)                           //Search Textbox
		{
			strWhere += " AND Address like '%" + txtAddress.Text + "%'";
		}

		if (txtProduct.Text.Length > 1)                           //Search Textbox
		{
			strWhere += " AND Product like '%" + txtProduct.Text + "%'";
		}

		if (txtAmount.Text.Length > 1)                           //Search Textbox
		{
			strWhere += " AND Amount like '%" + txtAmount.Text + "%'";
		}

		string strQuery = "select * from tbl_SalesTeam where  1=1 and UserID="+ UserID + strWhere;

		DataTable dt = new DataTable();

		dt = ClsProj.GetCondata(strQuery);

		Gridview1.DataSource = dt;
		Gridview1.DataBind();


	}


	protected void btnSearch_Click(object sender, EventArgs e)
	{
		BindGrid();
	}
}