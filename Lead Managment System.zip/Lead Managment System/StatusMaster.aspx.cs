﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Component;

using System.Data;

public partial class StatusMaster : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			ShowStatus();
		}
	}


	public void ShowStatus()
	{
		tbl_Status seldata = new tbl_Status();
		seldata.OrderBy = "StatusID";
		DataTable dtbl = new DataTable();
		dtbl = seldata.Select();
		Gridview1.DataSource = dtbl;
		Gridview1.DataBind();
	}


	protected void btnEdit_Click(object sender, EventArgs e)
	{
		LinkButton lbutn = (LinkButton)sender;
		int ID = Convert.ToInt32(lbutn.CommandArgument);
		Response.Redirect("AddStatus.aspx?StatusID=" + ID);
	}

	protected void btnDelete_Click(object sender, EventArgs e)
	{
		LinkButton Dbutn = (LinkButton)sender;
		int ID = Convert.ToInt32(Dbutn.CommandArgument);

		tbl_Status objdlete = new tbl_Status();
		objdlete.WhereClause = "StatusID=" + ID;
		objdlete.Delete();
		if (Session["UserID"] != null)
		{
			if (Session["UserType"] != null)
			{
				ShowStatus();
			}
		}
	}
}