﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class LogReports : System.Web.UI.Page
{
	protected void Page_PreInit(Object sender, EventArgs e)
	{
		ClsProj.GetMasterPage(this);

	}
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			ShowLog();
			BindLead();
		}
	}


	public void ShowLog()
	{
		//int LeadID = clsPrecaution.GetInt_Zero(Request.QueryString["LeadID"]);

		tbl_LeadLog objLL = new tbl_LeadLog();
		//objLL.WhereClause = "LeadID=" + LeadID;
		DataTable dtbl = objLL.Select();
		Gridview1.DataSource = dtbl;
		Gridview1.DataBind();
	}

	protected void ddlCalling_SelectedIndexChanged(object sender, EventArgs e)
	{
		//int leadid = clsPrecaution.GetInt_Zero(ddluser.SelectedValue);
		//tbl_LeadLog objLL = new tbl_LeadLog();
		//objLL.WhereClause = "LeadID=" + leadid;
		//DataTable dtbl = objLL.Select();
		//Gridview1.DataSource = dtbl;
		//Gridview1.DataBind();

	}

	public void BindLead()
	{
		tbl_Lead objlog = new tbl_Lead();
		DataTable dtbl = objlog.Select();
		ddluser.DataSource = dtbl;
		ddluser.DataValueField = "LeadID";
		ddluser.DataTextField = "LeadName";
		ddluser.DataBind();
		ddluser.Items.Insert(0, "Select Lead");
	}

	private void Search()
	{
		string strWhere = "";
		if (ddluser.SelectedIndex > 0)
		{

			strWhere += " AND LeadID=" + ddluser.SelectedValue;
		}

		//if (ddlStatus.SelectedIndex > 0)
		//{
		//	strWhere += " AND LStatusID= " + ddlStatus.SelectedValue;
		//}

		//if (ddlSource.SelectedIndex > 0)
		//{
		//	strWhere += " AND SourceID= " + ddlSource.SelectedValue;
		//}


		strWhere += " AND LastCallDate between '" + txtSD.Text + "' AND '" + txtED.Text + "'";


		string strQuery = "select * from tbl_LeadLog where 1=1" + strWhere;

		DataTable dt = new DataTable();

		dt = ClsProj.GetCondata(strQuery);

		Gridview1.DataSource = dt;
		Gridview1.DataBind();
	}



	protected void btnSearch_Click(object sender, EventArgs e)
	{
		Search();
	}
}