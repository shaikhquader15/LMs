﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SourceMaster : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!Page.IsPostBack)
        {
            ShowSource();
        }
    }

    public void ShowSource()
    {
        ClsSource.SelectAllSource(Gridview1);
    }

	protected void btnEdit_Click(object sender, EventArgs e)
	{
		LinkButton lnkbtn = (LinkButton)sender;
		int ID = Convert.ToInt32(lnkbtn.CommandArgument);
		Response.Redirect("AddSource.aspx?SourceID=" + ID);
	}

	protected void btnDelete_Click(object sender, EventArgs e)
	{
		LinkButton lnkbtn = (LinkButton)sender;
		int ID = Convert.ToInt32(lnkbtn.CommandArgument);

		tbl_Source objsource = new tbl_Source();
		objsource.WhereClause = "SourceID=" + ID;
		objsource.Delete();
	}

	protected void btnadd_Click(object sender, EventArgs e)
	{
		Response.Redirect("AddSource.aspx");
	}
}