﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class LMSAPI : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		GetAllData();
	}


	public void GetAllData()
	{
		int UserId = 0;
		string UserName = "";
		int LeadID = 0;
		string LeadName = "";
		string Category = "";
		int SourceID = 0;
		string SourceName = "";
		string Email1 = "";
		string Email2 = "";
		string Contact1 = "";
		string Contact2 = "";
		string LandLine1 = "";
		string LandLine2 = "";
		string Address1 = "";
		string Address2 ="";
		string Pincode = "";
		string ShortRmk = "";
		string LongRmk ="";
		int CountryID = 0;
		string CountryName = "";
		int StateID = 0;
		string StateName ="";
		int CityId = 0;
		string CityName = "";
		int LStatusID =0;
		string LStatusName = "";
		string ExtName = "";

		if (Request.QueryString["UserId"] != null)
		{
			 UserId = clsPrecaution.GetInt_Zero(Request.QueryString["UserId"]);
		}

		if (Request.QueryString["UserName"] != null)
		{
			UserName = clsPrecaution.GetStr_Empty(Request.QueryString["UserName"]);
		}
		if (Request.QueryString["LI"] != null)
		{
			 LeadID = clsPrecaution.GetInt_Zero(Request.QueryString["LI"]);
		}

		if (Request.QueryString["LN"] != null)
		{
			 LeadName = clsPrecaution.GetStr_Empty(Request.QueryString["LN"]);
		}

		if (Request.QueryString["CatI"] != null)
		{
			 Category = clsPrecaution.GetStr_Empty(Request.QueryString["CatI"]);
		}

		if (Request.QueryString["SurcID"] != null)
		{
			 SourceID = clsPrecaution.GetInt_Zero(Request.QueryString["SurcID"]);
		}

		if (Request.QueryString["SoucName"] != null)
		{
			 SourceName = clsPrecaution.GetStr_Empty(Request.QueryString["SoucName"]);
		}

		if (Request.QueryString["Email1"] != null)
		{
			 Email1 = clsPrecaution.GetStr_Empty(Request.QueryString["Email1"]);
		}

		if (Request.QueryString["Email2"] != null)
		{
			 Email2 = clsPrecaution.GetStr_Empty(Request.QueryString["Email2"]);
		}

		if (Request.QueryString["Contact1"] != null)
		{
			 Contact1 = clsPrecaution.GetStr_Empty(Request.QueryString["Contact1"]);
		}

		if (Request.QueryString["Contact2"] != null)
		{
			 Contact2 = clsPrecaution.GetStr_Empty(Request.QueryString["Contact2"]);
		}

		if (Request.QueryString["LandLine1"] != null)
		{
			 LandLine1 = clsPrecaution.GetStr_Empty(Request.QueryString["LandLine1"]);
		}

		if (Request.QueryString["LandLine2"] != null)
		{
			 LandLine2 = clsPrecaution.GetStr_Empty(Request.QueryString["LandLine2"]);
		}

		if (Request.QueryString["Address1"] != null)
		{
			 Address1 = clsPrecaution.GetStr_Empty(Request.QueryString["Address1"]);
		}

		if (Request.QueryString["Address2"] != null)
		{
			 Address2 = clsPrecaution.GetStr_Empty(Request.QueryString["Address2"]);
		}

		

		if (Request.QueryString["Pincode"] != null)
		{
			 Pincode = clsPrecaution.GetStr_Empty(Request.QueryString["Pincode"]);
		}

		if (Request.QueryString["ShortRmk"] != null)
		{
			 ShortRmk = clsPrecaution.GetStr_Empty(Request.QueryString["ShortRmk"]);
		}

		if (Request.QueryString["LongRmk"] != null)
		{
			 LongRmk = clsPrecaution.GetStr_Empty(Request.QueryString["LongRmk"]);
		}

		if (Request.QueryString["CountryID"] != null)
		{
			 CountryID = clsPrecaution.GetInt_Zero(Request.QueryString["CountryID"]);
		}

		if (Request.QueryString["CountryName"] != null)
		{
			 CountryName = clsPrecaution.GetStr_Empty(Request.QueryString["CountryName"]);
		}

		if (Request.QueryString["StateID"] != null)
		{
			 StateID = clsPrecaution.GetInt_Zero(Request.QueryString["StateID"]);
		}

		if (Request.QueryString["StateName"] != null)
		{
			 StateName = clsPrecaution.GetStr_Empty(Request.QueryString["StateName"]);
		}

		if (Request.QueryString["CityId"] != null)
		{
			 CityId = clsPrecaution.GetInt_Zero(Request.QueryString["CityId"]);
		}

		if (Request.QueryString["CityName"] != null)
		{
			 CityName = clsPrecaution.GetStr_Empty(Request.QueryString["CityName"]);
		}

		

		if (Request.QueryString["LStatusID"] != null)
		{
			 LStatusID = clsPrecaution.GetInt_Zero(Request.QueryString["LStatusID"]);
		}

		if (Request.QueryString["LStatusName"] != null)
		{
			 LStatusName = clsPrecaution.GetStr_Empty(Request.QueryString["LStatusName"]);
		}
		if (Request.QueryString["ExternalFeildName"] != null)
		{
			ExtName = clsPrecaution.GetStr_Empty(Request.QueryString["ExternalFeildName"]);
		}
		//if (Request.QueryString["Occupation"] != null)
		//{
		//	int LStatusName = Convert.ToInt32(Request.QueryString["LStatusName"]);
		//}

		//if (Request.QueryString["LStatusName"] != null)
		//{
		//	int LStatusName = Convert.ToInt32(Request.QueryString["LStatusName"]);
		//}

		int intleadid=ClsLead.AddLeads(UserId, LeadID, "", UserName, LeadName, Category, Email1, Email2, Contact1, 0, Contact2, LandLine1, LandLine2, Address1, Address2, Pincode, CityName, StateName,
			CountryName, LStatusID, LStatusName, "", "", "", "", "", "", "", SourceID, SourceName, "", "", "", StateID, CityId, 0, "", "", 0, ShortRmk, LongRmk);


		tbl_ExternalFields objef = new tbl_ExternalFields();
		DataTable dt = objef.Select();
		foreach (DataRow dr in dt.Rows)
		{
			if (Request.QueryString[dr["ExternalFieldName"].ToString()] != null)
			{
				ClsExternalFieldLeadMapping.AddExternalFieldsLeadMapping(Request.QueryString[dr["ExternalFieldName"].ToString()].ToString(),int.Parse(dr["ExternalID"].ToString()),intleadid);
			}
		}


		
	}

	
	
}