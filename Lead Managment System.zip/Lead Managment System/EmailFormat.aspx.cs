﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Collections;


public partial class StageMaster : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			ShowStage();
		}
	}

	public void ShowStage()
	{
		tbl_EmailFormat seldata = new tbl_EmailFormat();
		seldata.OrderBy = "StageID";
		DataTable dtbl = new DataTable();
		dtbl = seldata.Select();
		Gridview1.DataSource = dtbl;
		Gridview1.DataBind();
	}


	protected void btnEdit_Click(object sender, EventArgs e)
	{
		LinkButton lbutn = (LinkButton)sender;
		int ID = Convert.ToInt32(lbutn.CommandArgument);
		Response.Redirect("AddEmailFormatMaster.aspx?StageID=" + ID);
	}

	protected void btnDelete_Click(object sender, EventArgs e)
	{
		LinkButton Dbutn = (LinkButton)sender;
		int ID = Convert.ToInt32(Dbutn.CommandArgument);

		tbl_EmailFormat objdlete = new tbl_EmailFormat();
		objdlete.WhereClause = "StageID=" + ID;
		objdlete.Delete();
		if (Session["UserID"] != null)
		{
			if (Session["UserType"] != null)
			{
				ShowStage();
			}
		}
	}

}