﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AssignSales : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
			ShowSales();
			if (Session["UserID"] != null)
            {
				
				BinduserType();
				BindSource();
			}

        }
    }




    public void ShowSales()
    {
        int MID = clsPrecaution.GetInt_Zero(Session["UserID"].ToString());

        tbl_SalesTeam obj = new tbl_SalesTeam();
		obj.WhereClause = "IsSent=0 and SMID="+ MID;
		//obj.WhereClause = "UserID=" + MID;
		//tbl_Data obj = new tbl_DataOnSelectedIndexChanged
		DataTable dtbl = obj.Select();
        Gridview_s.DataSource = dtbl;
        Gridview_s.DataBind();
    }

    public void BinduserType()
    {
		ClsUser.binduser(ddluser, 5);
		//ClsUser.bindUserType(ddlusertype);

        //tbl_UserType obj = new tbl_UserType();
        //DataTable dtut = obj.Select();
        //ddlusertype.DataSource = dtut;
        //ddlusertype.DataTextField = "UserName";
        //ddlusertype.DataValueField = "UserType";
        //ddlusertype.DataBind();
        //ddlusertype.Items.Insert(0, "--Select Usertype--");
    }

    public void BindSource()
    {

        tbl_Source objstatus = new tbl_Source();
        objstatus.OrderBy = "SourceID";
        DataTable dtstatus = objstatus.Select();
        ddlsource.DataSource = dtstatus;
        ddlsource.DataTextField = "SourceName";
        ddlsource.DataValueField = "SourceID";
        ddlsource.DataBind();
        ddlsource.Items.Insert(0, "--Select Source--");

    }


    protected void btnAssign_Click(object sender, EventArgs e)
    {

        int MID = clsPrecaution.GetInt_Zero(Session["UserID"].ToString());
        String strLMName = clsPrecaution.GetStr_Empty(Session["UserName"].ToString());

        DataTable dt = new DataTable();
        dt.Columns.AddRange(new DataColumn[21]
        {
            new DataColumn("SalesID"),
            new DataColumn("SUserID"),
            new DataColumn("SUserName"),
            new DataColumn("SMID"),
            new DataColumn("SMName"),
            new DataColumn("SUserType"),
            new DataColumn("UserID"),
            new DataColumn("UserName"),
            new DataColumn("LeadID"),
            new DataColumn("LeadName"),
            new DataColumn("SourceID"),
            new DataColumn("SourceName"),
            new DataColumn("CallDate"),
            new DataColumn("CallTime"),
            new DataColumn("Address"),
            new DataColumn("Product"),
            new DataColumn("Amount"),
            new DataColumn("SstatusID"),
            new DataColumn("SstatusName"),
            new DataColumn("AppointmentDate"),
            new DataColumn("AppointmentTime"),



        }
        );
        foreach (GridViewRow row in Gridview_s.Rows)
        {
            if (row.RowType == DataControlRowType.DataRow)
            {
                CheckBox chkRow = (row.Cells[0].FindControl("chkRow") as CheckBox);
                if (chkRow.Checked)
                {
					Label lbdataID = (row.Cells[1].FindControl("lbldataID") as Label);
					string SSalesID = lbdataID.Text;

					Label lblSSalesid = (row.Cells[2].FindControl("lblSSalesid") as Label);
					string SUserID = lblSSalesid.Text;

					//string SUserID = row.Cells[2].Text;
                    string SUserName = row.Cells[3].Text;

                    //string SMID = row.Cells[4].Text;
					Label lblSMID = (row.Cells[4].FindControl("lblSMID") as Label);
					string SMID = lblSMID.Text;

					string SMName = row.Cells[5].Text;
                    string SUserType = row.Cells[6].Text;

                    //string UserID = row.Cells[7].Text;
					Label lblUSERID = (row.Cells[7].FindControl("lblUSERID") as Label);
					string UserID = lblSMID.Text;

					string UserName = row.Cells[8].Text;
                    //string LeadID = row.Cells[9].Text;
					Label lblLEADID = (row.Cells[9].FindControl("lblLEADID") as Label);
					string LeadID = lblLEADID.Text;

					string LeadName = row.Cells[10].Text;
                    //string SourceID = row.Cells[11].Text;
					Label lblSourceid = (row.Cells[11].FindControl("lblSourceid") as Label);
					string SourceID = lblSourceid.Text;

					string SourceName = row.Cells[12].Text;

                    string CallDate = row.Cells[13].Text;
                    string CallTime = row.Cells[14].Text;
                    string Address = row.Cells[15].Text;
                    string Product = row.Cells[16].Text;
                    string Amount = row.Cells[17].Text;
                    //string SstatusID = row.Cells[18].Text;
					Label lblSstatusid = (row.Cells[18].FindControl("lblSstatusid") as Label);
					string SstatusID = lblSstatusid.Text;

                    string SstatusName = row.Cells[19].Text;
                    string AppointmentDate = row.Cells[20].Text;
                    string AppointmentTIme = row.Cells[21].Text;

                    int SalesID = clsPrecaution.GetInt_Zero(SSalesID);
                    int userID = clsPrecaution.GetInt_Zero(UserID);
                    int leadID = clsPrecaution.GetInt_Zero(LeadID);
                    int sourceID = clsPrecaution.GetInt_Zero(SourceID);
                    int sstatusID = clsPrecaution.GetInt_Zero(SstatusID);

                    //int intusertype = clsPrecaution.GetInt_Zero(ddlusertype.SelectedItem.Value);
                    int intuser = clsPrecaution.GetInt_Zero(ddluser.SelectedItem.Value);
                    String struser = clsPrecaution.GetStr_Empty(ddluser.SelectedItem.Text);

                    int sourceid = clsPrecaution.GetInt_Zero(ddlsource.SelectedItem.Value);
                    String strsource = clsPrecaution.GetStr_Empty(ddlsource.SelectedItem.Text);

					

                    //dt.Rows.Add(name, country);
                    //ClsLead.AddLeads(intuser,LeadName,Type,Email1,"",Contact1,intusertype,"",Landline1,"",Address1,"",Pincode,City,State,Country,0,"","","","","","","",0,"","");

                    //ClsLead.AddLeads(intuser, MID, strLMName, struser, LeadName, Type, Email1, "", Contact1, intusertype, "", Landline1, "", Address1, "", Pincode, City, State, Country, 0, "", "", "", "", "", "", "", sourceid, strsource, "", "", "");
                    //ClsLead.UpdateLeads(LeadID, MID, strLMName, intuser, struser, LeadName, Type, Email1, intusertype, "", Contact1, "", Landline1, "", Address1, "", Pincode, City, State, Country, 0, "", "", "", "", "", "", "", 0, Source, "", "", "");
                    ClsSalesTeam.UpdateSalesTeam(SalesID, intuser, struser, MID, strLMName, 5, userID, UserName, leadID, LeadName, sourceID, SourceName, CallDate, CallTime, Address, Product, Amount, sstatusID, SstatusName, AppointmentDate, AppointmentTIme);

					//lblmsg.ForeColor = System.Drawing.Color.Green;
					string message = "Data Sent Successfully";

					ShowMessage(message);
				}
            }
        }
        Gridview_s.DataSource = dt;
        Gridview_s.DataBind();
    }



	public void ShowMessage(String message)
	{
		System.Text.StringBuilder sb = new System.Text.StringBuilder();

		sb.Append("<script type = 'text/javascript'>");

		sb.Append("window.onload=function(){");

		sb.Append("alert('");

		sb.Append(message);

		sb.Append("')};");

		sb.Append("</script>");

		ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
	}
	//protected void ddlusertype_SelectedIndexChanged(object sender, EventArgs e)
	//{



	//    if (ddlusertype.SelectedIndex > 0)
	//    {
	//        int userid = clsPrecaution.GetInt_Zero(ddlusertype.SelectedItem.Value);


	//        ClsUser.binduser(ddluser, userid);

	//        //tbl_User objuser = new tbl_User();
	//        //objuser.WhereClause = "UserType=" + userid;
	//        //DataTable dtuser = objuser.Select();
	//        //ddluser.DataSource = dtuser;
	//        //ddluser.DataTextField = "UserName";
	//        //ddluser.DataValueField = "UserID";
	//        //ddluser.DataBind();
	//        //ddluser.Items.Insert(0, "Please Select");
	//    }


	//}

	protected void ddlsource_SelectedIndexChanged(object sender, EventArgs e)
    {
        int intSourceID = clsPrecaution.GetInt_Zero(ddlsource.SelectedItem.Value);



        tbl_SalesTeam obj = new tbl_SalesTeam();
        obj.WhereClause = "SourceID=" + intSourceID;
        DataTable dtbl = obj.Select();
        Gridview_s.DataSource = dtbl;
        Gridview_s.DataBind();
    }
}