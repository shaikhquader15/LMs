﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Component;


public partial class LeadStageMaster : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			ShowLeadStage();
		}
		
	}


	public void ShowLeadStage()
	{
		ClsLeadStageMaster.SelectAllLeadStage(Gridview1);
	}






	protected void btnEdit_Click(object sender, EventArgs e)
	{
		LinkButton lbutn = (LinkButton)sender;
		int ID = Convert.ToInt32(lbutn.CommandArgument);
		Response.Redirect("AddStage.aspx?LStageID=" + ID);
	}

	protected void btnDelete_Click(object sender, EventArgs e)
	{
		LinkButton Dbutn = (LinkButton)sender;
		int ID = Convert.ToInt32(Dbutn.CommandArgument);

		tbl_LeadStageMaster objdlete = new tbl_LeadStageMaster();
		objdlete.WhereClause = "LStageID=" + ID;
		objdlete.Delete();
	}
}