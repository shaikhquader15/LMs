﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class LeadMaster : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!Page.IsPostBack)
        {
			if (Session["UserID"] != null)
			{
				if (Session["UserType"] != null)
				{
					ShowStatus();
				}
			}
			
        }
    }

    public void ShowStatus()
    {
        tbl_LeadStatus obj = new tbl_LeadStatus();
        obj.OrderBy = "LStatusID";
        DataTable dtbl = obj.Select();
        Gridview1.DataSource = dtbl;
        Gridview1.DataBind();
    }

	protected void btnadd_Click(object sender, EventArgs e)
	{
		Response.Redirect("AddLeadStaus.aspx");
	}

	protected void btnedit_Click(object sender, EventArgs e)
	{
		LinkButton lbutn = (LinkButton)sender;
		int ID = Convert.ToInt32(lbutn.CommandArgument);
		Response.Redirect("AddLeadStaus.aspx?LStatusID=" + ID);
	}

	protected void btnDelete_Click(object sender, EventArgs e)
	{
		LinkButton Dbutn = (LinkButton)sender;
		int ID = Convert.ToInt32(Dbutn.CommandArgument);

		tbl_LeadStatus objdlete = new tbl_LeadStatus();
		objdlete.WhereClause = "LStatusID=" + ID;
		objdlete.Delete();
		if (Session["UserID"] != null)
		{
			if (Session["UserType"] != null)
			{
				ShowStatus();
			}
		}
	}
}