﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ProductMaster : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!Page.IsPostBack)
        {
            ShowProduct();
        }

    }

    public void ShowProduct()
    {
        ClsProduct.SelectAllProduct(Gridview1);
    }

	protected void btnEdit_Click(object sender, EventArgs e)
	{

		LinkButton lnkbtn = (LinkButton)sender;
		int ID = Convert.ToInt32(lnkbtn.CommandArgument);
		Response.Redirect("AddProductMaster.aspx?PID=" + ID);
	}

	protected void btnDelete_Click(object sender, EventArgs e)
	{
		LinkButton lnkbtn = (LinkButton)sender;
		int ID = Convert.ToInt32(lnkbtn.CommandArgument);

		tbl_Product objsource = new tbl_Product();
		objsource.WhereClause = "PID=" + ID;
		objsource.Delete();
	}

	protected void btnadd_Click(object sender, EventArgs e)
	{
		Response.Redirect("AddProductMaster.aspx");
	}
}