﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddAppointment : System.Web.UI.Page
{
	protected void Page_PreInit(Object sender, EventArgs e)
	{
		ClsProj.GetMasterPage(this);

	}

    String strleadname = "";
    int StatusID = 0;
    int LeadID = 0;
    String strStatusName = "";
	string strcontact = "";
	protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {

			DateTime d = new DateTime();
			d = DateTime.Now;

			txtcalldate.Text = DateTime.Now.ToString("yyyy-MM-dd");
			txtcalltime.Text = d.ToString("HH:mm:ss");

			if (Session["UserID"] != null)
            {
                if (Session["UserName"] != null)
                {
                    if (Session["UserType"] != null)
                    {
                        bindusertype();
						BindLeadStage();
					}
                }
            }
        }

    }
	public void Leadname()
	{
		if (Request.QueryString["ld"] != null)
		{
			LeadID = Convert.ToInt32(Request.QueryString["ld"]);
		}
		lblleadname.Text = ClsLead.GetLeadName(LeadID);
		strleadname = ClsLead.GetLeadName(LeadID);

	}

	public void StatusName()
	{
		if (Request.QueryString["ls"] != null)
		{
			StatusID = clsPrecaution.GetInt_Zero(Request.QueryString["ls"]);
		}
		strStatusName = ClsLead.GetStatusName(StatusID);

	}

	protected void btnUpdate_Click(object sender, EventArgs e)
    {
      
        int StatusID = 0;
        if (Request.QueryString["ld"] != null)
        {
            LeadID = Convert.ToInt32(Request.QueryString["ld"]);
        }
        if (Request.QueryString["ls"] != null)
        {
            StatusID = clsPrecaution.GetInt_Zero(Request.QueryString["ls"]);
        }

        string LeadName = "";
        int sourceId = 0;
        string sourceName = "";
		strStatusName = ClsLead.GetStatusName(StatusID);


		tbl_Lead obj = new tbl_Lead();
        obj.WhereClause = "LeadID=" + LeadID;
        DataTable dtbl = obj.Select();
        if (dtbl.Rows.Count > 0)
        {
            LeadName = clsPrecaution.GetStr_Null(dtbl.Rows[0]["LeadName"]);
            sourceId = clsPrecaution.GetInt_Zero(dtbl.Rows[0]["SourceID"]);
            sourceName = clsPrecaution.GetStr_Empty(dtbl.Rows[0]["SourceName"]);
			strcontact = clsPrecaution.GetStr_Empty(dtbl.Rows[0]["Contact1"]);

		}


        string strlcaldate = clsPrecaution.GetStr_Null(txtcalldate.Text);
        String strcaltime = clsPrecaution.GetStr_Null(txtcalltime.Text);
        string straptdate = clsPrecaution.GetStr_Null(txtaptdate.Text);
        string strapttime = clsPrecaution.GetStr_Null(txtapttime.Text);
        string straddress = clsPrecaution.GetStr_Null(txtaddress.Text);
        string strproduct = clsPrecaution.GetStr_Null(txtproduct.Text);
        String strremark = clsPrecaution.GetStr_Null(txtremark.Text);
        int saletype = clsPrecaution.GetInt_Zero(ddlusertype.SelectedItem.Value);
        String saleusertype = clsPrecaution.GetStr_Null(ddlusertype.SelectedItem.Text);
        int salesuser = clsPrecaution.GetInt_Zero(ddluser.SelectedItem.Value);
        String saleuser = clsPrecaution.GetStr_Null(ddluser.SelectedItem.Text);
		int intlstageid = clsPrecaution.GetInt_Zero(ddlstage.SelectedValue);
		string strstagename = clsPrecaution.GetStr_Empty(ddlstage.SelectedItem.Text);

        int userid = clsPrecaution.GetInt_Zero(Session["UserID"].ToString());
        string strUserName = clsPrecaution.GetStr_Null(Session["UserName"].ToString());
		


        string strleadstatusname = "New Sales";

        int intstatus = 4;
        clsLeadLog.InsertLeadDeatilsAddAppointment(LeadID, strleadname, StatusID, strStatusName, strcontact, straddress, strproduct, strlcaldate, strcaltime, straptdate, strapttime, strremark, intlstageid, strstagename,"");
        ClsLead.GetLeadDetailsforAppointment(LeadID, StatusID, strStatusName, strlcaldate, strcaltime, straptdate, strapttime, straddress, strproduct, strremark, intlstageid, strstagename,"");

        //ClsSalesTeam.AddSalesTeam(salesuser, saletype, userid, LeadID, strcaltime, strcaltime, straddress, strproduct, strremark, 1, straptdate, strapttime);
        ClsSalesTeam.AddSalesTeam(0,"" , salesuser, saleuser, saletype, userid, strUserName, LeadID, LeadName,sourceId,sourceName, strlcaldate, strcaltime, straddress, strproduct, strremark, intstatus, strleadstatusname, straptdate, strapttime, intlstageid, strstagename, "");
       

        Response.Redirect("Appointments.aspx");

    }

    
    public void bindusertype()
    {
        ClsUser.bindUserType(ddlusertype);
    }


    protected void ddlusertype_SelectedIndexChanged(object sender, EventArgs e)
    {
        int ddltypeid = clsPrecaution.GetInt_Zero(ddlusertype.SelectedItem.Value);

        ClsUser.binduser(ddluser, ddltypeid);
    }
	public void BindLeadStage()
	{
		ClsLeadStageMaster.StageDropdown(ddlstage);
	}
}