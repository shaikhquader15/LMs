﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddProductMaster : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			EditSaleStatus();
		}
	}

	protected void btnsave_Click(object sender, EventArgs e)
	{

		string strsales = clsPrecaution.GetStr_Empty(txtproduct.Text);
		string strtype = clsPrecaution.GetStr_Empty(txttype.Text);
		string strdesc = clsPrecaution.GetStr_Empty(txtdescrtin.Text);
		string stramount = clsPrecaution.GetStr_Empty(txtamount.Text);
		string strtax = clsPrecaution.GetStr_Empty(txttax.Text);
		string strlink = clsPrecaution.GetStr_Empty(txtlink.Text);
		//bool blnactive=clsPrecaution.IsStringValid

		if (btnsave.Text == "Save")
		{
			ClsProduct.AddProduct(strsales,strtype,strdesc,stramount,strtax,strlink);
			Response.Redirect("ProductMaster.aspx");
		}
		else
		{
			if (Request.QueryString["PID"] != null)
			{
				int pid = clsPrecaution.GetInt_Zero(Request.QueryString["PID"]);
				ClsProduct.UpdateProduct(pid, strsales, strtype, strdesc, stramount, strtax, strlink);
				Response.Redirect("ProductMaster.aspx");
			}
		}

	}
	public void EditSaleStatus()
	{
		tbl_Product objedit = new tbl_Product();
		int pid = clsPrecaution.GetInt_Zero(Request.QueryString["PID"]);
		objedit.WhereClause = "PID=" + pid;
		DataTable dtlead = objedit.Select();


		if (dtlead.Rows.Count > 0)
		{
			txtproduct.Text = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["ProdName"]);
			txttype.Text = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["Type"]);
			txtdescrtin.Text = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["ProdDescrip"]);
			txtamount.Text = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["ProdAmount"]);
			txttax.Text = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["ProdTax"]);
			txtlink.Text = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["ProdLink"]);


			btnsave.Text = "Update";

		}
	}
}