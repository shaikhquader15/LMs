﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Data;

public partial class AddNewUser : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!Page.IsPostBack)
        {
            bindUserType();
			EditUser();

		}
       
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
		int userid = clsPrecaution.GetInt_Zero(Request.QueryString["UserID"]);
        String struser = clsPrecaution.GetStr_Null(txtuser.Text);
        string strpass = clsPrecaution.GetStr_Null(txtpassword.Text);
        string stremail = clsPrecaution.GetStr_Null(txtemail.Text);
        string straddress = clsPrecaution.GetStr_Null(txtaddress.Text);
        string strcontact = clsPrecaution.GetStr_Null(txtcontact.Text);
        int usertype = clsPrecaution.GetInt_Zero(ddltypeuser.SelectedItem.Value);


        string strDate = Convert.ToString(DateTime.Now);
        string Date = clsPrecaution.GetMMDD_Current(strDate);
		if (btnAdd.Text == "Submit")
		{
			ClsUser.AddUser(struser, strpass, stremail, strcontact, straddress, Date, usertype);
		}
		else
		{
			ClsUser.UpdateUser(userid, struser, strpass, stremail, strcontact, straddress, Date, usertype);
		}
        Response.Redirect("ManageUsers.aspx");
    }

    public void bindUserType()
    {
        ClsUser.bindUserType(ddltypeuser);
    }

	public void EditUser()
	{
		tbl_User objuser = new tbl_User();
		int userid = clsPrecaution.GetInt_Zero(Request.QueryString["UserID"]);
		objuser.WhereClause = "UserID=" + userid;
		DataTable dt = objuser.Select();

		if (dt.Rows.Count > 0)
		{
			txtuser.Text = clsPrecaution.GetStr_Empty(dt.Rows[0]["UserName"]);
			txtpassword.Text = clsPrecaution.GetStr_Empty(dt.Rows[0]["Password"]);
			txtemail.Text = clsPrecaution.GetStr_Empty(dt.Rows[0]["EmailAddress"]);
			txtaddress.Text = clsPrecaution.GetStr_Empty(dt.Rows[0]["Address"]);
			txtcontact.Text = clsPrecaution.GetStr_Empty(dt.Rows[0]["Contact"]);
			ddltypeuser.Text = clsPrecaution.GetStr_Empty(dt.Rows[0]["UserType"]);
			btnAdd.Text = "Update";
		}
	}
}