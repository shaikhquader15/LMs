﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin : System.Web.UI.MasterPage
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			if (Session["UserID"] != null)
			{

				int UserID = clsPrecaution.GetInt_Zero(Session["UserID"]);
				//GetRecord();
				//ShowUpcomingCall();
				//int intUpcomingCalls = ClsProj.GetDataValue("tbl_Lead", "UserID=" + UserID + " and ( LStatusID = 0)");
				//lblNot_Totcalls.Text = Convert.ToString(Session["TotalCalls"]);
				//lblNot_FollUp.Text = Convert.ToString(Session["TotalFollowUpCalls"]);
				//lblNot_TotPending.Text = Convert.ToString(Session["TotalPendingCalls"]);
				//lblNot_Totopen.Text = Convert.ToString(Session["TotalOpenCalls"]);
				//lblNot_TotInvalid.Text = Convert.ToString(Session["TotalInvalidCalls"]);
				//lblNot_TotConverted.Text = Convert.ToString(Session["TotalConvertedCalls"]);
				plcleadmenus.Controls.Add(new LiteralControl(LeadMenu()));
				// = Convert.ToString(intUpcomingCalls);

				if (Session["UserName"] != null)
				{
					lblUser.Text = Session["UserName"].ToString();
					lblLogUser.Text = Session["UserName"].ToString();
					
					showImage();
				}

			}
		}
	}

	public string LeadMenu()
	{
		StringBuilder sb = new StringBuilder();

		tbl_Status objst = new tbl_Status();
		objst.OrderBy = "StatusID";
		DataTable dt = objst.Select();
		foreach (DataRow dr in dt.Rows)
		{
			sb.Append(" <li><a href=\"FollowUp.aspx?s="+dr["StatusID"]+"\">"+dr["StatusName"]+"</a></li>"); 
		}
		return sb.ToString();
	}

	public void showImage()
	{
		int UserID = clsPrecaution.GetInt_Zero(Session["UserID"].ToString());

		tbl_User obj = new tbl_User();
		obj.WhereClause = "UserID=" + UserID;
		DataTable dtbl = obj.Select();
		if (dtbl.Rows.Count > 0)
		{
			String strPath = clsPrecaution.GetStr_Null(dtbl.Rows[0]["ProfImage"]);
			imgprod.ImageUrl = strPath;
		}
	}
}
