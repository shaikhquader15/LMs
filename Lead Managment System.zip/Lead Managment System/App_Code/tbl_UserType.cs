﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;

/// <summary>
/// Summary description for tbl_UserType
/// </summary>
public class tbl_UserType:StarIUD
{
    public tbl_UserType()
    {
        base.TableName = "tbl_UserType";
        base.IdentityColumn = "UserType";
    }
}