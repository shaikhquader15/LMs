﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using Component;

/// <summary>
/// Summary description for tbl_Stage
/// </summary>
public class tbl_EmailFormat : StarIUD
{
	public tbl_EmailFormat()
	{
		base.TableName = "tbl_EmailFormat";
		base.IdentityColumn = "StageID";
	}
}