﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Data;
using System.Web.UI.WebControls;
/// <summary>
/// Summary description for ClsState
/// </summary>
public class ClsState
{
	public ClsState()
	{
		
	}

	public static void Bindstate(DropDownList ddlstate)
	{
		tblStates objsource = new tblStates();
		objsource.OrderBy = "StateID";
		DataTable dtbl = objsource.Select();
		ddlstate.DataSource = dtbl;
		ddlstate.DataTextField = "Title";
		ddlstate.DataValueField = "StId";
		ddlstate.DataBind();
		ddlstate.Items.Insert(0, "Select State");
	}
}