﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;
/// <summary>
/// Summary description for tbl_ExternalFieldLeadMapping
/// </summary>
public class tbl_ExternalFieldLeadMapping:StarIUD
{
	public tbl_ExternalFieldLeadMapping()
	{
		base.TableName = "tbl_ExternalFieldLeadMapping";
		base.IdentityColumn = "EFLeadID";
	}
}