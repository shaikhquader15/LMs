﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;
using System.Collections;
using System.Data;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for ClsProduct
/// </summary>
public class ClsProduct
{
	public ClsProduct()
	{
		//
		// TODO: Add constructor logic here
		//
	}

	public static int AddProduct(string ProdName, string Type, string ProdDescrip,string ProdAmount,string ProdTax, string ProdLink)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("ProdName", ProdName);
		hstbl.Add("Type", Type);
		hstbl.Add("ProdDescrip", ProdDescrip);
		hstbl.Add("ProdAmount", ProdAmount);
		hstbl.Add("ProdTax", ProdTax);
		hstbl.Add("ProdLink", ProdLink);
		//hstbl.Add("IsActive", IsActive);

		tbl_Product Addproduct = new tbl_Product();
		Addproduct.Data = hstbl;
		int result = Addproduct.Add();
		return result;
	}

	public static bool UpdateProduct(int PID,string ProdName, string Type, string ProdDescrip, string ProdAmount, string ProdTax, string ProdLink)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("ProdName", ProdName);
		hstbl.Add("Type", Type);
		hstbl.Add("ProdDescrip", ProdDescrip);
		hstbl.Add("ProdAmount", ProdAmount);
		hstbl.Add("ProdTax", ProdTax);
		hstbl.Add("ProdLink", ProdLink);
		//hstbl.Add("IsActive", IsActive);

		tbl_Product updateproduct = new tbl_Product();
		updateproduct.Data = hstbl;
		updateproduct.WhereClause = "PID=" + PID;
		bool result = updateproduct.Update();
		return result;
	}

	public static bool DeleteProduct(int PID)
	{
		tbl_Product delproduct = new tbl_Product();
		delproduct.WhereClause = "PID=" + PID;
		bool result = delproduct.Delete();
		return result;

	}


	public static void SelectProduct(int PID)
	{
		tbl_Product seldata = new tbl_Product();
		DataTable dtbl = new DataTable();
		seldata.WhereClause = "PID=" + PID;
		dtbl = seldata.Select();
		//return result;
	}



	public static void SelectAllProduct(GridView gridview)
	{
		tbl_Product seldata = new tbl_Product();
		DataTable dtbl = new DataTable();
		dtbl = seldata.Select();
		gridview.DataSource = dtbl;
		gridview.DataBind();
		//return gridview;

	}

















}