﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;

/// <summary>
/// Summary description for tbl_Log
/// </summary>
public class tbl_LeadLog:StarIUD
{
    public tbl_LeadLog()
    {
        base.TableName = "tbl_LeadLog";
        base.IdentityColumn = "LogID";
    }
}