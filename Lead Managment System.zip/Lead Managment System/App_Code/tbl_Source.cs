﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;

/// <summary>
/// Summary description for tbl_Source
/// </summary>
public class tbl_Source: StarIUD
{
	public tbl_Source()
	{
		base.TableName = "tbl_Source";
		base.IdentityColumn = "SourceID";
	}
}