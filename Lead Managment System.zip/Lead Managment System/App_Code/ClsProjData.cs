﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;
using System.Collections;
using System.Data;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for ClsProjData
/// </summary>
public class ClsProjData
{
	public ClsProjData()
	{
		
	}



	public static int AddData(string LeadName, string Type, string Email1, string Email2, string Contact1, string Contact2, string Landline1, string Landline2, string Address1, string Address2, string Pincode, string City, string State, string Country)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("LeadName", LeadName);
		hstbl.Add("Type", Type);
		hstbl.Add("Email1", Email1);
		hstbl.Add("Email2", Email2);
		hstbl.Add("Contact1", Contact1);
		hstbl.Add("Contact2", Contact2);
		hstbl.Add("Landline1", Landline1);
		hstbl.Add("Landline2", Landline2);
		hstbl.Add("Address1", Address1);
		hstbl.Add("Address2", Address2);
		hstbl.Add("Pincode", Pincode);
		hstbl.Add("City", City);
		hstbl.Add("State", State);
		hstbl.Add("Country", Country);


		tbl_Data tbdata = new tbl_Data();
		tbdata.Data = hstbl;
		int result=tbdata.Add();
		return result;
	}


	public static bool UpdateData(int dataID, string LeadName, string Type, string Email1, string Email2, string Contact1, string Contact2, string Landline1, string Landline2, string Address1, string Address2, string Pincode, string City, string State, string Country)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("LeadName", LeadName);
		hstbl.Add("Type", Type);
		hstbl.Add("Email1", Email1);
		hstbl.Add("Email2", Email2);
		hstbl.Add("Contact1", Contact1);
		hstbl.Add("Contact2", Contact2);
		hstbl.Add("Landline1", Landline1);
		hstbl.Add("Landline2", Landline2);
		hstbl.Add("Address1", Address1);
		hstbl.Add("Address2", Address2);
		hstbl.Add("Pincode", Pincode);
		hstbl.Add("City", City);
		hstbl.Add("State", State);
		hstbl.Add("Country", Country);


		tbl_Data tbdata = new tbl_Data();
		tbdata.Data = hstbl;
		tbdata.WhereClause = "dataID=" + dataID;
		bool result = tbdata.Update();
		return result;
	}

	public static bool DeleteData(int dataID)
	{
		tbl_Data deldata = new tbl_Data();
		deldata.WhereClause = "dataID=" + dataID;
		bool result = deldata.Delete();
		return result;
	}

	public static void SelectData(int dataID)
	{
		tbl_Data seldata = new tbl_Data();		
		DataTable dtbl = new DataTable();
		seldata.WhereClause = "dataID=" + dataID;
		dtbl = seldata.Select();
		//return result;
	}


	public static void SelectData(GridView gridview, DataTable dtbl)
	{
		tbl_Data seldata = new tbl_Data();
		//DataTable dtbl = new DataTable();
		dtbl = seldata.Select();
		gridview.DataSource = dtbl;
		gridview.DataBind();
		//return gridview;

	}






































}