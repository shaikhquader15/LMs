﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for ClsData
/// </summary>
public class ClsData
{
    public ClsData()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public static bool UpdateLeads(int dataID, int LMID, String LMName, string LeadName, string Type, string Email1, int UserType, string Email2, string Contact1, string Contact2,
       string Landline1, string Landline2, string Address1, string Address2, string Pincode, string City, string State, string Country, int SourceID, String SourceName)
    {
        Hashtable hstbl = new Hashtable();
        //hstbl.Add("UserID", UserID);
        hstbl.Add("LMID", LMID);
        hstbl.Add("LMName", LMName);
        //hstbl.Add("UserName", UserName);
        hstbl.Add("LeadName", LeadName);
        hstbl.Add("Type", Type);
        hstbl.Add("Email1", Email1);
        hstbl.Add("Email2", Email2);
        hstbl.Add("Contact1", Contact1);
        hstbl.Add("Contact2", Contact2);
        hstbl.Add("Landline1", Landline1);
        hstbl.Add("Landline2", Landline2);
        hstbl.Add("Address1", Address1);
        hstbl.Add("Address2", Address2);
        hstbl.Add("Pincode", Pincode);
        hstbl.Add("City", City);
        hstbl.Add("State", State);
        hstbl.Add("Country", Country);  
        hstbl.Add("SourceID", SourceID);
        hstbl.Add("SourceName", SourceName);
        hstbl.Add("Flag", 1);
      

        tbl_Data tblead = new tbl_Data();
        tblead.Data = hstbl;
        tblead.WhereClause = "dataID=" + dataID;
        bool result = tblead.Update();
        return result;

    }

}