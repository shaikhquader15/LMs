﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;
using System.Collections;
using System.Data;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for ClsSalesStatus
/// </summary>
public class ClsSalesStatus
{
	public ClsSalesStatus()
	{
		//
		// TODO: Add constructor logic here
		//
	}


	public static int AddSalesStatus(string SstatusName)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("SstatusName", SstatusName);

		tbl_SaleStatus addSalesStatus = new tbl_SaleStatus();
		addSalesStatus.Data = hstbl;
		int result = addSalesStatus.Add();
		return result;
	}

	public static void BindSaleStatus(DropDownList ddl)
	{
		tbl_SaleStatus objLeadstatus = new tbl_SaleStatus();
		DataTable dtbl = objLeadstatus.Select();
		ddl.DataSource = dtbl;
		ddl.DataTextField = "SstatusName";
		ddl.DataValueField = "SstatusID";
		ddl.DataBind();
		ddl.Items.Insert(0, "Select Status");

	}

	public static bool UpdateSalesStatus(int SstatusID, string SstatusName)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("SstatusName", SstatusName);

		tbl_SaleStatus updateSalesStatus = new tbl_SaleStatus();
		updateSalesStatus.Data = hstbl;
		updateSalesStatus.WhereClause = "SstatusID=" + SstatusID;
		bool result = updateSalesStatus.Update();
		return result;
	}


	public static bool DeleteSalesStatus(int SstatusID, string SstatusName)
	{
		tbl_SaleStatus delSalesStatus = new tbl_SaleStatus();
		delSalesStatus.WhereClause = "SstatusID=" + SstatusID;
		bool result = delSalesStatus.Delete();
		return result;
	}




	public static void SelectData(int SstatusID)
	{
		tbl_SaleStatus seldata = new tbl_SaleStatus();
		DataTable dtbl = new DataTable();
		seldata.WhereClause = "SstatusID=" + SstatusID;
		dtbl = seldata.Select();
		//return result;
	}



	public static void SelectAllLeadStatus(GridView gridview)
	{
		tbl_SaleStatus seldata = new tbl_SaleStatus();
        seldata.OrderBy = "SstatusID";
        DataTable dtbl = new DataTable();
        dtbl = seldata.Select();
		gridview.DataSource = dtbl;
		gridview.DataBind();
		//return gridview;

	}















}