﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Data;
using System.Web.UI.WebControls;
using Component;

/// <summary>
/// Summary description for ClsSalesStageMaster
/// </summary>
public class ClsSalesStageMaster
{
	public ClsSalesStageMaster()
	{
		//
		// TODO: Add constructor logic here
		//
	}

}