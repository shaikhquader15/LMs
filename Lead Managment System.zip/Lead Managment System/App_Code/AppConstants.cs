﻿namespace Component
{
   
    using System;
    using System.Configuration;
    using System.IO;
    using System.Reflection;
    using System.Configuration;

    using System.Data.SqlClient;

    public static class AppConstants
    {
        private static string _GlobalCompanyId = "";

        private static string GetDynamicPath()
        {
            return Path.GetDirectoryName(Assembly.GetExecutingAssembly().GetName().CodeBase).Replace(@"file:\", "");
        }

        public static string AppPath
        {
            get
            {
                string str = GetDynamicPath() + @"\";
                if (str != "-1")
                {
                    return str;
                }
                return null;
            }
        }

        public static string AppPathMyComp
        {
            get
            {
                string str = GetDynamicPath() + @"\";
                if (str != "-1")
                {
                    return str;
                }
                return null;
            }
        }

        public static string CompConnectionString
        {
            get
            {
                string str = GetDynamicPath() + @"\";
                if (str != "-1")
                {
                    return str;
                }
                return null;
            }
        }

        public static string CompDBPath
        {
            get
            {
                string str = GetDynamicPath() + @"\";
                if (str != "-1")
                {
                    return str;
                }
                return null;
            }
        }

        public static string ConnectionString
        {
            get
            {
                string strValue = ConfigurationSettings.AppSettings["connectionstring"];
               // strValue = clsEncriptDecript.DecryptValue(strValue);

               // string strValue = System.Configuration.ConfigurationSettings.AppSettings["connectionstring"];
                //strValue = clsEncriptDecript.DecryptValue(strValue);
                if (strValue != "-1")
                {
                    return strValue;
                }
                return null;
            }
        }

        public static string DBPath
        {
            get
            {
                string str = GetDynamicPath() + @"\DBDetails\";
                if (str != "-1")
                {
                    return str;
                }
                return null;
            }
        }

        public static string DBProvider
        {
            get
            {
                return "Microsoft.Jet.OLEDB.4.0";
            }
        }

        public static int ExpireDays
        {
            get
            {
                return 0;
            }
        }

        public static string GlobalCompanyId
        {
            get
            {
                return _GlobalCompanyId;
            }
            set
            {
                if (value == "")
                {
                    _GlobalCompanyId = "";
                }
                else
                {
                    _GlobalCompanyId = value;
                }
            }
        }

        public static bool IsSQL
        {
            get
            {
                //return Convert.ToBoolean(ConfigurationSettings.AppSettings["IsSQL"]);

                //return Convert.ToBoolean(ConfigurationSettings.GetConfig["IsSQL"]);

                return true; //Convert.ToBoolean(System.Configuration.ConfigurationSettings.AppSettings["IsSQL"]); 
            }
        }

        public static double Opacity
        {
            get
            {
                return 90.5;
            }
        }

        public static string TemplatePath
        {
            get
            {
                return (AppPath + "/Templates/");
            }
        }
    }
}

