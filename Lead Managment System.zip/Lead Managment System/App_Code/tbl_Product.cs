﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;

/// <summary>
/// Summary description for tbl_Product
/// </summary>
public class tbl_Product: StarIUD
{
	public tbl_Product()
	{
		base.TableName = "tbl_Product";
		base.IdentityColumn = "PID";
	}
}