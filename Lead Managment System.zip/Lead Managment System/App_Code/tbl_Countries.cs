﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;

/// <summary>
/// Summary description for tbl_Countries
/// </summary>
public class tbl_Countries: StarIUD
{
	public tbl_Countries()
	{
		base.TableName = "tbl_Countries";
		base.IdentityColumn = "id";
	}
}