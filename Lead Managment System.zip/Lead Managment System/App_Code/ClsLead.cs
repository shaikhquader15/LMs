﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;
using System.Collections;
using System.Data;
using System.Web.UI.WebControls;
/// <summary>
/// Summary description for ClsLead
/// </summary>
public class ClsLead
{
	public ClsLead()
	{
		//
		// TODO: Add constructor logic here
		//
	}

	public static string GetStatusName(int StatusID)
	{
		string strstatusname = "";
		tbl_LeadStatus objln = new tbl_LeadStatus();
		objln.WhereClause = "LStatusID=" + StatusID;
		DataTable dtbl = objln.Select();
		if (dtbl.Rows.Count > 0)
		{
			strstatusname = clsPrecaution.GetStr_Empty(dtbl.Rows[0]["StatusName"]);
			string result = strstatusname;
		}

		return strstatusname;
	}

	public static int AddLeads(int UserID, int LMID, String LMName, String UserName, string LeadName, string Type, string Email1, string Email2, string Contact1, int UserType, string Contact2, string Landline1, string Landline2, string Address1, string Address2, string Pincode, string City, string State,
		  string Country, int LStatusID, string LStatusName, string AppointmentDate, string AppointmentTime, string LastCallDate, string LastCallTime,
		  string NextCallDate, string NextCallTime, string Remark, int SourceID, String SourceName, string Product, string Amount, String Address,
		  int StateId, int CityId, int LStageID, string LStageName, string LPercentage, int IsDelete, string SRemark, string LRemark)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("UserID", UserID);
		hstbl.Add("LMID", LMID);
		hstbl.Add("LMName", LMName);
		hstbl.Add("UserName", UserName);
		hstbl.Add("LeadName", LeadName);
		hstbl.Add("Type", Type);
		hstbl.Add("Email1", Email1);
		hstbl.Add("Email2", Email2);
		hstbl.Add("Contact1", Contact1);
		hstbl.Add("Contact2", Contact2);
		hstbl.Add("Landline1", Landline1);
		hstbl.Add("Landline2", Landline2);
		hstbl.Add("Address1", Address1);
		hstbl.Add("Address2", Address2);
		hstbl.Add("Pincode", Pincode);
		hstbl.Add("City", City);
		hstbl.Add("State", State);
		hstbl.Add("Country", Country);
		hstbl.Add("LStatusID", LStatusID);
		hstbl.Add("LStatusName", LStatusName);
		hstbl.Add("AppointmentDate", AppointmentDate);
		hstbl.Add("AppointmentTime", AppointmentTime);
		hstbl.Add("LastCallDate", LastCallDate);
		hstbl.Add("LastCallTime", LastCallTime);
		hstbl.Add("NextCallDate", NextCallDate);
		hstbl.Add("NextCallTime", NextCallTime);
		hstbl.Add("Remark", Remark);
		hstbl.Add("SourceID", SourceID);
		hstbl.Add("SourceName", SourceName);
		hstbl.Add("Product", Product);
		hstbl.Add("Amount", Amount);
		hstbl.Add("UserType", UserType);
		hstbl.Add("Address", Address);
		hstbl.Add("StateId", StateId);
		hstbl.Add("CityId", CityId);
		hstbl.Add("LStageID", LStageID);
		hstbl.Add("LStageName", LStageName);
		hstbl.Add("LPercentage", LPercentage);
		hstbl.Add("IsDelete", IsDelete);
		hstbl.Add("ShortRemark", SRemark);
		hstbl.Add("LongRemark", LRemark);




		tbl_Lead tblead = new tbl_Lead();

		tblead.Data = hstbl;
		int result = tblead.Add();
		return result;

	}


	public static int AddExecuLeads(int UserID, int LMID, string LMName, String UserName, string LeadName, string Type, string Email1, string Email2,
		string Contact1, int UserType, string Contact2, string Landline1, string Landline2, string Address1, string Address2, string Pincode,
		string City, string State, string Country, int LStatusID, string LStatusName, string AppointmentDate, string AppointmentTime,
		string LastCallDate, string LastCallTime, string NextCallDate, string NextCallTime, string Remark, int SourceID,
		String SourceName, string Product, string Amount, String Address, int StateId, int CityId, int LStageID, string LStageName,
		string LPercentage, int IsDelete)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("UserID", UserID);
		hstbl.Add("LMID", LMID);
		hstbl.Add("LMName", LMName);
		hstbl.Add("UserName", UserName);
		hstbl.Add("LeadName", LeadName);
		hstbl.Add("Type", Type);
		hstbl.Add("Email1", Email1);
		hstbl.Add("Email2", Email2);
		hstbl.Add("Contact1", Contact1);
		hstbl.Add("Contact2", Contact2);
		hstbl.Add("Landline1", Landline1);
		hstbl.Add("Landline2", Landline2);
		hstbl.Add("Address1", Address1);
		hstbl.Add("Address2", Address2);
		hstbl.Add("Pincode", Pincode);
		hstbl.Add("City", City);
		hstbl.Add("State", State);
		hstbl.Add("Country", Country);
		hstbl.Add("LStatusID", LStatusID);
		hstbl.Add("LStatusName", LStatusName);
		hstbl.Add("AppointmentDate", AppointmentDate);
		hstbl.Add("AppointmentTime", AppointmentTime);
		hstbl.Add("LastCallDate", LastCallDate);
		hstbl.Add("LastCallTime", LastCallTime);
		hstbl.Add("NextCallDate", NextCallDate);
		hstbl.Add("NextCallTime", NextCallTime);
		hstbl.Add("Remark", Remark);
		hstbl.Add("SourceID", SourceID);
		hstbl.Add("SourceName", SourceName);
		hstbl.Add("Product", Product);
		hstbl.Add("Amount", Amount);
		hstbl.Add("UserType", UserType);
		hstbl.Add("Address", Address);
		hstbl.Add("StateId", StateId);
		hstbl.Add("CityId", CityId);
		hstbl.Add("LStageID", LStageID);
		hstbl.Add("LStageName", LStageName);
		hstbl.Add("LPercentage", LPercentage);
		hstbl.Add("IsDelete", IsDelete);





		tbl_Lead tblead = new tbl_Lead();
		tblead.Data = hstbl;
		int result = tblead.Add();
		return result;

	}



	public static bool UpdateLeads(int LeadID, int LMID, String LMName, int UserID, String UserName, string LeadName, string Type, string Email1, int UserType, string Email2, string Contact1, string Contact2,
		string Landline1, string Landline2, string Address1, string Address2, string Pincode, string City, string State, string Country, int LStatusID, string StatusName,
		string AppointmentDate, string AppointmentTime, string LastCallDate, string LastCallTime, string NextCallDate, string NextCallTime, string Remark, int SourceID, String SourceName, string Product,
		string Amount, String Address, int StateId, int CityId, int LStageID, string LStageName, string LPercentage, string SRemark, string LRemark)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("UserID", UserID);
		hstbl.Add("LMID", LMID);
		hstbl.Add("LMName", LMName);
		hstbl.Add("UserName", UserName);
		hstbl.Add("LeadName", LeadName);
		hstbl.Add("Type", Type);
		hstbl.Add("Email1", Email1);
		hstbl.Add("Email2", Email2);
		hstbl.Add("Contact1", Contact1);
		hstbl.Add("Contact2", Contact2);
		hstbl.Add("Landline1", Landline1);
		hstbl.Add("Landline2", Landline2);
		hstbl.Add("Address1", Address1);
		hstbl.Add("Address2", Address2);
		hstbl.Add("Pincode", Pincode);
		hstbl.Add("City", City);
		hstbl.Add("State", State);
		hstbl.Add("Country", Country);
		hstbl.Add("LStatusID", LStatusID);
		hstbl.Add("LStatusName", StatusName);
		hstbl.Add("AppointmentDate", AppointmentDate);
		hstbl.Add("AppointmentTime", AppointmentTime);
		hstbl.Add("LastCallDate", LastCallDate);
		hstbl.Add("LastCallTime", LastCallTime);
		hstbl.Add("NextCallDate", NextCallDate);
		hstbl.Add("NextCallTime", NextCallTime);
		hstbl.Add("Remark", Remark);
		hstbl.Add("SourceID", SourceID);
		hstbl.Add("SourceName", SourceName);
		hstbl.Add("Product", Product);
		hstbl.Add("Amount", Amount);
		hstbl.Add("UserType", UserType);
		hstbl.Add("Address", Address);
		hstbl.Add("StateId", StateId);
		hstbl.Add("CityId", CityId);
		hstbl.Add("LStageID", LStageID);
		hstbl.Add("LStageName", LStageName);
		hstbl.Add("LPercentage", LPercentage);
		hstbl.Add("ShortRemark", SRemark);
		hstbl.Add("LongRemark", LRemark);


		tbl_Lead tblead = new tbl_Lead();
		tblead.Data = hstbl;
		tblead.WhereClause = "LeadID=" + LeadID;
		bool result = tblead.Update();
		return result;

	}

	public static bool DeleteLead(int LeadID)
	{
		tbl_Lead dellead = new tbl_Lead();
		dellead.WhereClause = "LeadID=" + LeadID;
		bool result = dellead.Delete();
		return result;
	}

	public static string GetLeadName(int LeadID)
	{
		string strleadname = "";
		tbl_Lead objln = new tbl_Lead();
		objln.WhereClause = "LeadID=" + LeadID;
		DataTable dtbl = objln.Select();
		if (dtbl.Rows.Count > 0)
		{
			strleadname = clsPrecaution.GetStr_Empty(dtbl.Rows[0]["LeadName"]);
			string result = strleadname;
		}

		return strleadname;
	}


	public static void SelectLead(int LeadID)
	{
		tbl_Lead seldata = new tbl_Lead();
		DataTable dtbl = new DataTable();
		seldata.WhereClause = "LeadID=" + LeadID;
		dtbl = seldata.Select();
		//return result;
	}



	public static void SelectAllLead(GridView gridview)
	{
		tbl_Lead seldata = new tbl_Lead();
		DataTable dtbl = new DataTable();
		dtbl = seldata.Select();
		gridview.DataSource = dtbl;
		gridview.DataBind();
		//return gridview;

	}

	public static void BindLeadStatus(DropDownList ddl)
	{
		tbl_LeadStatus objLeadstatus = new tbl_LeadStatus();
		DataTable dtbl = objLeadstatus.Select();
		ddl.DataSource = dtbl;
		ddl.DataTextField = "StatusName";
		ddl.DataValueField = "LStatusID";
		ddl.DataBind();
		ddl.Items.Insert(0, "Select Status");
	}

	public static void GetLeadDetailsforAppointment(int LeadID, int StatusID, string StatusName, String strlcaldate, String strcaltime, String strapdate, String straptime, String straddress, String strprod, String strremark, int LStageID, string LStageName, string LPercentage)
	{
		tbl_Lead obj = new tbl_Lead();
		obj.WhereClause = "LeadID=" + LeadID;
		DataTable dtlead = obj.Select();
		if (dtlead.Rows.Count > 0)
		{
			int MID = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["LMID"]);
			String strLMName = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["LMName"]);
			int intuserid = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["UserID"]);
			String strUsername = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["UserName"]);
			int intusertypeid = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["UserType"]);
			String strLeadname = clsPrecaution.GetStr_Null(dtlead.Rows[0]["LeadName"]);
			string strtype = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Type"]);
			String stremail1 = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Email1"]);
			string stremail2 = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Email2"]);
			String strcontact1 = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Contact1"]);
			String strcontact2 = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Contact2"]);
			String strlandline1 = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Landline1"]);
			String strlandline2 = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Landline2"]);
			String straddress1 = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Address1"]);
			String straddress2 = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Address2"]);
			String strpincode = clsPrecaution.GetStr_Null(dtlead.Rows[0]["PinCode"]);
			String strcity = clsPrecaution.GetStr_Null(dtlead.Rows[0]["City"]);
			String strState = clsPrecaution.GetStr_Null(dtlead.Rows[0]["State"]);
			String strcountry = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Country"]);
			//String strapdate = clsPrecaution.GetStr_Null(dtlead.Rows[0]["AppointmentDate"]);
			//string straptime = clsPrecaution.GetStr_Null(dtlead.Rows[0]["AppointmentTime"]);
			String strncaldate = clsPrecaution.GetStr_Null(dtlead.Rows[0]["NextCallDate"]);
			String strncaltime = clsPrecaution.GetStr_Null(dtlead.Rows[0]["NextCallTime"]);
			int intsourceid = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["SourceID"]);
			string strStatusName = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["SourceName"]);
			//String strprod = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Product"]);
			String stramount = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Amount"]);
			//String straddress = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Address"]);
			int StateId = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["StateId"]);
			int CityId = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["CityId"]);
			string strsremark = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["ShortRemark"]);
			string strlremark = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["LongRemark"]);
			//int stageid = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["LStageID"]);
			//string strstagename = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["LStageName"]);

			ClsLead.UpdateLeads(LeadID, MID, strLMName, intuserid, strUsername, strLeadname, strtype, stremail1, intusertypeid, stremail2, strcontact1, strcontact2, strlandline1, strlandline2, straddress1, straddress2, strpincode, strcity, strState, strcountry, StatusID, StatusName, strapdate, straptime, strlcaldate, strcaltime, strncaldate, strncaltime, strremark, intsourceid, strStatusName, strprod, stramount, straddress, StateId, CityId, LStageID, LStageName, "", strsremark, strlremark);

		}

	}


	public static void GetLeadDetailsforAddCallBack(int LeadID, int StatusID, string StatusName, String strlcaldate, String strcaltime, String strncaldate, String strncaltime, String strremark)
	{
		tbl_Lead obj = new tbl_Lead();
		obj.WhereClause = "LeadID=" + LeadID;
		DataTable dtlead = obj.Select();
		if (dtlead.Rows.Count > 0)
		{
			int MID = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["LMID"]);
			String strLMName = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["LMName"]);
			int intuserid = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["UserID"]);
			String strUsername = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["UserName"]);
			int intusertypeid = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["UserType"]);
			String strLeadname = clsPrecaution.GetStr_Null(dtlead.Rows[0]["LeadName"]);
			string strtype = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Type"]);
			String stremail1 = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Email1"]);
			string stremail2 = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Email2"]);
			String strcontact1 = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Contact1"]);
			String strcontact2 = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Contact2"]);
			String strlandline1 = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Landline1"]);
			String strlandline2 = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Landline2"]);
			String straddress1 = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Address1"]);
			String straddress2 = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Address2"]);
			String strpincode = clsPrecaution.GetStr_Null(dtlead.Rows[0]["PinCode"]);
			String strcity = clsPrecaution.GetStr_Null(dtlead.Rows[0]["City"]);
			String strState = clsPrecaution.GetStr_Null(dtlead.Rows[0]["State"]);
			String strcountry = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Country"]);
			String strapdate = clsPrecaution.GetStr_Null(dtlead.Rows[0]["AppointmentDate"]);
			string straptime = clsPrecaution.GetStr_Null(dtlead.Rows[0]["AppointmentTime"]);
			//String strncaldate = clsPrecaution.GetStr_Null(dtlead.Rows[0]["NextCallDate"]);
			//String strncaltime = clsPrecaution.GetStr_Null(dtlead.Rows[0]["NextCallTime"]);
			int intsourceid = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["SourceID"]);
			string strStatusName = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["SourceName"]);
			String strprod = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Product"]);
			String stramount = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Amount"]);
			String straddress = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Address"]);
			int StateId = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["StateId"]);
			int CityId = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["CityId"]);
			int stageid = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["LStageID"]);
			string strstagename = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["LStageName"]);
			string strsremark = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["ShortRemark"]);
			string strlremark = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["LongRemark"]);

			ClsLead.UpdateLeads(LeadID, MID, strLMName, intuserid, strUsername, strLeadname, strtype, stremail1, intusertypeid, stremail2, strcontact1, strcontact2, strlandline1, strlandline2, straddress1, straddress2, strpincode, strcity, strState, strcountry, StatusID, StatusName, strapdate, straptime, strlcaldate, strcaltime, strncaldate, strncaltime, strremark, intsourceid, strStatusName, strprod, stramount, straddress, StateId, CityId, stageid, strstagename, "", strsremark, strlremark);

		}

	}

	public static void GetLeadDetailsByLeadID(int LeadID, int StatusID, String strlcaldate, String strcaltime, String strremark, int LStageID, string LStageName)
	{
		tbl_Lead obj = new tbl_Lead();
		obj.WhereClause = "LeadID=" + LeadID;
		DataTable dtlead = obj.Select();
		if (dtlead.Rows.Count > 0)
		{
			int MID = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["LMID"]);
			String strLMName = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["LMName"]);
			int intuserid = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["UserID"]);
			String strUsername = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["UserName"]);
			int intusertypeid = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["UserType"]);
			String strLeadname = clsPrecaution.GetStr_Null(dtlead.Rows[0]["LeadName"]);
			string strtype = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Type"]);
			String stremail1 = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Email1"]);
			string stremail2 = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Email2"]);
			String strcontact1 = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Contact1"]);
			String strcontact2 = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Contact2"]);
			String strlandline1 = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Landline1"]);
			String strlandline2 = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Landline2"]);
			String straddress1 = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Address1"]);
			String straddress2 = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Address2"]);
			String strpincode = clsPrecaution.GetStr_Null(dtlead.Rows[0]["PinCode"]);
			String strcity = clsPrecaution.GetStr_Null(dtlead.Rows[0]["City"]);
			String strState = clsPrecaution.GetStr_Null(dtlead.Rows[0]["State"]);
			String strcountry = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Country"]);
			String strapdate = clsPrecaution.GetStr_Null(dtlead.Rows[0]["AppointmentDate"]);
			string straptime = clsPrecaution.GetStr_Null(dtlead.Rows[0]["AppointmentTime"]);
			String strncaldate = clsPrecaution.GetStr_Null(dtlead.Rows[0]["NextCallDate"]);
			String strncaltime = clsPrecaution.GetStr_Null(dtlead.Rows[0]["NextCallTime"]);
			//String strremark = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Remark"]);
			int intsourceid = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["SourceID"]);
			string strStatusName = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["SourceName"]);
			String strprod = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Product"]);
			String stramount = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Amount"]);
			String straddress = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Address"]);
			int StateId = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["StateId"]);
			int CityId = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["CityId"]);
			string strsremark = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["ShortRemark"]);
			string strlremark = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["LongRemark"]);
			//int stageid = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["LStageID"]);
			//string strstagename = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["LStageName"]);

			ClsLead.UpdateLeads(LeadID, MID, strLMName, intuserid, strUsername, strLeadname, strtype, stremail1, intusertypeid, stremail2, strcontact1, strcontact2, strlandline1, strlandline2, straddress1, straddress2, strpincode, strcity, strState, strcountry, StatusID, strStatusName, strapdate, straptime, strlcaldate, strcaltime, strncaldate, strncaltime, strremark, intsourceid, strStatusName, strprod, stramount, straddress, StateId, CityId, LStageID, LStageName, "", strsremark, strlremark);

		}


	}














}