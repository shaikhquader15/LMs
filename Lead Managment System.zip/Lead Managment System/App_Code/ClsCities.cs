﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Data;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for ClsCities
/// </summary>
public class ClsCities
{
	public ClsCities()
	{
		
	}


	public static void BindCity(DropDownList ddlCity, int StateId)
	{
		if (StateId > 0)
		{
			tblCities objcity = new tblCities();
			objcity.OrderBy = "Title";
			objcity.WhereClause = "StateId=" + StateId;
			DataTable dtbl = objcity.Select();
			ddlCity.DataSource = dtbl;
			ddlCity.DataTextField = "Title";
			ddlCity.DataValueField = "CityID";
			ddlCity.DataBind();
			ddlCity.Items.Insert(0, "Select City");
		}
	}


}