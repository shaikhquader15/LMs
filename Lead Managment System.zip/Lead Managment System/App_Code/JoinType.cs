﻿namespace Component
{
    using System;

    public enum JoinType
    {
        INNER_JOIN = 1,
        LEFT_JOIN = 2,
        RIGHT_JOIN = 3
    }
}

