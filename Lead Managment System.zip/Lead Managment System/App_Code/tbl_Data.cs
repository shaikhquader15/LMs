﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;

/// <summary>
/// Summary description for tbl_Data
/// </summary>
public class tbl_Data:StarIUD
{
	public tbl_Data()
	{
		base.TableName = "tbl_Data";
		base.IdentityColumn = "dataID";
	}
}