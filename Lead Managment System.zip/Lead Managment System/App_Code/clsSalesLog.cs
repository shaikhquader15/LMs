﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;
using System.Collections;
using System.Data;

/// <summary>
/// Summary description for clsSalesLog
/// </summary>
public class clsSalesLog
{

    public clsSalesLog()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public static void InsertLeadDeatilsAddSalesAppointment(int LeadID, String LeadName, int StatusID, String StatusName,string Address, 
		string sourcename, String strlcaldate, String strcaltime, String strncaldate, String strncaltime, String strremark)
    {
        Hashtable hstbl = new Hashtable();
        hstbl.Add("LeadID", LeadID);
        hstbl.Add("LeadName", LeadName);
        hstbl.Add("SstatusID", StatusID);
        hstbl.Add("SstatusName", StatusName);
        //hstbl.Add("LStatusName", StatusName);
        hstbl.Add("Address", Address);
        hstbl.Add("SourceName", sourcename);
        hstbl.Add("CallDate", strlcaldate);

		hstbl.Add("CallTime", strcaltime);
        hstbl.Add("AppointmentDate", strncaldate);
        hstbl.Add("AppointmentTime", strncaltime);
        hstbl.Add("Amount", strremark);
		//hstbl.Add("SStageID", SStageID);
		//hstbl.Add("SStageName", SStageName);
		//hstbl.Add("SPercentage", SPercentage);


		tbl_SalesLog obj = new tbl_SalesLog();
        obj.Data = hstbl;
        obj.Add();




    }



}