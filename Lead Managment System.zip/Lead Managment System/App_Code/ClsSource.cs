﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;
using System.Collections;
using System.Data;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for ClsSource
/// </summary>
public class ClsSource
{
	public ClsSource()
	{
		//
		// TODO: Add constructor logic here
		//
	}

	public static int AddSource(string SourceName)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("SourceName", SourceName);

		tbl_Source addsource = new tbl_Source();
		addsource.Data = hstbl;
		int result = addsource.Add();
		return result;
	}



	public static bool UpdateSource(int SourceID,string SourceName)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("SourceName", SourceName);

		tbl_Source addsource = new tbl_Source();
		addsource.Data = hstbl;
		addsource.WhereClause = "SourceID=" + SourceID;
		bool result = addsource.Update();
		return result;
	}



	public static bool UpdateSource(int SourceID)
	{

		tbl_Source delsource = new tbl_Source();
		delsource.WhereClause = "SourceID=" + SourceID;
		bool result = delsource.Delete();
		return result;
	}



	public static void SelectSource(int SourceID)
	{
		tbl_Source seldata = new tbl_Source();
		DataTable dtbl = new DataTable();
		seldata.WhereClause = "SourceID=" + SourceID;
		dtbl = seldata.Select();
		//return result;
	}



	public static void SelectAllSource(GridView gridview)
	{
		tbl_Source seldata = new tbl_Source();
		DataTable dtbl = new DataTable();
		dtbl = seldata.Select();
		gridview.DataSource = dtbl;
		gridview.DataBind();
		//return gridview;

	}

	public static void BindSource(DropDownList ddlsource)
	{
		tbl_Source objsource = new tbl_Source();
		objsource.OrderBy = "SourceID";
		DataTable dtbl = objsource.Select();
		ddlsource.DataSource = dtbl;
		ddlsource.DataTextField = "SourceName";
		ddlsource.DataValueField = "SourceID";
		ddlsource.DataBind();
		ddlsource.Items.Insert(0, "Select Source");
	}




}