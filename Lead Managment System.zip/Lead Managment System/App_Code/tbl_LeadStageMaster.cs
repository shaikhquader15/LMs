﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;

/// <summary>
/// Summary description for tbl_LeadStageMaster
/// </summary>
public class tbl_LeadStageMaster:StarIUD
{
	public tbl_LeadStageMaster()
	{
		base.TableName = "tbl_LeadStageMaster";
		base.IdentityColumn = "LStageID";
	}
}