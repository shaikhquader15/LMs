﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Globalization;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
/// <summary>
/// Summary description for ClsProj
/// </summary>
public class ClsProj
{
	public ClsProj()
	{
		//
		// TODO: Add constructor logic here
		//
	}


	public static Int32 GetDataValue(string TableName, string WhereCond)
	{
		DataTable dtbl = new DataTable();
		string constr = ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString;
		SqlConnection con = new SqlConnection(constr);
		con.Open();
		string strQuery = "SELECT COUNT(*) FROM " + TableName + " where " + WhereCond; // table_name";
		SqlCommand cmd = new SqlCommand(strQuery, con);
		Int32 intValue = (Int32)cmd.ExecuteScalar();
		//SqlDataAdapter sda = new SqlDataAdapter(cmd);
		//sda.Fill(dtbl);
		//con = null;
		return intValue;// dtbl;
	}


	public static DataTable GetCondata(string query)
	{
		DataTable dtbl = new DataTable();
		string constr = ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString;
		SqlConnection con = new SqlConnection(constr);
		con.Open();
		SqlCommand cmd = new SqlCommand(query, con);
		SqlDataAdapter sda = new SqlDataAdapter(cmd);
		sda.Fill(dtbl);
		con = null;
		return dtbl;
	}



	public static string GetMMDD_Current(String RawDate)
	{
		string strValue = DateTime.Now.ToString("yyyy-MM-dd");
		try
		{
			DateTime dtRawDate = DateTime.Parse(RawDate);
			strValue = dtRawDate.ToString("yyyy-MM-dd");
		}
		catch (Exception ex)
		{ }
		return strValue;
	}



	public static int TotalCalls(int Type, int UserID)
	{


		//DataTable dtbl = new DataTable();
		//dtbl = ClsProj.GetCondata(strquery);
		////dtbl = seldata.Select();

		//Gridview1.DataSource = dtbl;
		//Gridview1.DataBind();

		int result = 0;
		//String strquery = "";
		tbl_Lead objlead = new tbl_Lead();
		objlead.WhereClause = "LStatusID=" + Type + "or UserID=" + UserID;
		DataTable dtbl = objlead.Select();
		if (dtbl.Rows.Count > 0)
		{
			result = dtbl.Rows.Count;


		}
		return result;




	}

	


	public static void GetMasterPage(System.Web.UI.Page FrontPage)
	{
		string strusertype = clsPrecaution.GetStr_Null( System.Web.HttpContext.Current.Session["UserType"]);
		if (strusertype == null)
		{
			System.Web.HttpContext.Current.Response.Redirect("Login.aspx",true);
		}

		int UserType = clsPrecaution.GetInt_Zero(strusertype);


		if (UserType == 1)
		{

			FrontPage.MasterPageFile = "Admin.master";
		}
		else if (UserType == 2)
		{

			FrontPage.MasterPageFile = "MasterLM.master";
		}
		else if (UserType == 3)
		{

			FrontPage.MasterPageFile = "MasterSM.master";
		}
		else if (UserType == 4)
		{

			FrontPage.MasterPageFile = "MasterLeadExecutive.master";
		}
		else if (UserType == 5)
		{

			FrontPage.MasterPageFile = "MasterSE.master";
		}
	}
}