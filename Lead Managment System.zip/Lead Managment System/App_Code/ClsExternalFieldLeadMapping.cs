﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Data;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for ClsExternalFieldLeadMapping
/// </summary>
public class ClsExternalFieldLeadMapping
{
	public ClsExternalFieldLeadMapping()
	{
		//
		// TODO: Add constructor logic here
		//
	}

	public static int AddExternalFieldsLeadMapping(string FieldValues,int ExternalID,int LeadID)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("FieldValues", FieldValues);
		hstbl.Add("ExternalID", ExternalID);
		hstbl.Add("LeadID", LeadID);

		tbl_ExternalFieldLeadMapping objfeilds = new tbl_ExternalFieldLeadMapping();
		objfeilds.Data = hstbl;
		int result = objfeilds.Add();
		return result;
	}


	public static bool UpdateExternalFieldsLeadMapping(int EFleadID, string FieldValues, int ExternalID, int LeadID)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("FieldValues", FieldValues);
		hstbl.Add("ExternalID", ExternalID);
		hstbl.Add("LeadID", LeadID);

		tbl_ExternalFieldLeadMapping objfeilds = new tbl_ExternalFieldLeadMapping();
		objfeilds.Data = hstbl;
		objfeilds.WhereClause = "EFleadID=" + EFleadID;
		bool result = objfeilds.Update();
		return result;
	}

	public static void SelectExternalFieldsLeadMapping(int EFleadID)
	{
		tbl_ExternalFieldLeadMapping seldata = new tbl_ExternalFieldLeadMapping();
		DataTable dtbl = new DataTable();
		seldata.WhereClause = "EFleadID=" + EFleadID;
		dtbl = seldata.Select();
		//return result;
	}

	//public static bool DeleteLead(int ExternalID)
	//{
	//	tbl_ExternalFields dellead = new tbl_ExternalFields();
	//	dellead.WhereClause = "ExternalID=" + ExternalID;
	//	bool result = dellead.Delete();
	//	return result;
	//}
}