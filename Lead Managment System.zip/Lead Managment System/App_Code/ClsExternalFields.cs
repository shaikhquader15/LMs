﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Data;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for ClsExternalFields
/// </summary>
public class ClsExternalFields
{
	public ClsExternalFields()
	{
		//
		// TODO: Add constructor logic here
		//
	}

	public static int AddFields(string FieldName)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("ExternalFieldName", FieldName);

		tbl_ExternalFields objfeilds = new tbl_ExternalFields();
		objfeilds.Data = hstbl;
		int result = objfeilds.Add();
		return result;
	}


	public static bool UpdateFields(int ExternalID,string FieldName)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("ExternalFieldName", FieldName);

		tbl_ExternalFields objfeilds = new tbl_ExternalFields();
		objfeilds.Data = hstbl;
		objfeilds.WhereClause = "ExternalID=" + ExternalID;
		bool result = objfeilds.Update();
		return result;
	}

	public static void SelectExternalField(int ExternalID)
	{
		tbl_ExternalFields seldata = new tbl_ExternalFields();
		DataTable dtbl = new DataTable();
		seldata.WhereClause = "ExternalID=" + ExternalID;
		dtbl = seldata.Select();
		//return result;
	}

	public static bool DeleteLead(int ExternalID)
	{
		tbl_ExternalFields dellead = new tbl_ExternalFields();
		dellead.WhereClause = "ExternalID=" + ExternalID;
		bool result = dellead.Delete();
		return result;
	}




}