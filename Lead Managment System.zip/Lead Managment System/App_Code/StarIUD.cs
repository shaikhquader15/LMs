﻿using System;
using System.Collections;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Text;
//using System.Windows.Forms;
using System.Drawing;

namespace Component
{
    

    public class StarIUD
    {
        private int CompID;
        public bool isSql = true;
        public ArrayList m_ChildTableJoins;
        public ArrayList m_ChildTables;
        public Hashtable m_DataDetails;
        public bool m_dataExists;
        public int m_dataId;
        public string m_DBName;
        public string m_extraJoin;
        public string m_identityColumn;
        public string m_OrderBy;
        public int m_rowCount;
        public string m_sumOf;
        public string m_tableName;
        public int m_topRecords;
        public string m_whereClause;
        public OleDbConnection objConnection_ACCESS;
        public SqlConnection objConnection_SQL;
        public string referenceid;
        public string TableColumns = "*";
        public string MutipleIDs = "";
        public StarIUD()
        {
            this.isSql = AppConstants.IsSQL;
            if (this.isSql)
            {
                this.objConnection_SQL = new SqlConnection();
                //if (!string.IsNullOrEmpty(AppConstants.GlobalCompanyId))
                //{
                //    this.objConnection_SQL.ConnectionString = AppConstants.GlobalCompanyId;
                //}
                //else
                //{
                    this.objConnection_SQL.ConnectionString = this.GetConnection();
               // }
            }
            else
            {
                this.objConnection_ACCESS = new OleDbConnection();
                this.objConnection_ACCESS.ConnectionString = this.GetConnection();
            }
            this.m_ChildTables = new ArrayList();
            this.m_ChildTableJoins = new ArrayList();
            this.m_dataId = 0;
            this.m_dataExists = false;
            this.m_rowCount = 0;
            this.m_whereClause = "";
            this.m_OrderBy = "";
            this.m_sumOf = "";
            this.referenceid = "";
        }

        public virtual int Add()
        {
            int num2;
            int num = 0;
            SqlCommand command = null;
            OleDbCommand command2 = null;
            string str = "";
            string str2 = "";
            IDictionaryEnumerator enumerator = this.m_DataDetails.GetEnumerator();
            while (enumerator.MoveNext())
            {
                str = str + "[" + enumerator.Key.ToString() + "],";
                if ( enumerator.Value == null )
                    str2 = str2 + "'',";
                else
                    str2 = str2 + "'" + enumerator.Value.ToString() + "',";
            }
            str = str.Remove(str.Length - 1);
            str2 = str2.Remove(str2.Length - 1);
            StringBuilder builder = new StringBuilder();
            builder.Append("Insert Into " + this.m_tableName + "(");
            builder.Append(str + ") Values (");
            builder.Append(str2 + ")");
            string str3 = builder.ToString();
            
            if (this.isSql)
            {
                command = new SqlCommand(str3 + ";SELECT @@IDENTITY", this.objConnection_SQL);
            }
            else
            {
                command2 = new OleDbCommand(str3 + ";", this.objConnection_ACCESS);
            }
            try
            {
                if (this.isSql)
                {
                    if (this.objConnection_SQL.State == ConnectionState.Closed)
                    this.objConnection_SQL.Open();

                    num = Convert.ToInt32(command.ExecuteScalar());
                    this.objConnection_SQL.Close();
                    return num;
                }
                this.objConnection_ACCESS.Open();
                command2.CommandTimeout = 950;
                command2.ExecuteNonQuery();
                command2.CommandText = "SELECT @@IDENTITY";
                num = Convert.ToInt32(command2.ExecuteScalar());
                this.objConnection_ACCESS.Close();
                num2 = num;
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (this.isSql)
                {
                    command.Dispose();
                    this.objConnection_SQL.Close();
                    this.objConnection_SQL.Dispose();
                }
                else
                {
                    command2.Dispose();
                    this.objConnection_ACCESS.Close();
                    this.objConnection_ACCESS.Dispose();
                }
                builder = null;
            }
            return num2;
        }

        public void AddChildTable(StarIUD InsertUpdate)
        {
            this.m_ChildTables.Add(InsertUpdate);
            this.m_ChildTableJoins.Add(JoinType.INNER_JOIN);
        }

        public void AddChildTable(StarIUD InsertUpdate, JoinType joinType)
        {
            this.m_ChildTables.Add(InsertUpdate);
            this.m_ChildTableJoins.Add(joinType);
        }

        public DataTable ApplyMultipleJoins(int t3rdJoinFromTableNumber)
        {
            string str = "";
            if (this.m_topRecords > 0)
            {
                str = "TOP " + this.m_topRecords;
            }
            string strQuery = "SELECT " + str + " " + this.TableColumns + " FROM (" + this.m_tableName + " t1";
            for (int i = 0; i < this.m_ChildTables.Count; i++)
            {
                object obj2;
                StarIUD table = new StarIUD();
                table = (StarIUD)this.m_ChildTables[i];
                string str3 = " INNER JOIN ";
                switch (((JoinType) this.m_ChildTableJoins[i]))
                {
                    case JoinType.LEFT_JOIN:
                        str3 = " LEFT JOIN ";
                        break;

                    case JoinType.RIGHT_JOIN:
                        str3 = " RIGHT JOIN ";
                        break;
                }
                if (i == 0)
                {
                    obj2 = strQuery;
                    strQuery = string.Concat(new object[] { obj2, str3, table.TableName, " t", i + 2, " ON t1.", table.IdentityColumn, " = t", i + 2, ".", table.IdentityColumn, ")" });
                }
                else
                {
                    obj2 = strQuery;
                    strQuery = string.Concat(new object[] { obj2, str3, table.TableName, " t", i + 2, " ON t" + t3rdJoinFromTableNumber + ".", table.IdentityColumn, " = t", i + 2, ".", table.IdentityColumn });
                }
            }
            if (this.m_whereClause != "")
            {
                strQuery = strQuery + " WHERE " + this.m_whereClause;
            }
            if (this.OrderBy != "")
            {
                strQuery = strQuery + " ORDER BY " + this.OrderBy;
            }
            return this.ExecuteSelectQuery(strQuery);
        }

        public void BackUp(string strBackupLocation)
        {
            string cmdText = null;
            cmdText = "BACKUP DATABASE " + this.DatabaseName + " TO  DISK = '" + strBackupLocation + ".bak'";
            SqlConnection connection = new SqlConnection(this.GetConnection());
            SqlCommand command = new SqlCommand(cmdText, connection);
            connection.Open();
            command.CommandTimeout = 950;
            command.ExecuteNonQuery();
            if (connection.State == ConnectionState.Open)
            {
                connection.Close();
            }
        }

        public bool Delete()
        {
            bool flag = false;
            string cmdText = "";
            if (this.m_whereClause != "")
            {
                cmdText = "DELETE FROM " + this.m_tableName + " WHERE " + this.m_whereClause;
            }
            else if (this.ReferenceId != "")
            {
                cmdText = "DELETE FROM " + this.m_tableName + " WHERE " + this.ReferenceId + " = " + this.m_dataId.ToString();
            }
            else
            {
                cmdText = "DELETE FROM " + this.m_tableName + " WHERE " + this.m_identityColumn + " = " + this.m_dataId.ToString();
            }
            SqlCommand command = null;
            OleDbCommand command2 = null;
            if (this.isSql)
            {
                command = new SqlCommand(cmdText, this.objConnection_SQL);
            }
            else
            {
                command2 = new OleDbCommand(cmdText, this.objConnection_ACCESS);
            }
            try
            {
                if (this.isSql)
                {
                    this.objConnection_SQL.Open();
                    command.CommandTimeout = 950;
                    command.ExecuteNonQuery();
                }
                else
                {
                    this.objConnection_ACCESS.Open();
                    command2.CommandTimeout = 950;
                    command2.ExecuteNonQuery();
                }
                flag = true;
            }
            catch( Exception ex)
            {
                throw (ex);
            }
            finally
            {
                if (this.isSql)
                {
                    command.Dispose();
                    this.objConnection_SQL.Close();
                    this.objConnection_SQL.Dispose();
                }
                else
                {
                    command2.Dispose();
                    this.objConnection_ACCESS.Close();
                    this.objConnection_ACCESS.Dispose();
                }
            }
            return flag;
        }

        public bool MultipleDelete( )
        {
            bool flag = false;
            string cmdText = "";
            if (this.m_whereClause != "")
            {
                cmdText = "DELETE FROM " + this.m_tableName + " WHERE " + this.m_whereClause;
            }
            else if (this.ReferenceId != "")
            {
                cmdText = "DELETE FROM " + this.m_tableName + " WHERE " + this.ReferenceId + " = " + this.m_dataId.ToString();
            }
            else
            {
                cmdText = "DELETE FROM " + this.m_tableName + " WHERE " + this.m_identityColumn + " = " + this.m_dataId.ToString();
            }
            SqlCommand command = null;
            OleDbCommand command2 = null;
            if (this.isSql)
            {
                command = new SqlCommand(cmdText, this.objConnection_SQL);
            }
            else
            {
                command2 = new OleDbCommand(cmdText, this.objConnection_ACCESS);
            }
            try
            {
                if (this.isSql)
                {
                    this.objConnection_SQL.Open();
                    command.CommandTimeout = 950;
                    command.ExecuteNonQuery();
                }
                else
                {
                    this.objConnection_ACCESS.Open();
                    command2.ExecuteNonQuery();
                }
                flag = true;
            }
            catch
            {
            }
            finally
            {
                if (this.isSql)
                {
                    command.Dispose();
                    this.objConnection_SQL.Close();
                    this.objConnection_SQL.Dispose();
                }
                else
                {
                    command2.Dispose();
                    this.objConnection_ACCESS.Close();
                    this.objConnection_ACCESS.Dispose();
                }
            }
            return flag;
        }


        public bool MultipleDeleteList()
        {
            bool flag = false;
            string cmdText = "";
            if (this.m_whereClause != "")
            {
                cmdText = "DELETE FROM " + this.m_tableName + " WHERE " + this.m_whereClause;
            }
            else if (this.ReferenceId != "")
            {
                cmdText = "DELETE FROM " + this.m_tableName + " WHERE " + this.ReferenceId + " = " + this.m_dataId.ToString();
            }
            else
            {
                cmdText = "DELETE FROM " + this.m_tableName + " WHERE " + this.m_identityColumn + " = " + this.m_dataId.ToString();
            }
            SqlCommand command = null;
            OleDbCommand command2 = null;
            if (this.isSql)
            {
                command = new SqlCommand(cmdText, this.objConnection_SQL);
            }
            else
            {
                command2 = new OleDbCommand(cmdText, this.objConnection_ACCESS);
            }
            try
            {
                if (this.isSql)
                {
                    this.objConnection_SQL.Open();
                    command.CommandTimeout = 950;
                    command.ExecuteNonQuery();
                }
                else
                {
                    this.objConnection_ACCESS.Open();
                    command2.ExecuteNonQuery();
                }
                flag = true;
            }
            catch
            {
            }
            finally
            {
                if (this.isSql)
                {
                    command.Dispose();
                    this.objConnection_SQL.Close();
                    this.objConnection_SQL.Dispose();
                }
                else
                {
                    command2.Dispose();
                    this.objConnection_ACCESS.Close();
                    this.objConnection_ACCESS.Dispose();
                }
            }
            return flag;
        }

        private DataTable DeleteUnwantedColumns(DataTable dttblSelectData)
        {
            int num;
            for (num = 0; num < dttblSelectData.Columns.Count; num++)
            {
                if (dttblSelectData.Columns[num].ColumnName.IndexOf(".") > 0)
                {
                    try
                    {
                        Array array = dttblSelectData.Columns[num].ColumnName.Split(new char[] { '.' });
                        dttblSelectData.Columns[num].ColumnName = array.GetValue(1).ToString();
                    }
                    catch
                    {
                    }
                }
            }
            if (!this.isSql && (this.m_topRecords > 0))
            {
                DataTable table = dttblSelectData.Clone();
                int count = dttblSelectData.Rows.Count;
                for (num = 0; num < this.m_topRecords; num++)
                {
                    if (num >= count)
                    {
                        return table;
                    }
                    DataRow row = table.NewRow();
                    for (int i = 0; i < dttblSelectData.Columns.Count; i++)
                    {
                        row[table.Columns[i]] = dttblSelectData.Rows[num][dttblSelectData.Columns[i]];
                    }
                    table.Rows.Add(row);
                }
                return table;
            }
            return dttblSelectData;
        }

        public virtual bool ExecuteQuery(string strQuery)
        {
            SqlCommand command = null;
            OleDbCommand command2 = null;
            bool flag = false;
            if (this.isSql)
            {
                command = new SqlCommand(strQuery, this.objConnection_SQL);
            }
            else
            {
                command2 = new OleDbCommand(strQuery, this.objConnection_ACCESS);
            }
            try
            {
                if (this.isSql)
                {
                    this.objConnection_SQL.Open();
                    command.CommandTimeout = 950;
                    command.ExecuteNonQuery();
                    this.objConnection_SQL.Close();
                }
                else
                {
                    this.objConnection_ACCESS.Open();
                    command2.CommandTimeout = 950;
                    command2.ExecuteNonQuery();
                    this.objConnection_ACCESS.Close();
                }
                flag = true;
            }
            catch
            {
            }
            finally
            {
                if (this.isSql)
                {
                    command.Dispose();
                    this.objConnection_SQL.Close();
                    this.objConnection_SQL.Dispose();
                }
                else
                {
                    command2.Dispose();
                    this.objConnection_ACCESS.Close();
                    this.objConnection_ACCESS.Dispose();
                }
            }
            return flag;
        }

        public DataTable ExecuteSelectQuery(string strQuery)
        {
            DataTable table2;
            DataTable dataTable = new DataTable();
            SqlDataAdapter adapter = null;
            OleDbDataAdapter adapter2 = null;
            try
            {
                if (this.isSql)
                {
                    adapter = new SqlDataAdapter(strQuery, this.objConnection_SQL);
                    adapter.SelectCommand.CommandType = CommandType.Text;
                    adapter.Fill(dataTable);
                }
                else
                {
                    adapter2 = new OleDbDataAdapter(strQuery, this.objConnection_ACCESS);
                    adapter2.SelectCommand.CommandType = CommandType.Text;
                    adapter2.Fill(dataTable);
                }
                if (dataTable != null)
                {
                    dataTable = this.DeleteUnwantedColumns(dataTable);
                    this.m_rowCount = dataTable.Rows.Count;
                    if (this.m_rowCount > 0)
                    {
                        this.m_dataExists = true;
                    }
                }
                table2 = dataTable;
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                if (this.isSql)
                {
                    adapter.Dispose();
                    this.objConnection_SQL.Close();
                    this.objConnection_SQL.Dispose();
                }
                else
                {
                    adapter2.Dispose();
                    this.objConnection_ACCESS.Close();
                    this.objConnection_ACCESS.Dispose();
                }
            }
            return table2;
        }

        //public virtual void Fill(ComboBox ddl, string fieldName)
        //{
        //    this.FillDropdown(ddl, fieldName, "");
        //}

        //public virtual void Fill(ComboBox ddl, string fieldName, string firstRowText)
        //{
        //    this.FillDropdown(ddl, fieldName, firstRowText);
        //}

        //private void FillDropdown(ComboBox ddl, string fieldName, string firstRowText)
        //{
        //    DataTable table = new DataTable();
        //    try
        //    {
        //        try
        //        {
        //            string strQuery = "";
        //            if ((firstRowText != "") && (this.ReferenceId != ""))
        //            {
        //                strQuery = "SELECT " + this.referenceid + "," + fieldName + " FROM " + this.m_tableName;
        //            }
        //            else if (firstRowText != "")
        //            {
        //                strQuery = "SELECT " + this.m_identityColumn + "," + fieldName + " FROM " + this.m_tableName;
        //            }
        //            else
        //            {
        //                strQuery = "SELECT " + this.m_identityColumn + "," + fieldName + " FROM " + this.m_tableName;
        //            }
        //            if (this.m_whereClause != "")
        //            {
        //                strQuery = strQuery + " WHERE " + this.m_whereClause;
        //            }
        //            if (this.OrderBy != "")
        //            {
        //                if (this.OrderBy == (this.m_identityColumn + " DESC"))
        //                {
        //                    strQuery = strQuery + " ORDER BY " + fieldName;
        //                }
        //                else
        //                {
        //                    strQuery = strQuery + " ORDER BY " + this.OrderBy;
        //                }
        //            }
        //            else
        //            {
        //                strQuery = strQuery + " ORDER BY " + fieldName;
        //            }
        //            table = this.ExecuteSelectQuery(strQuery);
        //            if (table != null)
        //            {
        //                this.m_rowCount = table.Rows.Count;
        //                if (this.m_rowCount > 0)
        //                {
        //                    this.m_dataExists = true;
        //                    if (firstRowText != "")
        //                    {
        //                        DataRow row = table.NewRow();
        //                        if (this.ReferenceId != "")
        //                        {
        //                            row[this.ReferenceId] = "0";
        //                        }
        //                        else
        //                        {
        //                            row[this.m_identityColumn] = "0";
        //                        }
        //                        row[fieldName] = "Select " + firstRowText;
        //                        table.Rows.InsertAt(row, 0);
        //                    }
        //                }
        //                ddl.DataSource = table;
        //                ddl.DisplayMember = fieldName;
        //                if (this.ReferenceId != "")
        //                {
        //                    ddl.ValueMember = this.ReferenceId;
        //                }
        //                else
        //                {
        //                    ddl.ValueMember = this.m_identityColumn;
        //                }
        //                if (firstRowText != "")
        //                {
        //                }
        //            }
        //        }
        //        catch (Exception exception)
        //        {
        //            throw exception;
        //        }
        //    }
        //    finally
        //    {
        //    }
        //}

        private string GetColumnValues(Hashtable hstbl)
        {
            string str = "";
            string str2 = "";
            IDictionaryEnumerator enumerator = hstbl.GetEnumerator();
            while (enumerator.MoveNext())
            {
                str = str + enumerator.Key.ToString() + ",";
                str2 = str2 + "'" + enumerator.Value.ToString() + "',";
            }
            str = str.Remove(str.Length - 1);
            return str.Remove(str.Length - 1);
        }

        private string GetConnection()
        {
            return AppConstants.ConnectionString;
            string dBPath = "";
            if ((this.DatabaseName == null) || (this.DatabaseName == ""))
            {
                string globalCompanyId = "";
                globalCompanyId = AppConstants.GlobalCompanyId;
                if (globalCompanyId != "")
                {
                    globalCompanyId = globalCompanyId.Replace("/", "");
                    dBPath = AppConstants.DBPath;
                }
                else
                {
                    dBPath = AppConstants.AppPathMyComp;
                    globalCompanyId = "";
                }
                //this.DatabaseName = "Invoice" + globalCompanyId;

                this.DatabaseName = "CustomerNew" + globalCompanyId;
            }
            if (this.isSql)
            {
                return AppConstants.ConnectionString;
            }
            return ("Jet OLEDB:Global Partial Bulk Ops=2;Jet OLEDB:Registry Path=;Jet OLEDB:Database Locking Mode=1;Jet OLEDB:Database Password=#uWaJaM1lu9;Data Source=\"" + dBPath + this.DatabaseName + "\";Password=;Jet OLEDB:Engine Type=5;Jet OLEDB:Global Bulk Transactions=1;Provider=\"Microsoft.Jet.OLEDB.4.0\";Jet OLEDB:System database=;Jet OLEDB:SFP=False;Extended Properties=;Mode=Share Deny None;Jet OLEDB:New Database Password=;Jet OLEDB:Create System Database=False;Jet OLEDB:Don't Copy Locale on Compact=False;Jet OLEDB:Compact Without Replica Repair=False;User ID=Admin;Jet OLEDB:Encrypt Database=False");
        }

        public int GetDefaultValue(string fieldName, string firstRowText)
        {
            int num = 0;
            DataTable table = new DataTable();
            try
            {
                try
                {
                    string strQuery = "";
                    if (firstRowText != "")
                    {
                        strQuery = "SELECT " + this.m_identityColumn + "," + fieldName + " FROM " + this.m_tableName;
                    }
                    else
                    {
                        strQuery = "SELECT " + this.m_identityColumn + "," + fieldName + " FROM " + this.m_tableName;
                    }
                    if (this.m_whereClause != "")
                    {
                        strQuery = strQuery + " WHERE " + this.m_whereClause;
                    }
                    if (this.OrderBy != "")
                    {
                        if (this.OrderBy == (this.m_identityColumn + " DESC"))
                        {
                            strQuery = strQuery + " ORDER BY " + fieldName;
                        }
                        else
                        {
                            strQuery = strQuery + " ORDER BY " + this.OrderBy;
                        }
                    }
                    else
                    {
                        strQuery = strQuery + " ORDER BY " + fieldName;
                    }
                    table = this.ExecuteSelectQuery(strQuery);
                    if (table != null)
                    {
                        this.m_rowCount = table.Rows.Count;
                        if (this.m_rowCount > 0)
                        {
                            return (num = (int) table.Rows[0]["TaxTypeId"]);
                        }
                    }
                }
                catch (Exception exception)
                {
                    throw exception;
                }
            }
            finally
            {
            }
            return num;
        }

        public int GetIDCount()
        {
            DataTable table = new DataTable();
            if (this.WhereClause != null)
            {
                string strQuery = "SELECT count(VoucherTypeId) AS CountVal FROM " + this.m_tableName + " Where " + this.WhereClause;
                table = this.ExecuteSelectQuery(strQuery);
            }
            return Convert.ToInt32(table.Rows[0]["CountVal"]);
        }

        public int GetModuleCount()
        {
            DataTable table = new DataTable();
            string strQuery = "SELECT count(ModuleId) AS CountVal FROM " + this.m_tableName;
            return Convert.ToInt32(this.ExecuteSelectQuery(strQuery).Rows[0]["CountVal"]);
        }

        private string GetTableColumns(Hashtable hstbl)
        {
            string str = "";
            IDictionaryEnumerator enumerator = hstbl.GetEnumerator();
            while (enumerator.MoveNext())
            {
                str = str + enumerator.Key.ToString() + ",";
            }
            return str.Remove(str.Length - 1);
        }

        public bool IsTrialVersion(int intTotalRecords, bool blnIsTrial)
        {
            return true;
        }

        public void Restore(string strLocation)
        {
            string cmdText = null;
            cmdText = "Use master ALTER DATABASE Invoice  SET SINGLE_USER WITH ROLLBACK IMMEDIATE; RESTORE DATABASE Invoice FROM  DISK ='" + strLocation + "' with replace";
            SqlConnection connection = new SqlConnection(this.GetConnection());
            SqlCommand command = new SqlCommand(cmdText, connection);
            connection.Open();
            command.CommandTimeout = 950;
            command.ExecuteNonQuery();
            if (connection.State == ConnectionState.Open)
            {
                connection.Close();
            }
        }

        //public virtual DataTable Search(Control SearchPanel, DataTable dttblData)
        //{
        //    int num;
        //    if (dttblData == null)
        //    {
        //        return dttblData;
        //    }
        //    if (dttblData.Rows.Count < 1)
        //    {
        //        return dttblData;
        //    }
        //    DataTable table = new DataTable();
        //    for (num = 0; num < dttblData.Columns.Count; num++)
        //    {
        //        DataColumn column = new DataColumn(dttblData.Columns[num].ColumnName, typeof(string));
        //        table.Columns.Add(column);
        //        column = null;
        //    }
        //    for (num = 0; num < dttblData.Rows.Count; num++)
        //    {
        //        DataRow row = table.NewRow();
        //        for (int i = 0; i < dttblData.Columns.Count; i++)
        //        {
        //            row[table.Columns[i].ColumnName] = Convert.ToString(dttblData.Rows[num][dttblData.Columns[i].ColumnName]);
        //        }
        //        table.Rows.Add(row);
        //    }
        //    TextBox box = (TextBox) SearchPanel.Controls.Find("txtKeyword", true).GetValue(0);
        //    ComboBox box2 = (ComboBox) SearchPanel.Controls.Find("ddlSearchBy", true).GetValue(0);
        //    DataView defaultView = table.DefaultView;
        //    string str = "";
        //    if (box2.SelectedIndex > 0)
        //    {
        //        str = box2.SelectedItem.ToString() + " LIKE '%" + box.Text + "%'";
        //    }
        //    else if (box.Text != "")
        //    {
        //        for (num = 1; num < box2.Items.Count; num++)
        //        {
        //            str = str + box2.Items[num].ToString() + " LIKE '%" + box.Text + "%' OR ";
        //        }
        //        str = str.Remove(str.Length - 4, 4);
        //    }
        //    defaultView.RowFilter = str;
        //    return defaultView.ToTable();
        //}

        public virtual DataTable Select()
        {
            if (this.m_ChildTables.Count > 0)
            {
                return this.SelectWithJoin();
            }
            DataTable table = new DataTable();
            try
            {
                try
                {
                    string str = "";
                    if (this.m_topRecords > 0)
                    {
                        str = "TOP " + this.m_topRecords;
                    }
                    string str2 = "*";
                    string strQuery = "SELECT " + str + " " + str2 + " FROM " + this.m_tableName + " t1 " + this.m_extraJoin;
                    if (this.m_whereClause != "")
                    {
                        strQuery = strQuery + " WHERE " + this.m_whereClause;  // ivoice no query 
                    }
                    if (this.OrderBy != "")
                    {
                        strQuery = strQuery + " ORDER BY " + this.OrderBy;
                    }
                    table = this.ExecuteSelectQuery(strQuery);
                    if (table != null)
                    {
                        this.m_rowCount = table.Rows.Count;
                        if (this.m_rowCount > 0)
                        {
                            this.m_dataExists = true;
                        }
                    }
                }
                catch (Exception exception)
                {
                   throw exception;
                }
            }
            finally
            {
            }
            return table;
        }

        public virtual DataTable Select(string Table2_Name, string Table1_Id, string Table2_Id, bool isLeftJoin)
        {
            DataTable table = new DataTable();
            string str = " INNER JOIN ";
            if (isLeftJoin)
            {
                str = " LEFT JOIN ";
            }
            string str2 = "";
            if (this.m_topRecords > 0)
            {
                str2 = "TOP " + this.m_topRecords;
            }
            string strQuery = "SELECT " + str2 + " * FROM " + this.m_tableName + " t1 " + str + Table2_Name + " t2 ON t1." + Table1_Id + "=t2." + Table2_Id + " " + this.m_extraJoin;
            if (this.m_whereClause != "")
            {
                strQuery = strQuery + " WHERE " + this.m_whereClause;
            }
            if (this.OrderBy != "")
            {
                strQuery = strQuery + " ORDER BY " + this.OrderBy;
            }
            return this.ExecuteSelectQuery(strQuery);
        }

        public virtual DataRow SelectDetails()
        {
            if (this.m_ChildTables.Count > 0)
            {
                return this.SelectDetailWithJoin();
            }
            DataTable table = new DataTable();
            DataRow row = null;
            try
            {
                try
                {
                    string strQuery = "";
                    if (this.m_whereClause != "")
                    {
                        strQuery = "SELECT * FROM " + this.m_tableName + " WHERE " + this.m_whereClause;
                    }
                    else
                    {
                        strQuery = "SELECT * FROM " + this.m_tableName + " t1 WHERE " + this.m_identityColumn + "=" + this.m_dataId.ToString();
                    }
                    if (this.OrderBy != "")
                    {
                        strQuery = strQuery + " ORDER BY " + this.OrderBy;
                    }
                    table = this.ExecuteSelectQuery(strQuery);
                    if (table != null)
                    {
                        this.m_rowCount = table.Rows.Count;
                        if (this.m_rowCount > 0)
                        {
                            this.m_dataExists = true;
                            row = table.Rows[0];
                        }
                    }
                }
                catch (Exception exception)
                {
                    throw exception;
                }
            }
            finally
            {
            }
            return row;
        }

        public virtual DataRow SelectDetails(string Table2_Name, string Table1_Id, string Table2_Id, bool isLeftJoin)
        {
            DataTable table = new DataTable();
            string str = " INNER JOIN ";
            if (isLeftJoin)
            {
                str = " LEFT JOIN ";
            }
            string strQuery = "";
            if (this.m_whereClause == "")
            {
                strQuery = "SELECT * FROM " + this.m_tableName + " t1 " + str + Table2_Name + " t2 ON t1." + Table1_Id + "=t2." + Table2_Id + " WHERE " + this.m_identityColumn + "=" + this.m_dataId.ToString();
            }
            else
            {
                strQuery = "SELECT * FROM " + this.m_tableName + " t1 " + str + Table2_Name + " t2 ON t1." + Table1_Id + "=t2." + Table2_Id + " WHERE " + this.m_whereClause;
            }
            if (this.OrderBy != "")
            {
                strQuery = strQuery + " ORDER BY " + this.OrderBy;
            }
            return this.ExecuteSelectQuery(strQuery).Rows[0];
        }

        public DataRow SelectDetailWithJoin()
        {
            string strQuery = "SELECT * FROM " + this.m_tableName + " t1";
            for (int i = 0; i < this.m_ChildTables.Count; i++)
            {
                StarIUD table = new StarIUD();
                table = (StarIUD)this.m_ChildTables[i];
                object obj2 = strQuery;
                strQuery = string.Concat(new object[] { obj2, " INNER JOIN ", table.TableName, " t", i + 2, " ON t1.", table.IdentityColumn, "=t", i + 2, ".", table.IdentityColumn });
            }
            if (this.m_whereClause != "")
            {
                strQuery = strQuery + " WHERE " + this.m_whereClause;
            }
            else
            {
                string str2 = strQuery;
                strQuery = str2 + " WHERE t1." + this.m_identityColumn + "=" + this.m_dataId.ToString();
            }
            return this.ExecuteSelectQuery(strQuery).Rows[0];
        }

        public string SelectDetailWithSUM()
        {
            string strQuery = "SELECT SUM(" + this.SUM + ") AS " + this.SUM + " FROM (" + this.m_tableName + " t1";
            for (int i = 0; i < this.m_ChildTables.Count; i++)
            {
                StarIUD table = new StarIUD();
                table = (StarIUD)this.m_ChildTables[i];
                object obj2 = strQuery;
                string str2 = " INNER JOIN ";
                switch (((JoinType) this.m_ChildTableJoins[i]))
                {
                    case JoinType.LEFT_JOIN:
                        str2 = " LEFT JOIN ";
                        break;

                    case JoinType.RIGHT_JOIN:
                        str2 = " RIGHT JOIN ";
                        break;
                }
                if (i == 0)
                {
                    strQuery = string.Concat(new object[] { obj2, str2, table.TableName, " t", i + 2, " ON t1.", table.IdentityColumn, " = t", i + 2, ".", table.IdentityColumn, ")" });
                }
                else
                {
                    obj2 = strQuery;
                    strQuery = string.Concat(new object[] { obj2, str2, table.TableName, " t", i + 2, " ON t1.", table.IdentityColumn, " = t", i + 2, ".", table.IdentityColumn });
                }
            }
            if (this.m_ChildTables.Count <= 0)
            {
                strQuery = strQuery + ")";
            }
            if (this.m_whereClause != "")
            {
                strQuery = strQuery + " WHERE " + this.m_whereClause;
            }
            else
            {
                string str3 = strQuery;
                strQuery = str3 + " WHERE t1." + this.m_identityColumn + " = " + this.m_dataId.ToString();
            }
            DataTable table2 = this.ExecuteSelectQuery(strQuery);
            string str4 = "";
            if ((table2 != null) && (table2.Rows[0][0] != DBNull.Value))
            {
                str4 = Convert.ToString(table2.Rows[0][0]);
            }
            return str4;
        }

        public virtual DataRow SelectLast(string fieldName, string orderbyfieldname)
        {
            DataTable table = new DataTable();
            string strQuery = "SELECT Top 1 " + fieldName + " AS LastVal FROM " + this.m_tableName;
            if (this.m_whereClause != "")
            {
                strQuery = strQuery + " WHERE " + this.m_whereClause;
            }
            strQuery = strQuery + " ORDER BY " + orderbyfieldname + " DESC";
            table = this.ExecuteSelectQuery(strQuery);
            if ((table != null) && (table.Rows.Count > 0))
            {
                return table.Rows[0];
            }
            return null;
        }

        public virtual DataRow SelectMax(string fieldName)
        {
            DataTable table = new DataTable();
            string strQuery = "SELECT MAX(" + fieldName + ") AS maxVal FROM " + this.m_tableName;
            table = this.ExecuteSelectQuery(strQuery);
            if ((table != null) && (table.Rows.Count > 0))
            {
                return table.Rows[0];
            }
            return null;
        }

        public virtual DataTable SelectShortDetails(string ColumnNames)
        {
            DataTable table = new DataTable();
            if (!string.IsNullOrEmpty(ColumnNames))
            {
                if (this.m_ChildTables.Count > 0)
                {
                    return this.SelectWithJoin();
                }
                try
                {
                    try
                    {
                        string str = "";
                        if (this.m_topRecords > 0)
                        {
                            str = "TOP " + this.m_topRecords;
                        }
                        string str2 = ColumnNames;
                        string strQuery = "SELECT " + str + " " + str2 + " FROM " + this.m_tableName + this.m_extraJoin;
                        if (this.m_whereClause != "")
                        {
                            strQuery = strQuery + " WHERE " + this.m_whereClause;
                        }
                        if (this.OrderBy != "")
                        {
                            strQuery = strQuery + " ORDER BY " + this.OrderBy;
                        }
                        table = this.ExecuteSelectQuery(strQuery);
                        if (table != null)
                        {
                            this.m_rowCount = table.Rows.Count;
                            if (this.m_rowCount > 0)
                            {
                                this.m_dataExists = true;
                            }
                        }
                    }
                    catch (Exception exception)
                    {
                        throw exception;
                    }
                }
                finally
                {
                }
            }
            return table;
        }

        public virtual DataTable SelectTable()
        {
            if (this.m_ChildTables.Count > 0)
            {
                return this.SelectWithJoin();
            }
            DataTable table = new DataTable();
            try
            {
                try
                {
                    string str = "";
                    if (this.m_topRecords > 0)
                    {
                        str = "TOP " + this.m_topRecords;
                    }
                    string str2 = "*";
                    string strQuery = "SELECT " + str + " " + str2 + " FROM " + this.m_tableName + this.m_extraJoin;
                    if (this.m_whereClause != "")
                    {
                        strQuery = strQuery + " WHERE " + this.m_whereClause;
                    }
                    if (this.OrderBy != "")
                    {
                        strQuery = strQuery + " ORDER BY " + this.OrderBy;
                    }
                    table = this.ExecuteSelectQuery(strQuery);
                    if (table != null)
                    {
                        this.m_rowCount = table.Rows.Count;
                        if (this.m_rowCount > 0)
                        {
                            this.m_dataExists = true;
                        }
                    }
                }
                catch (Exception exception)
                {
                    throw exception;
                }
            }
            finally
            {
            }
            return table;
        }

        public DataTable SelectTop100(DataTable dttblData)
        {
            DataTable table = new DataTable();
            table = dttblData.Clone();
            int count = 100;
            if (dttblData.Rows.Count < count)
            {
                count = dttblData.Rows.Count;
            }
            for (int i = 0; i < count; i++)
            {
                table.ImportRow(dttblData.Rows[i]);
            }
            table.AcceptChanges();
            return table;
        }

        public DataTable SelectWithJoin()
        {
            return this.ApplyMultipleJoins(1);
        }

        public DataTable SelectWithJoin(int t3rdTableJoinFromTableNumber)
        {
            return this.ApplyMultipleJoins(t3rdTableJoinFromTableNumber);
        }

        public virtual bool Update()
        {
            bool flag;
            SqlCommand command = null;
            OleDbCommand command2 = null;
            StringBuilder builder = new StringBuilder();
            string str = "";
            IDictionaryEnumerator enumerator = this.m_DataDetails.GetEnumerator();
            while (enumerator.MoveNext())
            {
               
                if (enumerator.Value != null)
                {
                    str = str + "[" + enumerator.Key.ToString() + "]='" + enumerator.Value.ToString() + "',";
                }
                else
                {
                    str = str + "[" + enumerator.Key.ToString() + "]='" + "',";
                }
            }
            str = str.Remove(str.Length - 1);
            builder.Append("Update " + this.m_tableName + " Set");
            builder.Append(" " + str);
            if (this.m_whereClause != "")
            {
                builder.Append(" Where " + this.m_whereClause);
            }
            else
            {
                builder.Append(" Where " + this.m_identityColumn + " = " + this.m_dataId.ToString());
            }
            if (this.isSql)
            {
                command = new SqlCommand(builder.ToString(), this.objConnection_SQL);
            }
            else
            {
                command2 = new OleDbCommand(builder.ToString(), this.objConnection_ACCESS);
            }
            try
            {
                if (this.isSql)
                {
                    this.objConnection_SQL.Open();
                    command.ExecuteNonQuery();
                    command.CommandTimeout = 950;
                    this.objConnection_SQL.Close();
                }
                else
                {
                    this.objConnection_ACCESS.Open();
                    command2.CommandTimeout = 950;
                    command2.ExecuteNonQuery();
                    this.objConnection_ACCESS.Close();
                }
                flag = true;
            }
            catch
            {
                flag = false;
            }
            finally
            {
                if (this.isSql)
                {
                    command.Dispose();
                    this.objConnection_SQL.Close();
                    this.objConnection_SQL.Dispose();
                }
                else
                {
                    command2.Dispose();
                    this.objConnection_ACCESS.Close();
                    this.objConnection_ACCESS.Dispose();
                }
                builder = null;
            }
            return flag;
        }

        public Hashtable Data
        {
            set
            {
                this.m_DataDetails = value;
            }
        }

        public string DatabaseName
        {
            get
            {
                return this.m_DBName;
            }
            set
            {
                this.m_DBName = value;
            }
        }

        public bool DataExists
        {
            get
            {
                return this.m_dataExists;
            }
        }

        public int DataId
        {
            get
            {
                return this.m_dataId;
            }
            set
            {
                this.m_dataId = value;
            }
        }

        public string ExtraJoin
        {
            set
            {
                this.m_extraJoin = value;
            }
        }

        public string IdentityColumn
        {
            get
            {
                return this.m_identityColumn;
            }
            set
            {
                this.m_identityColumn = value;
            }
        }

        public string OrderBy
        {
            get
            {
                if (this.m_OrderBy == "")
                {
                    this.m_OrderBy = this.m_identityColumn + " DESC";
                }
                return this.m_OrderBy;
            }
            set
            {
                this.m_OrderBy = value;
            }
        }

        public string ReferenceId
        {
            get
            {
                return this.referenceid;
            }
            set
            {
                this.referenceid = value;
            }
        }

        public int RowCount
        {
            get
            {
                return this.m_rowCount;
            }
        }

        public string SUM
        {
            get
            {
                return this.m_sumOf;
            }
            set
            {
                this.m_sumOf = value;
            }
        }

        public string TableName
        {
            get
            {
                return this.m_tableName;
            }
            set
            {
                this.m_tableName = value;
            }
        }

        public int TopRecords
        {
            set
            {
                this.m_topRecords = value;
            }
        }

        public string WhereClause
        {
            get
            {
                return this.m_whereClause;
            }
            set
            {
                this.m_whereClause = value;
            }
        }
    }
}

