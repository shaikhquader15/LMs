﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Web.UI.WebControls;
using System.Data;

/// <summary>
/// Summary description for ClsStage
/// </summary>
public class ClsEmailFormat
{
	public ClsEmailFormat()
	{
		//
		// TODO: Add constructor logic here
		//
	}

	public static int AddStage(string StageName, int IsApproved, string Description)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("StageName", StageName);
		hstbl.Add("IsApproved", IsApproved);
		hstbl.Add("Description", Description);


		tbl_EmailFormat objstatus = new tbl_EmailFormat();
		objstatus.Data = hstbl;
		int result = objstatus.Add();
		return result;
	}


	public static bool UpdateStage(int StageID, string StageName, int IsApproved, string Description)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("StageName", StageName);
		hstbl.Add("IsApproved", IsApproved);
		hstbl.Add("Description", Description);

		tbl_EmailFormat objstat = new tbl_EmailFormat();
		objstat.Data = hstbl;
		objstat.WhereClause = "StageID=" + StageID;
		bool result = objstat.Update();
		return result;

	}

	public static bool DeleteStage(int Stageid)
	{
		tbl_EmailFormat obj = new tbl_EmailFormat();
		obj.WhereClause = "StageID=" + Stageid;
		bool result = obj.Delete();
		return result;
	}


	public static string SelectStage(int Stageid)
	{
		string strStagename = "";
		string strdescription = "";
		tbl_EmailFormat sellstage = new tbl_EmailFormat();
		sellstage.WhereClause = "StageID=" + Stageid;
		DataTable dtbl = sellstage.Select();
		if (dtbl.Rows.Count > 0)
		{
			strStagename = clsPrecaution.GetStr_Empty(dtbl.Rows[0]["StageName"]);
			strStagename = clsPrecaution.GetStr_Empty(dtbl.Rows[0]["IsApproved"]);
			strdescription = clsPrecaution.GetStr_Empty(dtbl.Rows[0]["Description"]);
			string result = strStagename;
		}
		return strStagename;
	}
}