﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;
using System.Collections;
using System.Data;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for ClsLeadStatus
/// </summary>
public class ClsLeadStatus
{
	public ClsLeadStatus()
	{
		//
		// TODO: Add constructor logic here
		//
	}

	public static int AddLeadStatus(string StatusName,int StatusID)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("StatusName", StatusName);
		hstbl.Add("StatusID", StatusID);


		tbl_LeadStatus tbleadStatus = new tbl_LeadStatus();
		tbleadStatus.Data = hstbl;
		int result = tbleadStatus.Add();
		return result;
	}

	public static bool UpdateLeadStatus(int LStatusID, string StatusName,int StatusID)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("StatusName", StatusName);
		hstbl.Add("StatusID", StatusID);


		tbl_LeadStatus tbleadStatus = new tbl_LeadStatus();
		tbleadStatus.Data = hstbl;
		tbleadStatus.WhereClause = "LStatusID=" + LStatusID;
		bool result = tbleadStatus.Update();
		return result;
	}

	public static bool DeleteLeadStatus(int LStatusID)
	{
		tbl_LeadStatus delleadstatus = new tbl_LeadStatus();
		delleadstatus.WhereClause = "LStatusID=" + LStatusID;
		bool result = delleadstatus.Delete();
		return result;

	}


	public static void SelectLeadStatus(int LStatusID)
	{
		tbl_LeadStatus seldata = new tbl_LeadStatus();
		DataTable dtbl = new DataTable();
		seldata.WhereClause = "LStatusID=" + LStatusID;
		dtbl = seldata.Select();
		//return result;
	}


	public static void SelectAllLeadStatus(GridView gridview, DataTable dtbl)
	{
		tbl_LeadStatus seldata = new tbl_LeadStatus();
		//DataTable dtbl = new DataTable();
		dtbl = seldata.Select();
		gridview.DataSource = dtbl;
		gridview.DataBind();
		//return gridview;

	}



















}