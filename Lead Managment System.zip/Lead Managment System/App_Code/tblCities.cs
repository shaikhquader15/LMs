﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;

/// <summary>
/// Summary description for tblCities
/// </summary>
public class tblCities:StarIUD
{
	public tblCities()
	{
		base.TableName = "tblCities";
		base.IdentityColumn = "CityId";
	}
}