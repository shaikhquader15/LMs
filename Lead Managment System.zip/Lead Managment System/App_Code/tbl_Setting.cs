﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Data;
using System.Web.UI.WebControls;
using Component;

/// <summary>
/// Summary description for tbl_Setting
/// </summary>
public class tbl_Setting:StarIUD
{
	public tbl_Setting()
	{
		base.TableName = "tbl_Setting";
		base.IdentityColumn = "Sid";
	}
}