﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;

/// <summary>
/// Summary description for tblStates
/// </summary>
public class tblStates: StarIUD
{
	public tblStates()
	{
		base.TableName= "tblStates";
		base.IdentityColumn= "StateId";

	}
}