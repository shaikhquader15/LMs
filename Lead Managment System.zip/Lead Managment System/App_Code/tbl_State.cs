﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;
/// <summary>
/// Summary description for tbl_State
/// </summary>
public class tbl_State:StarIUD
{
	public tbl_State()
	{
		base.TableName = "tbl_State";
		base.IdentityColumn = "StateID";
	}
}