﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;

/// <summary>
/// Summary description for tbl_SalesTeam
/// </summary>
public class tbl_SalesTeam: StarIUD
{
	public tbl_SalesTeam()
	{
		base.TableName = "tbl_SalesTeam";
		base.IdentityColumn = "SalesID";
	}
}