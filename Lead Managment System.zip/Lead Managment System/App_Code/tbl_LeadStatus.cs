﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;

/// <summary>
/// Summary description for tbl_LeadStatus
/// </summary>
public class tbl_LeadStatus:StarIUD
{
	public tbl_LeadStatus()
	{
		base.TableName = "tbl_LeadStatus";
		base.IdentityColumn = "LStatusID";
	}
}