﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;

/// <summary>
/// Summary description for tbl_SalesLog
/// </summary>
public class tbl_SalesLog:StarIUD
{
    public tbl_SalesLog()
    {
        base.TableName = "tbl_SalesLog";
        base.IdentityColumn = "SalesLogID";
    }
}