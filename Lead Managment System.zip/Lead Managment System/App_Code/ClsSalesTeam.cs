﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;
using System.Collections;
using System.Data;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for ClsSalesTeam
/// </summary>
public class ClsSalesTeam
{
	public ClsSalesTeam()
	{
		
	}

	public static int AddSalesTeam(int SUserID,String SUserName,int SMID,String SMName, int SUserType, int UserID,String UserName, int LeadID,
		String LeadName ,int SouceID,String SourceName, string CallDate, string CallTime, string Address, string Product,string Amount,int SstatusID,
		String SstatusName,string AppointmentDate, string AppointmentTime,int SStageID,string SStageName,string SPercentage)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("SUserID", SUserID);
        hstbl.Add("SUserName", SUserName);
        hstbl.Add("SMID", SMID);
        hstbl.Add("SMName", SMName);
        hstbl.Add("SUserType", SUserType);
		hstbl.Add("UserID", UserID);
        hstbl.Add("UserName", UserName);
        hstbl.Add("LeadID", LeadID);
        hstbl.Add("LeadName", LeadName);
        hstbl.Add("CallDate", CallDate);
		hstbl.Add("CallTime", CallTime);
		hstbl.Add("Address", Address);
		hstbl.Add("Product", Product);
		hstbl.Add("Amount", Amount);
		hstbl.Add("SstatusID", SstatusID);
        hstbl.Add("SstatusName", SstatusName);
        hstbl.Add("AppointmentDate", AppointmentDate);
		hstbl.Add("AppointmentTime", AppointmentTime);
        hstbl.Add("SourceID", SouceID);
        hstbl.Add("SourceName", SourceName);
		hstbl.Add("IsSent", 0);
		hstbl.Add("SStageID", SStageID);
		hstbl.Add("SStageName", SStageName);
		hstbl.Add("SPercentage", SPercentage);


		tbl_SalesTeam AddSalesteam = new tbl_SalesTeam();
		AddSalesteam.Data = hstbl;
		int result = AddSalesteam.Add();
		return result;
	}


	public static bool UpdateSalesTeam(int SalesID,int SUserID, String SUserName, int SMID, String SMName, int SUserType, int UserID, String UserName,
		int LeadID, String LeadName, int SouceID, String SourceName, string CallDate, string CallTime, string Address, string Product, string Amount,
		int SstatusID, String SstatusName, string AppointmentDate, string AppointmentTime)
	{
		Hashtable hstbl = new Hashtable();

        hstbl.Add("SUserID", SUserID);
        hstbl.Add("SUserName", SUserName);
        hstbl.Add("SMID", SMID);
        hstbl.Add("SMName", SMName);
        hstbl.Add("SUserType", SUserType);
        hstbl.Add("UserID", UserID);
        hstbl.Add("UserName", UserName);
        hstbl.Add("LeadID", LeadID);
        hstbl.Add("LeadName", LeadName);
        hstbl.Add("CallDate", CallDate);
        hstbl.Add("CallTime", CallTime);
        hstbl.Add("Address", Address);
        hstbl.Add("Product", Product);
        hstbl.Add("Amount", Amount);
        hstbl.Add("SstatusID", 4);
        hstbl.Add("SstatusName", "New Sales");
        hstbl.Add("AppointmentDate", AppointmentDate);
        hstbl.Add("AppointmentTime", AppointmentTime);
        hstbl.Add("SourceID", SouceID);
        hstbl.Add("SourceName", SourceName);
		hstbl.Add("IsSent", 1);
		//hstbl.Add("SStageID", SStageID);
		//hstbl.Add("SStageName", SStageName);
		//hstbl.Add("SPercentage", SPercentage);


		tbl_SalesTeam UpdateSalesteam = new tbl_SalesTeam();
		UpdateSalesteam.Data = hstbl;
		UpdateSalesteam.WhereClause = "SalesID=" + SalesID;
		bool result = UpdateSalesteam.Update();
		return result;
	}


	public static bool UpdateSales(int SalesID, int SUserID, String SUserName, int SMID, String SMName, int SUserType, int UserID, String UserName,
		int LeadID, String LeadName, int SouceID, String SourceName, string CallDate, string CallTime, string Address, string Product, string Amount,
		int SstatusID, String SstatusName, string AppointmentDate, string AppointmentTime, int SStageID, string SStageName, string SPercentage)
	{
		Hashtable hstbl = new Hashtable();

		hstbl.Add("SUserID", SUserID);
		hstbl.Add("SUserName", SUserName);
		hstbl.Add("SMID", SMID);
		hstbl.Add("SMName", SMName);
		hstbl.Add("SUserType", SUserType);
		hstbl.Add("UserID", UserID);
		hstbl.Add("UserName", UserName);
		hstbl.Add("LeadID", LeadID);
		hstbl.Add("LeadName", LeadName);
		hstbl.Add("CallDate", CallDate);
		hstbl.Add("CallTime", CallTime);
		hstbl.Add("Address", Address);
		hstbl.Add("Product", Product);
		hstbl.Add("Amount", Amount);
		hstbl.Add("SstatusID", SstatusID);
		hstbl.Add("SstatusName", SstatusName);
		hstbl.Add("AppointmentDate", AppointmentDate);
		hstbl.Add("AppointmentTime", AppointmentTime);
		hstbl.Add("SourceID", SouceID);
		hstbl.Add("SourceName", SourceName);
		hstbl.Add("IsSent", 1);
		hstbl.Add("SStageID", SStageID);
		hstbl.Add("SStageName", SStageName);
		hstbl.Add("SPercentage", SPercentage);


		tbl_SalesTeam UpdateSalesteam = new tbl_SalesTeam();
		UpdateSalesteam.Data = hstbl;
		UpdateSalesteam.WhereClause = "SalesID=" + SalesID;
		bool result = UpdateSalesteam.Update();
		return result;
	}

	public static bool DeleteSalesTeam(int SalesID)
	{
		tbl_SalesTeam delSalesTeam = new tbl_SalesTeam();
		delSalesTeam.WhereClause = "SalesID=" + SalesID;
		bool result=delSalesTeam.Delete();
		return result;
	}

	public static string GetLeadName(int SalesID)
	{
		string strleadname = "";
		tbl_SalesTeam objln = new tbl_SalesTeam();
		objln.WhereClause = "SalesID=" + SalesID;
		DataTable dtbl = objln.Select();
		if (dtbl.Rows.Count > 0)
		{
			strleadname = clsPrecaution.GetStr_Empty(dtbl.Rows[0]["LeadName"]);
			string result = strleadname;
		}

		return strleadname;
	}



	public static void SelectData(int SalesID)
	{
		tbl_SalesTeam seldata = new tbl_SalesTeam();
		DataTable dtbl = new DataTable();
		seldata.WhereClause = "SalesID=" + SalesID;
		dtbl = seldata.Select();
		//return result;
	}

	public static string GetStatusName(int StatusID)
	{
		string SStatusName = "";
		tbl_SaleStatus obj = new tbl_SaleStatus();
		obj.WhereClause = "SstatusID=" + StatusID;
		DataTable dtsal = obj.Select();
		if (dtsal.Rows.Count > 0)
		{
			 SStatusName = clsPrecaution.GetStr_Empty(dtsal.Rows[0]["SstatusName"]);
		}
		return SStatusName;
	}



	public static void SelectAllLeadStatus(GridView gridview, DataTable dtbl)
	{
		tbl_SalesTeam seldata = new tbl_SalesTeam();
		//DataTable dtbl = new DataTable();
		dtbl = seldata.Select();
		gridview.DataSource = dtbl;
		gridview.DataBind();
		//return gridview;

	}


























}