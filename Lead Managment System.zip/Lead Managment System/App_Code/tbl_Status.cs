﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;

/// <summary>
/// Summary description for tblStatus
/// </summary>
public class tbl_Status:StarIUD
{
	public tbl_Status()
	{
		base.TableName = "tbl_Status";
		base.IdentityColumn = "StatusID";
	}
}