﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;
using System.Data;
using System.Collections;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for ClsCountries
/// </summary>
public class ClsCountries
{
	public ClsCountries()
	{
		
	}


	public static void BindCountry(DropDownList ddlCountry)
	{
		tbl_Countries objsource = new tbl_Countries();
		objsource.OrderBy = "id";
		DataTable dtbl = objsource.Select();
		ddlCountry.DataSource = dtbl;
		ddlCountry.DataTextField = "cname";
		ddlCountry.DataValueField = "id";
		ddlCountry.DataBind();
		ddlCountry.Items.Insert(0, "Select Country");
	}























}