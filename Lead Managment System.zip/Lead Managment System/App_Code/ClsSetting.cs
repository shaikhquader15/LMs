﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Data;
using System.Web.UI.WebControls;
using Component;

/// <summary>
/// Summary description for ClsSetting
/// </summary>
public class ClsSetting
{
	public ClsSetting()
	{
		//
		// TODO: Add constructor logic here
		//
	}

	public static bool GetLeadStatus(string LeadStatus,int ValiD)
	{
		//string result = "";

		//Hashtable hstb = new Hashtable();
		//hstb.Add("Value", ValiD);

		//tbl_Setting objlstatus = new tbl_Setting();
		//objlstatus.Data = hstb;
		//objlstatus.WhereClause = "Keys='" + LeadStatus+"'";
		//bool result= objlstatus.Update();


		Hashtable hst = new Hashtable();
		hst.Add("LStatusID", ValiD);

		tbl_Lead objlead = new tbl_Lead();
		objlead.Data = hst;
		objlead.WhereClause = "LStatusName='" + LeadStatus + "'";
		bool result=objlead.Update();
		//DataTable dt = objlstatus.Select();
		//if (dt.Rows.Count > 0)
		//{

		//	string intvalue = clsPrecaution.GetStr_Empty(dt.Rows[0]["Value"]);
		//	 //result = intvalue;
		//}

		return result;

	}


}