﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Globalization;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for clsPrecaution
/// </summary>
public class clsPrecaution
{
	public clsPrecaution()
	{
		//
		// TODO: Add constructor logic here
		//
	}

	public static string GetStr_Empty(object objData)
	{
		string IDNEW = "";
		try
		{
			IDNEW = Convert.ToString(objData);
			if (IDNEW == null)
				IDNEW = "";
		}
		catch (Exception ex)
		{
			IDNEW = "";
		}
		return IDNEW;
	}
	public static string GetStr_Null(object objData)
	{
		string IDNEW = null;
		try
		{
			IDNEW = Convert.ToString(objData);
			if (string.IsNullOrEmpty(IDNEW))
				IDNEW = null;
		}
		catch (Exception ex)
		{
			IDNEW = null;
		}
		return IDNEW;
	}

	public static int GetQryStr_ID_Zero()
	{
		int IDNEW = 0;
		try
		{
			IDNEW = Convert.ToInt32(System.Web.HttpContext.Current.Request.QueryString["ID"]);
		}
		catch (Exception ex) { }
		return IDNEW;
	}


	

	public static string GetMMDD_Current(String RawDate)
	{
		string strValue = DateTime.Now.ToString("MM/dd/yyyy");
		try
		{
			DateTime dtRawDate = DateTime.Parse(RawDate);
			strValue = dtRawDate.ToString("MM/dd/yyyy");
		}
		catch (Exception ex)
		{ }
		return strValue;
	}


	public static decimal GetDcml_Zero(object objData)
	{
		decimal IDNEW = 0;
		try
		{
			IDNEW = Convert.ToDecimal(objData);
		}
		catch (Exception ex) { }
		return IDNEW;
	}

	public static int GetInt_Zero(object objData)
	{
		int IDNEW = 0;
		try
		{
			IDNEW = Convert.ToInt32(objData);
		}
		catch (Exception ex) { }
		return IDNEW;
	}
	public static bool IsStringValid(object objvalue)
	{
		try
		{
			if (String.IsNullOrEmpty(Convert.ToString(objvalue)))
			{
				return false;
			}

		}
		catch (Exception e)
		{ }
		return true;
	}

	public static string GetCurrentTime()
	{
		string date;
		DateTime timeUtc = System.DateTime.UtcNow;
		TimeZoneInfo cstZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
		DateTime cstTime = TimeZoneInfo.ConvertTimeFromUtc(timeUtc, cstZone);
		date = cstTime.ToString("dd/MM/yyyy");
		string time;
		time = cstTime.ToString("HH:mm:ss tt", CultureInfo.InvariantCulture);

		return time;
	}

}





