﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Data;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for ClsStageMaster
/// </summary>
public class ClsLeadStageMaster
{
	public ClsLeadStageMaster()
	{
		
	}


	public static int AddLeadStage(string Stagename, string percentage, int StageID)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("LStageName", Stagename);
		hstbl.Add("LPercentage", percentage);
		hstbl.Add("StageID", StageID);

		tbl_LeadStageMaster objlstage = new tbl_LeadStageMaster();
		objlstage.Data = hstbl;
		int result = objlstage.Add();
		return result;
	}


	public static bool UpdateLeadStage(int LStageID, string Lstagename, string Lpercentage, int StageID)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("LStageName", Lstagename);
		hstbl.Add("LPercentage", Lpercentage);
		hstbl.Add("StageID", StageID);

		tbl_LeadStageMaster objlstage = new tbl_LeadStageMaster();
		objlstage.Data = hstbl;
		objlstage.WhereClause = "LStageID=" + LStageID;
		bool result = objlstage.Update();
		return result;

	}

	public static bool DeleteLeadStage(int Lstageid)
	{
		tbl_LeadStageMaster obj = new tbl_LeadStageMaster();
		obj.WhereClause = "LStageID=" + Lstageid;
		bool result = obj.Delete();
		return result;
	}


	public static string SelectLeadStage(int Lstageid)
	{
		string strStagename = "";
		tbl_LeadStageMaster sellstage = new tbl_LeadStageMaster();
		sellstage.WhereClause = "LStageID=" + Lstageid;
		DataTable dtbl = sellstage.Select();
		if (dtbl.Rows.Count > 0)
		{
			 strStagename = clsPrecaution.GetStr_Empty(dtbl.Rows[0]["LStageName"]);
			string result = strStagename;
		}
		return strStagename;
	}

	public static void SelectAllLeadStage(GridView gridview)
	{
		tbl_LeadStageMaster seldata = new tbl_LeadStageMaster();
		DataTable dtbl = new DataTable();
		dtbl = seldata.Select();
		gridview.DataSource = dtbl;
		gridview.DataBind();
		//return gridview;

	}

	public static void StageDropdown(DropDownList ddlstage)
	{
		tbl_LeadStageMaster objLM = new tbl_LeadStageMaster();
		DataTable dtbl = objLM.Select();
		ddlstage.DataSource = dtbl;
		ddlstage.DataTextField="LStageName";
		ddlstage.DataValueField = "LStageID";
		ddlstage.DataBind();
		ddlstage.Items.Insert(0, "Select Stage");
	}



}