﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;
using System.Collections;
using System.Data;


/// <summary>
/// Summary description for clsLeadLog
/// </summary>
public class clsLeadLog
{
    public clsLeadLog()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public static void InsertLeadDeatilsAddCallBack(int LeadID,String LeadName, int StatusID,String StatusName,string contact, string sourcename, String strlcaldate, String strcaltime, String strncaldate, String strncaltime, String strremark, int LStageID, string LStageName, string LPercentage)
    {
        Hashtable hstbl = new Hashtable();
        hstbl.Add("LeadID",LeadID);
        hstbl.Add("LeadName", LeadName);
        hstbl.Add("LStatusID", StatusID);
        hstbl.Add("LStatusName", StatusName);
		hstbl.Add("Contact1", contact);
		hstbl.Add("SourceName", sourcename);
		hstbl.Add("LastCallDate", strlcaldate);
        hstbl.Add("LastCallTime", strcaltime);
        hstbl.Add("NextCallDate", strncaldate);
        hstbl.Add("NextCallTime", strncaltime);
        hstbl.Add("Remark", strremark);
		hstbl.Add("LStageID", LStageID);
		hstbl.Add("LStageName", LStageName);
		hstbl.Add("LPercentage", LPercentage);


        tbl_LeadLog obj = new tbl_LeadLog();
        obj.Data = hstbl;
        obj.Add();


      

        }


    public static void InsertLeadDeatilsAddAppointment(int LeadID, String LeadName, int StatusID, String StatusName,string contact ,String Address,String Product, String strlcaldate, String strcaltime, String strncaldate, String strncaltime, String strremark, int LStageID, string LStageName, string LPercentage)
    {
        Hashtable hstbl = new Hashtable();
        hstbl.Add("LeadID", LeadID);
        hstbl.Add("LeadName", LeadName);
        hstbl.Add("LStatusID", StatusID);
        hstbl.Add("LStatusName", StatusName);
		hstbl.Add("Contact1", contact);

		hstbl.Add("Address", Address);
        hstbl.Add("Product", Product);
        hstbl.Add("LastCallDate", strlcaldate);
        hstbl.Add("LastCallTime", strcaltime);
        hstbl.Add("AppointmentDate", strncaldate);
        hstbl.Add("AppointmentTime", strncaltime);
        hstbl.Add("Remark", strremark);
		hstbl.Add("LStageID", LStageID);
		hstbl.Add("LStageName", LStageName);
		hstbl.Add("LPercentage", LPercentage);

		tbl_LeadLog obj = new tbl_LeadLog();
        obj.Data = hstbl;
        obj.Add();




    }


    public static void InsertLeadDeatilsAddActivityCalls(int LeadID, String LeadName, int StatusID, String StatusName,string contact, string source,String strlcaldate, String strcaltime,String strremark,int LStageID,string LStageName, string LPercentage)
    {
        Hashtable hstbl = new Hashtable();
        hstbl.Add("LeadID", LeadID);
        hstbl.Add("LeadName", LeadName);
        hstbl.Add("LStatusID", StatusID);
        hstbl.Add("LStatusName", StatusName);
        hstbl.Add("Contact1", contact);
        hstbl.Add("SourceName", source);

		hstbl.Add("LastCallDate", strlcaldate);
        hstbl.Add("LastCallTime", strcaltime);
       
        hstbl.Add("Remark", strremark);
		hstbl.Add("LStageID", LStageID);
		hstbl.Add("LStageName", LStageName);
		hstbl.Add("LPercentage", LPercentage);


		tbl_LeadLog obj = new tbl_LeadLog();
        obj.Data = hstbl;
        obj.Add();




    }




}
