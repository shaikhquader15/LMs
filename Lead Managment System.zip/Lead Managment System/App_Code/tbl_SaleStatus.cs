﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;

/// <summary>
/// Summary description for tbl_SaleStatus
/// </summary>
public class tbl_SaleStatus : StarIUD
{
	public tbl_SaleStatus()
	{
		base.TableName = "tbl_SaleStatus";
		base.IdentityColumn = "SstatusID";
	}
}