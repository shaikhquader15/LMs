﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;

/// <summary>
/// Summary description for tbl_SalesStageMaster
/// </summary>
public class tbl_SalesStageMaster:StarIUD
{
	public tbl_SalesStageMaster()
	{
		base.TableName = "tbl_SalesStageMaster";
		base.IdentityColumn = "SStageID";
	}
}