﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Data;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for ClsStatus
/// </summary>
public class ClsStatus
{
	public ClsStatus()
	{
		
	}



	public static int AddStatus(string StatusName,int IsApproved)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("StatusName", StatusName);
		hstbl.Add("IsApproved", IsApproved);


		tbl_Status objstatus = new tbl_Status();
		objstatus.Data = hstbl;
		int result = objstatus.Add();
		return result;
	}


	public static bool UpdateStatus(int StatusID, string StatusName, int IsApproved)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("StatusName", StatusName);
		hstbl.Add("IsApproved", IsApproved);

		tbl_Status objstat = new tbl_Status();
		objstat.Data = hstbl;
		objstat.WhereClause = "StatusID=" + StatusID;
		bool result = objstat.Update();
		return result;

	}

	public static bool DeleteStatus(int Statusid)
	{
		tbl_Status obj = new tbl_Status();
		obj.WhereClause = "StatusID=" + Statusid;
		bool result = obj.Delete();
		return result;
	}


	public static string SelectStatus(int Statusid)
	{
		string strStagename = "";
		tbl_Status sellstage = new tbl_Status();
		sellstage.WhereClause = "StatusID=" + Statusid;
		DataTable dtbl = sellstage.Select();
		if (dtbl.Rows.Count > 0)
		{
			strStagename = clsPrecaution.GetStr_Empty(dtbl.Rows[0]["StatusName"]);
			strStagename = clsPrecaution.GetStr_Empty(dtbl.Rows[0]["IsApproved"]);
			string result = strStagename;
		}
		return strStagename;
	}

	//public static void SelectAllStatus(GridView Gridview1)
	//{
	//	tbl_Status seldata = new tbl_Status();
	//	DataTable dtbl = new DataTable();
	//	dtbl = seldata.Select();
	//	Gridview1.DataSource = dtbl;
	//	Gridview1.DataBind();
	//	//return Gridview1;

	//}

	//public static void StageDropdown(DropDownList ddlstage)
	//{
	//	tbl_Status objLM = new tbl_Status();
	//	DataTable dtbl = objLM.Select();
	//	ddlstage.DataSource = dtbl;
	//	ddlstage.DataTextField = "LStageName";
	//	ddlstage.DataValueField = "LStageID";
	//	ddlstage.DataBind();
	//	ddlstage.Items.Insert(0, "Select Stage");
	//}
}