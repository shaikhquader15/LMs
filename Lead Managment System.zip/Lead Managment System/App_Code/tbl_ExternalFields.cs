﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;
/// <summary>
/// Summary description for tbl_ExternalFields
/// </summary>
public class tbl_ExternalFields:StarIUD
{
	public tbl_ExternalFields()
	{
		base.TableName = "tbl_ExternalFields";
		base.IdentityColumn = "ExternalID";
	}
}