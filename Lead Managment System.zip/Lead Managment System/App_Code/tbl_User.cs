﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;

/// <summary>
/// Summary description for tbl_User
/// </summary>
public class tbl_User: StarIUD
{
	public tbl_User()
	{
		base.TableName = "tbl_User";
		base.IdentityColumn = "UserID";
	}
}