﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Component;
using System.Collections;
using System.Data;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for ClsUser
/// </summary>
public class ClsUser
{
	public ClsUser()
	{
		//
		// TODO: Add constructor logic here
		//
	}



	public static int AddUser(string UserName, string Password, string EmailAddress, string Contact, string Address, string CreateDate, int UserType)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("UserName", UserName);
		hstbl.Add("Password", Password);
		hstbl.Add("EmailAddress", EmailAddress);
		hstbl.Add("Contact", Contact);
		hstbl.Add("Address", Address);
		hstbl.Add("CreateDate", CreateDate);
        hstbl.Add("UserType", UserType);

        tbl_User adduser = new tbl_User();
		adduser.Data = hstbl;
		int result = adduser.Add();
		return result;
		
	}


	public static bool UpdateUser(int UserID,string UserName, string Password, string EmailAddress, string Contact, string Address, string CreateDate, int UserType)
	{
		Hashtable hstbl = new Hashtable();
		hstbl.Add("UserName", UserName);
		hstbl.Add("Password", Password);
		hstbl.Add("EmailAddress", EmailAddress);
		//hstbl.Add("EmailAddress", EmailAddress);
		hstbl.Add("Contact", Contact);
		hstbl.Add("Address", Address);
		hstbl.Add("CreateDate", CreateDate);

		tbl_User adduser = new tbl_User();
		adduser.Data = hstbl;
		adduser.WhereClause = "UserID=" + UserID;
		bool result = adduser.Update();
		return result;

	}



	public static bool delUser(int UserID)
	{
		tbl_User adduser = new tbl_User();
		adduser.WhereClause = "UserID=" + UserID;
		bool result = adduser.Delete();
		return result;
	}


	public static void SelectUser(int UserID)
	{
		tbl_User seldata = new tbl_User();
		DataTable dtbl = new DataTable();
		seldata.WhereClause = "UserID=" + UserID;
		dtbl = seldata.Select();
		//return result;
	}



	public static void SelectAllUser(GridView gridview, DataTable dtbl)
	{
		tbl_User seldata = new tbl_User();
		//DataTable dtbl = new DataTable();
		dtbl = seldata.Select();
		gridview.DataSource = dtbl;
		gridview.DataBind();
		//return gridview;

	}

    //public static bool loginusers(string UserName,string Password,String UserType)
    //{
    //    tbl_User obj = new tbl_User();
    //    return 
    //}


    public static void bindUserType(DropDownList ddl)
    {
        tbl_UserType objusertype = new tbl_UserType();
        objusertype.OrderBy = "UserType";
		//objusertype.WhereClause="SUserType=3"
        DataTable dt = objusertype.Select();
        ddl.DataSource = dt;
        ddl.DataTextField = "UserName";
        ddl.DataValueField = "UserType";
        ddl.DataBind();
        ddl.Items.Insert(0, "Please Select");
    }

    public static void binduser(DropDownList ddl, int usertype)
    {
        tbl_User objcity = new tbl_User();
		objcity.OrderBy = "UserID";
		objcity.WhereClause = "UserType=" + usertype;
        DataTable dt = objcity.Select();
        ddl.DataSource = dt;
        ddl.DataTextField = "UserName";
        ddl.DataValueField = "UserID";
        ddl.DataBind();
        ddl.Items.Insert(0, "Select User");
    }

   


}