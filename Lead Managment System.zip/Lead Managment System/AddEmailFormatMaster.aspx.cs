﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Component;
using System.Data;

public partial class AddStageMaster : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			EditStage();
			RbtnCheched();
		}
	}

	public void EditStage()
	{
		tbl_EmailFormat objstatus = new tbl_EmailFormat();
		int statusid = clsPrecaution.GetInt_Zero(Request.QueryString["StageID"]);
		objstatus.WhereClause = "StageID=" + statusid;
		DataTable dt = objstatus.Select();

		if (dt.Rows.Count > 0)
		{
			txtstage.Text = clsPrecaution.GetStr_Empty(dt.Rows[0]["StageName"]);
			txtdesc.Text = clsPrecaution.GetStr_Empty(dt.Rows[0]["Description"]);
			//txtchkbox.Text = clsPrecaution.GetStr_Empty(dt.Rows[0]["IsApproved"]);
			btnsave.Text = "Update";
		}
	}


	protected void RbtnCheched()
	{
		if (Request.QueryString["StageID"] != null)
		{

			int id = Convert.ToInt32(Request.QueryString["StageID"]);
			if (id > 0)
			{
				tbl_EmailFormat objRbtn = new tbl_EmailFormat();
				DataTable dtbl = new DataTable();
				objRbtn.WhereClause = "StageID=" + id;
				dtbl = objRbtn.Select();
				if (dtbl.Rows.Count > 0)
				{
					int a = clsPrecaution.GetInt_Zero(dtbl.Rows[0]["IsApproved"]);
					if (a == 1)
					{
						txtchkbox.Checked = true;
					}
					else
					{
						txtchkbox.Checked = false;
					}
				}
			}
		}
	}



	protected void btnsave_Click(object sender, EventArgs e)
	{

		int IsApprove = 0;

		if (txtchkbox.Checked)
		{
			IsApprove = 1;
		}
		else
		{
			IsApprove = 0;
		}

		string statusname = clsPrecaution.GetStr_Empty(txtstage.Text);
		string strdesc = clsPrecaution.GetStr_Empty(txtdesc.Text);
		//int intchkbx = clsPrecaution.GetInt_Zero(txtchkbox.Text);

		if (btnsave.Text == "Save")
		{
			ClsEmailFormat.AddStage(statusname, IsApprove, strdesc);
			Response.Redirect("EmailFormat.aspx");
		}

		else
		{
			if (Request.QueryString["StageID"] != null)
			{
				int statusid = clsPrecaution.GetInt_Zero(Request.QueryString["StageID"]);
				ClsEmailFormat.UpdateStage(statusid, statusname, IsApprove, strdesc);
				Response.Redirect("EmailFormat.aspx");

			}
		}

	}
}