﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CallinReportSumary : System.Web.UI.Page
{
	protected void Page_PreInit(Object sender, EventArgs e)
	{
		ClsProj.GetMasterPage(this);

	}
	protected void Page_Load(object sender, EventArgs e)
    {
		if (!Page.IsPostBack)
		{
			int usertype = clsPrecaution.GetInt_Zero(Session["UserType"]);
			if (usertype == 1 || usertype == 2)
			{
				BindDropdown();
				
			}
            if (Session["UserID"] != null)
            {
                if (Session["UserType"] != null)
                {
                    if (Session["UserName"] != null)
                    {
                        ShowSTatusinLabel();

                    }

                }
            }
        }
    }


    public void ShowSTatusinLabel()
    {
        int intRingingCalls = ClsProj.GetDataValue("tbl_Lead", "LStatusID=1");
        lblring.Text = Convert.ToString(intRingingCalls);

        int intBusyCalls = ClsProj.GetDataValue("tbl_Lead", "LStatusID=2");
        lblbusy.Text = Convert.ToString(intBusyCalls);

        int intNotReachCalls = ClsProj.GetDataValue("tbl_Lead", "LStatusID=3");
        lblnotreach.Text = Convert.ToString(intNotReachCalls);

        int intSwitchoffCalls = ClsProj.GetDataValue("tbl_Lead", "LStatusID=6");
        lblswitchoff.Text = Convert.ToString(intSwitchoffCalls);

        int intdisconnectCalls = ClsProj.GetDataValue("tbl_Lead", "LStatusID=4");
        lbldisconnect.Text = Convert.ToString(intdisconnectCalls);

        int intWrongCalls = ClsProj.GetDataValue("tbl_Lead", "LStatusID=5");
        lblwrongNo.Text = Convert.ToString(intWrongCalls);

        int intDNDCalls = ClsProj.GetDataValue("tbl_Lead", "LStatusID=9");
        lblDND.Text = Convert.ToString(intDNDCalls);

        int intNotInterestCalls = ClsProj.GetDataValue("tbl_Lead", "LStatusID=10");
        lblnotinterested.Text = Convert.ToString(intNotInterestCalls);

        int intConvertCalls = ClsProj.GetDataValue("tbl_Lead", "LStatusID=8");
        lblconverted.Text = Convert.ToString(intConvertCalls);

        int intCallBackCalls = ClsProj.GetDataValue("tbl_Lead", "LStatusID=7");
        lblcalback.Text = Convert.ToString(intCallBackCalls);

        int intNoOfCalls = ClsProj.GetDataValue("tbl_Lead", "LStatusID=0 or LStatusID=1 or LStatusID=2 or LStatusID=3 or LStatusID=4 or LStatusID=5 or LStatusID=6 or LStatusID=7 or LStatusID=8 or LStatusID=9 or LStatusID=10 ");
        lblnoofcalls.Text = Convert.ToString(intNoOfCalls);
    }


    private void Search()
    {
        string strWhere = "";
        if (ddlCalling.SelectedIndex > 0)
        {

            strWhere += " AND UserID=" + ddlCalling.SelectedValue;
        }


        strWhere += " AND LastCallDate between '" + txtSD.Text + "' AND '" + txtED.Text + "'";


        string strQuery = "select * from tbl_Lead where 1=1" + strWhere;

        DataTable dt = new DataTable();

			dt = ClsProj.GetCondata(strQuery);

        if(dt.Rows.Count>0)
        {
            //int i = 0;

            for(int i=0; i< dt.Rows.Count; i++)
            {

        
            int LeadStatus = clsPrecaution.GetInt_Zero(dt.Rows[i]["LStatusID"]);

            if(LeadStatus==1)
            {
                int intRingingCalls = ClsProj.GetDataValue("tbl_Lead", "LStatusID=1");
                lblring.Text = Convert.ToString(intRingingCalls);
            }
            else if (LeadStatus==2)
            {
                int intBusyCalls = ClsProj.GetDataValue("tbl_Lead", "LStatusID=2");
                lblbusy.Text = Convert.ToString(intBusyCalls);

            }
            else if (LeadStatus == 3)
            {
                int intNotReachCalls = ClsProj.GetDataValue("tbl_Lead", "LStatusID=3");
                lblnotreach.Text = Convert.ToString(intNotReachCalls);
            }
            else if (LeadStatus == 4)
            {
                int intdisconnectCalls = ClsProj.GetDataValue("tbl_Lead", "LStatusID=4");
                lbldisconnect.Text = Convert.ToString(intdisconnectCalls);
            }
            else if (LeadStatus == 5)
            {
                int intWrongCalls = ClsProj.GetDataValue("tbl_Lead", "LStatusID=5");
                lblwrongNo.Text = Convert.ToString(intWrongCalls);
            }
            else if (LeadStatus == 6)
            {
                int intSwitchoffCalls = ClsProj.GetDataValue("tbl_Lead", "LStatusID=6");
                lblswitchoff.Text = Convert.ToString(intSwitchoffCalls);
            }
            else if (LeadStatus == 7)
            {
                int intCallBackCalls = ClsProj.GetDataValue("tbl_Lead", "LStatusID=7");
                lblcalback.Text = Convert.ToString(intCallBackCalls);
            }
            else if (LeadStatus == 8)
            {
                int intConvertCalls = ClsProj.GetDataValue("tbl_Lead", "LStatusID=8");
                lblconverted.Text = Convert.ToString(intConvertCalls);
            }
            else if (LeadStatus == 9)
            {
                int intDNDCalls = ClsProj.GetDataValue("tbl_Lead", "LStatusID=9");
                lblDND.Text = Convert.ToString(intDNDCalls);

               
            }
            else if (LeadStatus == 10)
            {
                int intNotInterestCalls = ClsProj.GetDataValue("tbl_Lead", "LStatusID=10");
                lblnotinterested.Text = Convert.ToString(intNotInterestCalls);
            }

            }

        }

       
    }


    private void BindDropdown()
    {
        tbl_User objLead = new tbl_User();
		objLead.WhereClause = "UserType=4";
        DataTable dtbl1 = objLead.Select();
        ddlCalling.DataSource = dtbl1;
        ddlCalling.DataTextField = "UserName";
        ddlCalling.DataValueField = "UserID";
        ddlCalling.DataBind();
        ddlCalling.Items.Insert(0, "Select UserName");


    }



    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Search();
    }
}