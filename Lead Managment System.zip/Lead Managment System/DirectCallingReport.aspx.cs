﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class DirectCallingReport : System.Web.UI.Page
{
	
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			ShowUpcomingCall();
			BindDropdown();
			BindDropdownStatus();
			BindDropdownSource();

		}
	}


	public void ShowUpcomingCall()
	{

		tbl_Lead seldata = new tbl_Lead();
		seldata.OrderBy = "LeadID asc";
		DataTable dtbl = new DataTable();
		dtbl = seldata.Select();
		Gridview1.DataSource = dtbl;
		Gridview1.DataBind();
		//ClsLead.SelectAllLead(GridView1);
	}


	//protected void ddlLeadStatus_SelectedIndexChanged(object sender, EventArgs e)
	//{
	//    DropDownList ddlSellist = (DropDownList)sender;
	//    GridViewRow gvrow = (GridViewRow)ddlSellist.NamingContainer;
	//    int index = gvrow.RowIndex;
	//    DropDownList ddlLeadStatus = (DropDownList)Gridview1.Rows[index].FindControl("ddlLeadStatus");
	//    Response.Redirect("AddActivityCalls.aspx");
	//}










	//protected void Gridview1_RowDataBound(object sender, GridViewRowEventArgs e)
	//{
	//	if (e.Row.RowType == DataControlRowType.DataRow)
	//	{
	//		tbl_LeadStatus objLeadstatus = new tbl_LeadStatus();
	//		objLeadstatus.OrderBy = "LStatusID";
	//		DataTable dtbl = objLeadstatus.Select();

	//		if (dtbl.Rows.Count > 0)
	//		{
	//			DropDownList ddlLeadStatus = (DropDownList)e.Row.FindControl("ddlLeadStatus");
	//			HiddenField hdnval = (HiddenField)e.Row.FindControl("hdnprice");

	//			ddlLeadStatus.DataSource = dtbl;
	//			ddlLeadStatus.DataTextField = "StatusName";
	//			ddlLeadStatus.DataValueField = "LStatusID";
	//			ddlLeadStatus.DataBind();
	//			ddlLeadStatus.Items.Insert(0, "Select Status");
	//		}
	//	}
	//}


	public void BindDropdown()
	{
		tbl_User objuser = new tbl_User();
		DataTable dtbl = objuser.Select();
		ddlCalling.DataSource = dtbl;
		ddlCalling.DataTextField = "UserName";
		ddlCalling.DataValueField = "UserID";
		ddlCalling.DataBind();
		ddlCalling.Items.Insert(0, "Select User");
	}

	public void BindDropdownStatus()
	{
		tbl_LeadStatus objstatus = new tbl_LeadStatus();
		DataTable dtbl = objstatus.Select();
		ddlStatus.DataSource = dtbl;
		ddlStatus.DataTextField = "StatusName";
		ddlStatus.DataValueField = "LStatusID";
		ddlStatus.DataBind();
		ddlStatus.Items.Insert(0, "Select Status");
	}

	public void BindDropdownSource()
	{
		tbl_Source objsource = new tbl_Source();
		DataTable dtbl = objsource.Select();
		ddlSource.DataSource = dtbl;
		ddlSource.DataTextField = "SourceName";
		ddlSource.DataValueField = "SourceID";
		ddlSource.DataBind();
		ddlSource.Items.Insert(0, "Select Source");
	}

	private void Search()
	{
		string strWhere = "";
		if (ddlCalling.SelectedIndex > 0)
		{

			strWhere += " AND UserID=" + ddlCalling.SelectedValue;
		}

		if (ddlStatus.SelectedIndex > 0)
		{
			strWhere += " AND LStatusID= " + ddlStatus.SelectedValue;
		}

		if (ddlSource.SelectedIndex > 0)
		{
			strWhere += " AND SourceID= " + ddlSource.SelectedValue;
		}


		strWhere += " AND LastCallDate between '" + txtSD.Text + "' AND '" + txtED.Text + "'";


		string strQuery = "select * from tbl_Lead where 1=1" + strWhere;

		DataTable dt = new DataTable();

		dt = ClsProj.GetCondata(strQuery);

		Gridview1.DataSource = dt;
		Gridview1.DataBind();
	}


	protected void btnSearch_Click(object sender, EventArgs e)
	{
		Search();
	}

	protected void btnETE_Click(object sender, EventArgs e)
	{

	}

	protected void ddlLeadStatus_SelectedIndexChanged(object sender, EventArgs e)
	{

	}

	protected void Gridview1_PageIndexChanged(object sender, GridViewPageEventArgs e)
	{
		Gridview1.PageIndex = e.NewPageIndex;
		ShowUpcomingCall();
	}

}