	<?php
error_reporting(0);
  
$cn=mysql_connect("localhost","root","");
mysql_select_db("lms",$cn);
 
?>
