﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SalesStatus : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            ShowStatus();
        }
    }

    public void ShowStatus()
    {
        ClsSalesStatus.SelectAllLeadStatus(Gridview1);
    }

	protected void btnadd_Click(object sender, EventArgs e)
	{
		Response.Redirect("AddSaleStatus.aspx");
	}

	protected void btnEdit_Click(object sender, EventArgs e)
	{
		LinkButton lnkbtn = (LinkButton)sender;
		int ID = Convert.ToInt32(lnkbtn.CommandArgument);
		Response.Redirect("AddSaleStatus.aspx?SstatusID="+ ID);
	}
	

	protected void btnDelete_Click(object sender, EventArgs e)
	{
		LinkButton Dbutn = (LinkButton)sender;
		int ID = Convert.ToInt32(Dbutn.CommandArgument);

		tbl_SaleStatus objdlete = new tbl_SaleStatus();
		objdlete.WhereClause = "SstatusID=" + ID;
		objdlete.Delete();
	}
}