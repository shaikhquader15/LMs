﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Component;
using System.Data;

public partial class AddStage : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			EditLeadStage();
			BindStage();
		}
	}

	protected void btnsave_Click(object sender, EventArgs e)
	{
		string strstagename = clsPrecaution.GetStr_Empty(txtstagename.Text);
		string strpercentage = clsPrecaution.GetStr_Empty(txtpercent.Text);
		int intstageid = clsPrecaution.GetInt_Zero(ddlStage.Text);

		if (btnsave.Text == "Save")
		{
			ClsLeadStageMaster.AddLeadStage(strstagename, strpercentage, intstageid);
			Response.Redirect("LeadStageMaster.aspx");
		}
		else
		{
			if (Request.QueryString["LStageID"] != null)
			{
				int LstageID = clsPrecaution.GetInt_Zero(Request.QueryString["LStageID"]);
				ClsLeadStageMaster.UpdateLeadStage(LstageID, strstagename, strpercentage,intstageid);
				Response.Redirect("LeadStageMaster.aspx");
			}
		}

	}

	public void EditLeadStage()
	{
		tbl_LeadStageMaster objedit = new tbl_LeadStageMaster();
		int lstageid = clsPrecaution.GetInt_Zero(Request.QueryString["LStageID"]);
		objedit.WhereClause = "LStageID=" + lstageid;
		DataTable dtlead = objedit.Select();


		if (dtlead.Rows.Count > 0)
		{
			txtstagename.Text = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["LStageName"]);
			txtpercent.Text = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["LPercentage"]);
			//ddlStage.SelectedItem.Value = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["StageID"]);
			//ddlStage.SelectedItem.Value = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["StageID"]);
			btnsave.Text = "Update";

		}
	}

	public void BindStage()
	{
		tbl_EmailFormat obj = new tbl_EmailFormat();
		DataTable dtbl = obj.Select();
		ddlStage.DataSource = dtbl;
		ddlStage.DataValueField = "StageID";
		ddlStage.DataTextField = "StageName";
		ddlStage.DataBind();
		ddlStage.Items.Insert(0, "Select Email Format");
	}
}