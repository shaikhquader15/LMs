﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class ExternalFieldMaster : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			BindGrid();
			//EditExternalFields();
			mv.ActiveViewIndex = 0;
			if (Request.QueryString != null)
			{
				//int externalid = clsPrecaution.GetInt_Zero(Request.QueryString["ExternalID"]);
				EditExternalFields();
			}

		}
	}

	public void BindGrid()
	{
		tbl_ExternalFields seldata = new tbl_ExternalFields();
		seldata.OrderBy = "ExternalID";
		DataTable dtbl = new DataTable();
		dtbl = seldata.Select();
		Gridview1.DataSource = dtbl;
		Gridview1.DataBind();
	}

	protected void btnadd_Click(object sender, EventArgs e)
	{
		mv.ActiveViewIndex = 1;
	}

	protected void btnback_Click(object sender, EventArgs e)
	{
		mv.ActiveViewIndex = 0;
	}


	protected void btnSave_Click(object sender, EventArgs e)
	{
		string strfld = clsPrecaution.GetStr_Empty(txtfld.Text.Trim());
		ClsExternalFields.AddFields(strfld);
		mv.ActiveViewIndex = 0;
		if (Request.QueryString != null)
		{
			int externalid = clsPrecaution.GetInt_Zero(Request.QueryString["ExternalID"]);
			ClsExternalFields.UpdateFields(externalid, strfld);
		}
	}

	public void EditExternalFields()
	{
		
		int externalid = clsPrecaution.GetInt_Zero(Request.QueryString["ExternalID"]);
		tbl_ExternalFields objfiled = new tbl_ExternalFields();
		objfiled.WhereClause = "ExternalID=" + externalid;
		DataTable dt = objfiled.Select();
		

		if (dt.Rows.Count > 0)
		{
			txtfld.Text = clsPrecaution.GetStr_Empty(dt.Rows[0]["ExternalFieldName"]);
			btnSave.Text = "Update";

		}
	}

	protected void btnEdit_Click(object sender, EventArgs e)
	{		
		LinkButton lbutn = (LinkButton)sender;
		int ID = Convert.ToInt32(lbutn.CommandArgument);
		mv.ActiveViewIndex = 0;
		Response.Redirect("ExternalFieldMaster.aspx?ExternalID=" + ID);	
	}

	protected void btnDelete_Click(object sender, EventArgs e)
	{
		LinkButton Dbutn = (LinkButton)sender;
		int ID = Convert.ToInt32(Dbutn.CommandArgument);

		tbl_ExternalFields objdlete = new tbl_ExternalFields();
		objdlete.WhereClause = "ExternalID=" + ID;
		objdlete.Delete();
		if (Session["UserID"] != null)
		{
			if (Session["UserType"] != null)
			{
				BindGrid();
			}
		}
	}
}