﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UpdateProfile : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			if (Session["UserID"] != null)
			{
				EditProfile();
			}
		}
	}

	protected void btnAdd_Click(object sender, EventArgs e)
	{

		int UserID = clsPrecaution.GetInt_Zero(Session["UserID"].ToString());

		string FilePath = "";
		if (fupimg.HasFile)
		{
			string fileName = Path.GetFileName(fupimg.PostedFile.FileName);
			fupimg.PostedFile.SaveAs(Server.MapPath("~/img/") + fileName);
			FilePath = "~/img/" + fileName.ToString();
			//Response.Redirect(Request.Url.AbsoluteUri);
		}

		Hashtable hstbl = new Hashtable();
		hstbl.Add("FirstName", clsPrecaution.GetStr_Null(txtfname.Text));
		hstbl.Add("LastName", clsPrecaution.GetStr_Null(txtlname.Text));
		hstbl.Add("UserName", clsPrecaution.GetStr_Null(txtusername.Text));
		hstbl.Add("Password", clsPrecaution.GetStr_Null(txtpass.Text));
		hstbl.Add("EmailAddress", clsPrecaution.GetStr_Null(txtemail.Text));
		hstbl.Add("Address", clsPrecaution.GetStr_Null(txtaddress.Text));
		hstbl.Add("Contact", clsPrecaution.GetStr_Null(txtcontact.Text));
		if (fupimg.HasFile)
		{
			hstbl.Add("ProfImage", FilePath);
		}

		tbl_User objup = new tbl_User();
		objup.Data = hstbl;
		objup.WhereClause = "UserID=" + UserID;
		objup.Update();




	}

	public void EditProfile()
	{
		int UserID = clsPrecaution.GetInt_Zero(Session["UserID"].ToString());

		tbl_User obj = new tbl_User();
		obj.WhereClause = "UserID=" + UserID;
		DataTable dtbl = obj.Select();
		if (dtbl.Rows.Count > 0)
		{
			txtfname.Text = clsPrecaution.GetStr_Null(dtbl.Rows[0]["FirstName"]);
			txtlname.Text = clsPrecaution.GetStr_Null(dtbl.Rows[0]["LastName"]);
			txtusername.Text = clsPrecaution.GetStr_Null(dtbl.Rows[0]["UserName"]);
			txtemail.Text = clsPrecaution.GetStr_Null(dtbl.Rows[0]["EmailAddress"]);
			txtpass.Text = clsPrecaution.GetStr_Null(dtbl.Rows[0]["Password"]);
			txtconpass.Text = clsPrecaution.GetStr_Null(dtbl.Rows[0]["Password"]);
			txtaddress.Text = clsPrecaution.GetStr_Null(dtbl.Rows[0]["Address"]);
			txtcontact.Text = clsPrecaution.GetStr_Null(dtbl.Rows[0]["Contact"]);


		}
	}
}