﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class FollowUp : System.Web.UI.Page
{
	protected void Page_PreInit(Object sender, EventArgs e)
	{
		ClsProj.GetMasterPage(this);

	}

	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			if (Session["UserID"] != null)
			{
				if (Session["UserType"] != null)
				{
					ShowUpcomingCall();
					ShowReminder();
					BindDropdown();
					LeadUser();
					GetAddCall();


				}
			}

			
			//DropDownList ddlLeadStatus = null;
			//ClsLead.BindLeadStatus(ddlLeadStatus);
		}
	}

	public void GetAddCall()
	{
		int usertype = clsPrecaution.GetInt_Zero(Session["UserType"].ToString());
		int Statusid = clsPrecaution.GetInt_Zero(Request.QueryString["s"]);
		if (usertype == 4)
		{
			if (Statusid == 1)
			{
				lbladdcall.Visible = true;
			}
			else
				lbladdcall.Visible = false;
		}
			
	}

	public void ShowUpcomingCall()
	{
		int intuser = clsPrecaution.GetInt_Zero(Session["UserID"].ToString());
		int intusertype = clsPrecaution.GetInt_Zero(Session["UserType"].ToString());

		string strquery = "";

		//		if (intusertype == 1 && intusertype == 2) // Admin & LeadMgr
		//		{
		//			strquery = @"select tbl_Lead.LeadID, tbl_Lead.SourceID,tbl_Lead.LStatusID,tbl_Lead.LeadName,tbl_Lead.Email1,tbl_Lead.Contact1,tbl_Source.SourceName,tbl_LeadStatus.StatusName From tbl_Lead
		//inner Join tbl_Source on tbl_Lead.SourceID = tbl_Source.SourceID
		//inner Join tbl_LeadStatus on tbl_Lead.LStatusID = tbl_LeadStatus.LStatusID where tbl_Lead.LStatusID=7";
		//		 // and UserType=" + intusertype;
		//		}
		//		else
		//		{
		//			strquery = @"select tbl_Lead.LeadID, tbl_Lead.SourceID,tbl_Lead.LStatusID,tbl_Lead.LeadName,tbl_Lead.Email1,tbl_Lead.Contact1,tbl_Source.SourceName,tbl_LeadStatus.StatusName From tbl_Lead
		//inner Join tbl_Source on tbl_Lead.SourceID = tbl_Source.SourceID
		//inner Join tbl_LeadStatus on tbl_Lead.LStatusID = tbl_LeadStatus.LStatusID where tbl_Lead.LStatusID=7 and UserID=" + intuser; // + "and UserType=" + intusertype;
		//		}

		//		DataTable dtbl = new DataTable();
		//		dtbl = ClsProj.GetCondata(strquery);
		if (Request.QueryString!=null)
		{
			tbl_Lead objfollow = new tbl_Lead();
			tbl_Status obj = new tbl_Status();
			obj.WhereClause = "StatusID=" + Request.QueryString["s"];
			lbltitle.Text = obj.Select().Rows[0]["StatusName"].ToString();
			//			strquery = @"
			//SELECT* FROM tbl_Lead t1
			//inner join tbl_LeadStatus ON t1.LStatusID = tbl_LeadStatus.StatusID
			//  WHERE UserID =" + intuser + " and tbl_LeadStatus.StatusID = " + Request.QueryString["s"] + " and IsDelete = 0 ORDER BY LeadID";
			objfollow.OrderBy = "LeadID";
			objfollow.WhereClause = "UserID=" + intuser + "and LStatusID in (select LStatusID from tbl_LeadStatus where StatusID=" + Request.QueryString["s"] + ") and IsDelete=0";
			//DataTable dtbl = ClsProj.GetCondata(strquery);
			DataTable dtbl = objfollow.Select();

			Gridview1.DataSource = dtbl;
			Gridview1.DataBind();
			//ClsLead.SelectAllLead(GridView1);
		}
	}
	public void LeadUser()
	{
		int intusertype = clsPrecaution.GetInt_Zero(Session["UserType"].ToString());
		if (intusertype == 1 || intusertype == 2)
		{
			divuser.Visible = true;
		}
		else
			divuser.Visible = false;
	}

	public void ShowReminder()
	{
		String StrLeadName = "";
		String strCallTime = "";
		int UserID = clsPrecaution.GetInt_Zero(Session["UserID"].ToString());
		tbl_Lead obj = new tbl_Lead();
		obj.WhereClause = "UserID=" + UserID;
		DataTable dtshow = obj.Select();
		if (dtshow.Rows.Count > 0)
		{
			string calltime = clsPrecaution.GetStr_Empty(dtshow.Rows[0]["NextCallDate"]);
			string strcaltime = ClsProj.GetMMDD_Current(calltime);

			String strDate = clsPrecaution.GetStr_Empty(DateTime.Now.ToString("yyyy-MM-dd"));
			string dttime = ClsProj.GetMMDD_Current(strDate);

			if (strcaltime == dttime)
			{
				String strquery = "select Top 1 * from tbl_Lead where NextCalldate='" + dttime + "'Order By NextCallTime Desc";
				DataTable dtre = ClsProj.GetCondata(strquery);
				if (dtre.Rows.Count > 0)
				{
					StrLeadName = clsPrecaution.GetStr_Null(dtre.Rows[0]["LeadName"]);
					strCallTime = clsPrecaution.GetStr_Null(dtre.Rows[0]["NextCallTime"]);
					//lblleadname.Visible = true;
					//lblremindertime.Visible = true;
					//lblcaller.Visible = true;
					//lblcallertime.Visible = true;
					lblnoti.Visible = true;

				}
				
				lblremindertime.Text = strCallTime;
				lblleadname.Text = StrLeadName;
			}

		}
	}

	protected void ddlLeadStatus_SelectedIndexChanged(object sender, EventArgs e)
	{
		DropDownList ddlSellist = (DropDownList)sender;
		GridViewRow gvrow = (GridViewRow)ddlSellist.NamingContainer;
		int index = gvrow.RowIndex;
		Label lblLeadID = (Label)Gridview1.Rows[index].FindControl("lblLeadId");

		int sid = clsPrecaution.GetInt_Zero(ddlSellist.SelectedItem.Value);
		string strleadname = clsPrecaution.GetStr_Empty(ddlSellist.SelectedItem.Text);

		if (sid == 7)
		{
			Response.Redirect("AddCallBack.aspx?ld=" + lblLeadID.Text + "&ls=" + sid + "&sn=" + strleadname);
		}
		else if (sid == 8)
		{
			Response.Redirect("AddAppointment.aspx?ld=" + lblLeadID.Text + "&ls=" + sid + "&sn=" + strleadname);
		}
		else
		{
			Response.Redirect("AddActivityCalls.aspx?ld=" + lblLeadID.Text + "&ls=" + sid + "&sn=" + strleadname);
		}
	}










	protected void Gridview1_RowDataBound(object sender, GridViewRowEventArgs e)
	{
		if (e.Row.RowType == DataControlRowType.DataRow)
		{
			tbl_LeadStatus objLeadstatus = new tbl_LeadStatus();
			DataTable dtbl = objLeadstatus.Select();

			if (dtbl.Rows.Count > 0)
			{
				DropDownList ddlLeadStatus = (DropDownList)e.Row.FindControl("ddlLeadStatus");
				HiddenField hdnval = (HiddenField)e.Row.FindControl("hdnprice");
				

				ddlLeadStatus.DataSource = dtbl;
				ddlLeadStatus.DataTextField = "StatusName";
				ddlLeadStatus.DataValueField = "LStatusID";
				ddlLeadStatus.DataBind();
				ddlLeadStatus.Items.Insert(0, "Select Status");
				if (hdnval.Value != "0")
				{
					ddlLeadStatus.Items.FindByValue(hdnval.Value).Selected = true;
				}
				//ddlLeadStatus.Items.FindByValue(hdnval.Value).Selected = true;
			}
		}
	}

	protected void btnEdit_Click(object sender, EventArgs e)
	{
		LinkButton objlknbtn = (LinkButton)sender;
		int ID = Convert.ToInt32(objlknbtn.CommandArgument);
		Response.Redirect("AddCalls.aspx?LeadID=" + ID);
	}


	private void BindDropdown()
	{
		tbl_User objLead = new tbl_User();
		DataTable dtbl1 = objLead.Select();
		ddlUserName.DataSource = dtbl1;
		ddlUserName.DataTextField = "UserName";
		ddlUserName.DataValueField = "UserID";
		ddlUserName.DataBind();
		ddlUserName.Items.Insert(0, "Select UserName");


	}

	private void BindGrid()
	{
		string strWhere = "";


		if (ddlUserName.SelectedIndex > 0)
		{
			strWhere += "AND UserID= " + ddlUserName.SelectedValue;
		}

		strWhere += "AND LastCallDate between '" + txtSD.Text + "' AND '" + txtED.Text + "'";

		if (txtUserName.Text.Length > 1)                           //Search Textbox
		{
			strWhere += " AND UserName like '%" + txtUserName.Text + "%'";
		}

		if (txtLeadName.Text.Length > 1)                           //Search Textbox
		{
			strWhere += " AND LeadName like '%" + txtLeadName.Text + "%'";
		}

		if (txtLCD.Text.Length > 1)                           //Search Textbox
		{
			strWhere += " AND LastCallDate like '%" + txtLCD.Text + "%'";
		}

		if (txtLCT.Text.Length > 1)                           //Search Textbox
		{
			strWhere += " AND LastCallTime like '%" + txtLCT.Text + "%'";
		}

		if (txtNCD.Text.Length > 1)                           //Search Textbox
		{
			strWhere += " AND NextCallDate like '%" + txtNCD.Text + "%'";
		}

		if (txtNCT.Text.Length > 1)                           //Search Textbox
		{
			strWhere += " AND NextCallTime like '%" + txtNCT.Text + "%'";
		}

		if (txtRemark.Text.Length > 1)                           //Search Textbox
		{
			strWhere += " AND Remark like '%" + txtRemark.Text + "%'";
		}

		string strQuery = "select * from tbl_Lead where 1=1" + strWhere;

		DataTable dt = new DataTable();

		dt = ClsProj.GetCondata(strQuery);

		Gridview1.DataSource = dt;
		Gridview1.DataBind();


	}




	protected void btnSearch_Click(object sender, EventArgs e)
	{
		BindGrid();
	}

	protected void btnSearch1_Click(object sender, EventArgs e)
	{
		BindGrid();
	}

	protected void ddlUserName_SelectedIndexChanged(object sender, EventArgs e)
	{

	}

	protected void btnDelete_Click(object sender, EventArgs e)
	{
		LinkButton lnkbtn = (LinkButton)sender;
		int ID = Convert.ToInt32(lnkbtn.CommandArgument);
		Hashtable hstbl = new Hashtable();
		hstbl.Add("IsDelete", 1);
		tbl_Lead objlead = new tbl_Lead();
		objlead.Data = hstbl;
		objlead.WhereClause = "LeadID=" + ID;
		objlead.Update();
	}

	protected void Gridview1_PageIndexChanging(object sender, GridViewPageEventArgs e)
	{
		Gridview1.PageIndex = e.NewPageIndex;
		ShowUpcomingCall();
	}
}
