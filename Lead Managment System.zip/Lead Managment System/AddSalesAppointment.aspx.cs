﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddSalesAppointment : System.Web.UI.Page
{
	protected void Page_PreInit(Object sender, EventArgs e)
	{
		ClsProj.GetMasterPage(this);

	}

	int SalesID = 0;
	int StatusID = 0;
	int LeadID = 0;
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			DateTime d = new DateTime();
			d = DateTime.Now;

			txtcalldate.Text = DateTime.Now.ToString("yyyy-MM-dd");
			txtcalltime.Text = d.ToString("HH:mm:ss");

			Leadname();
			BindSaleStage();

			//ShowUpcomingCall();
			if (Session["UserID"] != null)
			{
				if (Session["UserType"] != null)
				{
					//ShowUpcomingCall();
				}
			}


		}
	}

	public void Leadname()
	{
		if (Request.QueryString["ld"] != null)
		{
			SalesID = Convert.ToInt32(Request.QueryString["ld"]);
		}
		lblSalesleadname.Text = ClsLead.GetLeadName(SalesID);
	}

	protected void btnUpdate_Click(object sender, EventArgs e)
	{
		String SStatusName = "";
		string strcontact = "";
		string strsource = "";

		if (Request.QueryString["ld"] != null)
		{
			SalesID = Convert.ToInt32(Request.QueryString["ld"]);
			LeadID = Convert.ToInt32(Request.QueryString["leadid"]);

		}
		if (Request.QueryString["ls"] != null)
		{
			StatusID = clsPrecaution.GetInt_Zero(Request.QueryString["ls"]);

			tbl_SaleStatus obj = new tbl_SaleStatus();
			obj.WhereClause = "SstatusID=" + StatusID;
			DataTable dtsal = obj.Select();
			if (dtsal.Rows.Count > 0)
			{
				SStatusName = clsPrecaution.GetStr_Empty(dtsal.Rows[0]["SstatusName"]);
				//strcontact = clsPrecaution.GetStr_Empty(dtsal.Rows[0]["Contact1"]);
				//strsource = clsPrecaution.GetStr_Empty(dtsal.Rows[0]["SourceName"]);
			}

		}

		tbl_SalesTeam objs = new tbl_SalesTeam();
		objs.WhereClause = "SalesID=" + SalesID + "and LeadID="+ LeadID;
		DataTable dtsale = objs.Select();
		if (dtsale.Rows.Count > 0)
		{
			int SUserID = clsPrecaution.GetInt_Zero(dtsale.Rows[0]["SUserID"]);
			String SUserName = clsPrecaution.GetStr_Empty(dtsale.Rows[0]["SUserName"]);
			int MID = clsPrecaution.GetInt_Zero(dtsale.Rows[0]["SMID"]);
			String SMName = clsPrecaution.GetStr_Empty(dtsale.Rows[0]["SMName"]);
			int SuserType = clsPrecaution.GetInt_Zero(dtsale.Rows[0]["SUserType"]);
			int UserID = clsPrecaution.GetInt_Zero(dtsale.Rows[0]["UserID"]);
			String UserName = clsPrecaution.GetStr_Empty(dtsale.Rows[0]["UserName"]);
			//int LeadID = clsPrecaution.GetInt_Zero(dtsale.Rows[0]["LeadID"]);
			String LeadName = clsPrecaution.GetStr_Empty(dtsale.Rows[0]["LeadName"]);
			int SourceId = clsPrecaution.GetInt_Zero(dtsale.Rows[0]["SourceID"]);
			String SourceName = clsPrecaution.GetStr_Empty(dtsale.Rows[0]["SourceName"]);
			string StatusName = clsPrecaution.GetStr_Empty(dtsale.Rows[0]["SstatusName"]);
			String Product = clsPrecaution.GetStr_Empty(dtsale.Rows[0]["Product"]);

			string strlcaldate = clsPrecaution.GetStr_Null(txtcalldate.Text);
			String strcaltime = clsPrecaution.GetStr_Null(txtcalltime.Text);
			string straptdate = clsPrecaution.GetStr_Null(txtaptdate.Text);
			string strapttime = clsPrecaution.GetStr_Null(txtapttime.Text);
			string straddress = clsPrecaution.GetStr_Null(txtaddress.Text);
			String strremark = clsPrecaution.GetStr_Null(txtremark.Text);
			int intstageid = clsPrecaution.GetInt_Zero(ddlStage.SelectedValue);
			string strstagename = clsPrecaution.GetStr_Empty(ddlStage.SelectedItem.Text);
			string strpercent = clsPrecaution.GetStr_Empty(txtpercentage.Text);

			ClsSalesTeam.UpdateSales(SalesID, SUserID, SUserName, MID, SMName, SuserType, UserID, UserName, LeadID, LeadName, SourceId, SourceName, strlcaldate, strcaltime, straddress, Product, strremark, StatusID, SStatusName, straptdate, strapttime, intstageid, strstagename, strpercent);
			clsSalesLog.InsertLeadDeatilsAddSalesAppointment(LeadID, LeadName, StatusID, StatusName, straddress, strsource, strlcaldate, strcaltime, straptdate, strapttime, strremark);
			string message = "Data Sent Successfully";

			ShowMessage(message);
			//Response.Redirect("SalesFollowUp.aspx");
            

		}

	}

	public void BindSaleStage()
	{
		tbl_SalesStageMaster objssm = new tbl_SalesStageMaster();
		objssm.OrderBy = "SStageID";
		DataTable dt = objssm.Select();
		ddlStage.DataSource = dt;
		ddlStage.DataTextField = "SStageName";
		ddlStage.DataValueField = "SStageID";
		ddlStage.DataBind();
		ddlStage.Items.Insert(0, "Select Stage");
	}


	public void ShowMessage(String message)
	{
		System.Text.StringBuilder sb = new System.Text.StringBuilder();

		sb.Append("<script type = 'text/javascript'>");

		sb.Append("window.onload=function(){");

		sb.Append("alert('");

		sb.Append(message);

		sb.Append("')};");

		sb.Append("</script>");

		ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
	}
}