﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddCallBack : System.Web.UI.Page
{
	protected void Page_PreInit(Object sender, EventArgs e)
	{
		ClsProj.GetMasterPage(this);

	}
	int LeadID = 0;
	String strleadname = "";
	int StatusID = 0;
	String strStatusName = "";
	string strcontact = "";
	string strsource = "";
	protected void Page_Load(object sender, EventArgs e)
    {
		if (!Page.IsPostBack)
		{
			Leadname();
			BindLeadStage();

			DateTime d = new DateTime();
			d = DateTime.Now;

			txtcalldate.Text = DateTime.Now.ToString("yyyy-MM-dd");
			txtcalltime.Text = d.ToString("HH:mm:ss");
		}
    }

	public void BindLeadStage()
	{
		ClsLeadStageMaster.StageDropdown(ddlstage);
	}

	public void Leadname()
	{
		if (Request.QueryString["ld"] != null)
		{
			LeadID = Convert.ToInt32(Request.QueryString["ld"]);
		}
		lblleadname.Text = ClsLead.GetLeadName(LeadID);
		strleadname = ClsLead.GetLeadName(LeadID);

	}

	public void StatusName()
	{
		if (Request.QueryString["ls"] != null)
		{
			StatusID = clsPrecaution.GetInt_Zero(Request.QueryString["ls"]);
		}
		strStatusName = ClsLead.GetStatusName(StatusID);
	}

	

    protected void btnUpdate_Click(object sender, EventArgs e)
	{
		

		if (Request.QueryString["ld"] != null)
		{
			LeadID = Convert.ToInt32(Request.QueryString["ld"]);
		}
		if (Request.QueryString["ls"] != null)
		{
			StatusID = clsPrecaution.GetInt_Zero(Request.QueryString["ls"]);
		}

		tbl_Lead objlead = new tbl_Lead();
		objlead.WhereClause = "LeadID=" + LeadID;
		DataTable dt = objlead.Select();
		if (dt.Rows.Count > 0)
		{
			strcontact = clsPrecaution.GetStr_Empty(dt.Rows[0]["Contact1"]);
			strsource = clsPrecaution.GetStr_Empty(dt.Rows[0]["SourceName"]);
		}
		strleadname = ClsLead.GetLeadName(LeadID);
		strStatusName = ClsLead.GetStatusName(StatusID);

		ClsLead.GetLeadName(LeadID);

		string strlcaldate = clsPrecaution.GetStr_Null(txtcalldate.Text);
		String strcaltime = clsPrecaution.GetStr_Null(txtcalltime.Text);
		string strncaldate = clsPrecaution.GetStr_Null(txtncaldate.Text);
		string strncaltime = clsPrecaution.GetStr_Null(txtcalltime.Text);
		String strremark = clsPrecaution.GetStr_Null(txtremark.Text);
		int intstageid = clsPrecaution.GetInt_Zero(ddlstage.SelectedValue);
		string strlstagename = clsPrecaution.GetStr_Empty(ddlstage.SelectedItem.Text);
		
		clsLeadLog.InsertLeadDeatilsAddCallBack(LeadID, strleadname, StatusID, strStatusName, strcontact, strsource, strlcaldate, strcaltime, strncaldate, strncaltime, strremark, intstageid, strlstagename,"");
        ClsLead.GetLeadDetailsforAddCallBack(LeadID, StatusID,strStatusName,strlcaldate, strcaltime, strncaldate, strncaltime, strremark);
		Response.Redirect("FollowUp.aspx");

    }

	
}