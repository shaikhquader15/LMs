﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ImportedData : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            showLeadData();
            BinduserType();
            BindSource();
        }
    }

    public void showLeadData()
    {
        tbl_Data obj = new tbl_Data();
		obj.WhereClause = "Flag=0";
        DataTable dtbl = obj.Select();
        Gridview_s.DataSource = dtbl;
        Gridview_s.DataBind();
    }

    protected void ddlusertype_SelectedIndexChanged(object sender, EventArgs e)
    {



        if (ddlusertype.SelectedIndex > 0)
        {
            int userid = clsPrecaution.GetInt_Zero(ddlusertype.SelectedItem.Value);


            ClsUser.binduser(ddluser, userid);

            //tbl_User objuser = new tbl_User();
            //objuser.WhereClause = "UserType=" + userid;
            //DataTable dtuser = objuser.Select();
            //ddluser.DataSource = dtuser;
            //ddluser.DataTextField = "UserName";
            //ddluser.DataValueField = "UserID";
            //ddluser.DataBind();
            //ddluser.Items.Insert(0, "Please Select");
        }


    }

    public void BinduserType()
    {
        ClsUser.bindUserType(ddlusertype);

        //tbl_UserType obj = new tbl_UserType();
        //DataTable dtut = obj.Select();
        //ddlusertype.DataSource = dtut;
        //ddlusertype.DataTextField = "UserName";
        //ddlusertype.DataValueField = "UserType";
        //ddlusertype.DataBind();
        //ddlusertype.Items.Insert(0, "--Select Usertype--");
    }

    public void BindSource()
    {
       
        tbl_Source objstatus = new tbl_Source();
        objstatus.OrderBy = "SourceID";
        DataTable dtstatus = objstatus.Select();
        ddlsource.DataSource = dtstatus;
        ddlsource.DataTextField = "SourceName";
        ddlsource.DataValueField = "SourceID";
        ddlsource.DataBind();
        ddlsource.Items.Insert(0, "--Select Source--");
    
}

    //protected void ddluser_SelectedIndexChanged(object sender, EventArgs e)
    //{

    //    int userid = clsPrecaution.GetInt_Zero(ddlusertype.SelectedIndex);

    //    tbl_User objuser = new tbl_User();
    //    objuser.WhereClause = "UserType=" + userid;
    //    DataTable dtuser = objuser.Select();
    //    ddluser.DataSource = dtuser;
    //    ddluser.DataTextField = "UserName";
    //    ddluser.DataValueField = "UserID";
    //    ddluser.DataBind();
    //    ddluser.Items.Insert(0, "Please Select");
    //}

    protected void btnAssign_Click(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();
        dt.Columns.AddRange(new DataColumn[12]
        {
			new DataColumn("dataID"),
			new DataColumn("LeadName"),
            new DataColumn("Type"),
            new DataColumn("Email1"),
            new DataColumn("Contact1"),
            new DataColumn("Landline1"),
            new DataColumn("Address1"),
            new DataColumn("Pincode"),
            new DataColumn("City"),
            new DataColumn("State"),
            new DataColumn("Country"),
            new DataColumn("SourceName"),

        }
        );
        foreach (GridViewRow row in Gridview_s.Rows)
        {
			//GridViewRow trow = Gridview_s.SelectedRow;
			//int rowid = trow.RowIndex;

			if (row.RowType == DataControlRowType.DataRow)
            {
                CheckBox chkRow = (row.Cells[0].FindControl("chkRow") as CheckBox);
                if (chkRow.Checked)
                {

					Label lbdataID = (row.Cells[1].FindControl("lbldataID") as Label);
					//int rowindex=clsPrecaution.GetInt_Zero(
					string SDataID = lbdataID.Text;//row.Cells[1].Text;

					string LeadName = row.Cells[2].Text;
                    string Type = row.Cells[3].Text;
                    //string Type = (row.Cells[2].FindControl("lblCountry") as Label).Text;
                    string Email1 = row.Cells[4].Text;
                    string Contact1 = row.Cells[5].Text;
                    string Landline1 = row.Cells[6].Text;
                    string Address1 = row.Cells[7].Text;
                    string Pincode = row.Cells[8].Text;
                    string City = row.Cells[9].Text;
                    string State = row.Cells[10].Text;
                    string Country = row.Cells[11].Text;
                    string Source = row.Cells[12].Text;

                    int DataID = clsPrecaution.GetInt_Zero(SDataID);


                    int intusertype = clsPrecaution.GetInt_Zero(ddlusertype.SelectedItem.Value);
                    int intuser = clsPrecaution.GetInt_Zero(ddluser.SelectedItem.Value);
                    String strUserName = clsPrecaution.GetStr_Empty(ddluser.SelectedItem.Text);

                    int intsource = clsPrecaution.GetInt_Zero(ddlsource.SelectedItem.Value);
                    String strsource = clsPrecaution.GetStr_Empty(ddlsource.SelectedItem.Text);

                    //dt.Rows.Add(name, country);
                    //ClsLead.AddLeads(intuser,LeadName,Type,Email1,"",Contact1,intusertype,"",Landline1,"",Address1,"",Pincode,City,State,Country,0,"","","","","","","",0,"","");

                    //ClsLead.AddLeads(0, intuser, strUserName,"", LeadName, Type, Email1, "", Contact1, intusertype, "", Landline1, "", Address1, "", Pincode, City, State, Country, 0, "", "", "", "", "", "", "", 0, Source, "", "","");
                    ClsData.UpdateLeads(DataID, intuser, strUserName, LeadName, Type, Email1, intusertype, "", Contact1, "", Landline1, "", Address1, "", Pincode, City,State, Country, intsource, strsource);
					string message = "Leads Sent Successfully";
					ShowMessage(message);
				}
            }
        }
        Gridview_s.DataSource = dt;
        Gridview_s.DataBind();
    }

	public void ShowMessage(String message)
	{
		System.Text.StringBuilder sb = new System.Text.StringBuilder();

		sb.Append("<script type = 'text/javascript'>");

		sb.Append("window.onload=function(){");

		sb.Append("alert('");

		sb.Append(message);

		sb.Append("')};");

		//sb.Append("window.location.href=UpcomingCalls.aspx");

		sb.Append("</script>");


		ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
	}
	protected void ddlsource_SelectedIndexChanged(object sender, EventArgs e)
    {
        int intSourceID = clsPrecaution.GetInt_Zero(ddlsource.SelectedItem.Value);

    
    
        tbl_Data obj = new tbl_Data();
        obj.WhereClause = "SourceID=" + intSourceID + "and flag=0";
        DataTable dtbl = obj.Select();
        Gridview_s.DataSource = dtbl;
        Gridview_s.DataBind();
    
        
    }
}