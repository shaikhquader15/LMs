﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ImportData : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!Page.IsPostBack)
        {
            bindLeadStatus();
			BindLeadState();
			BindCountry();
		}
    }
    DataSet ds = new DataSet();
    protected void btnupload_Click(object sender, EventArgs e)
    {
        if (fudoc.HasFile)
        {
            try
            {
                string path = fudoc.FileName;
                fudoc.SaveAs(Server.MapPath("~/ExcelUploads/" + path));
                OleDbConnection oconn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Server.MapPath("~/ExcelUploads/" + path) + ";Extended Properties=Excel 12.0;");
                oconn.Open();
                //Getting records from Sheet1 of excel file. As you know one excel file may have many sheets                    
                OleDbCommand ocmd = new OleDbCommand("select * from [Sheet1$]", oconn);
                // DataSet ds = new DataSet();
                OleDbDataAdapter odapt = new OleDbDataAdapter(ocmd);
                odapt.Fill(ds);
                // when data not getting in or from DataTable then use Session to fetch data.
                Session["Data"] = ds;
                Gridview_s.DataSource = ds;
                Gridview_s.DataBind();
                oconn.Close();
            }
            catch (Exception exp)
            {
                throw exp;
            }
            btnSave.Visible = true;
            lblupmsg.Visible = true;
        }
        else
        {
            Response.Write("<script>alert('Please Select File to Upload')</script>");
        }
    }

    public void bindLeadStatus()
    {
        tbl_Source objstatus = new tbl_Source();
        objstatus.OrderBy = "SourceID";
        DataTable dtstatus = objstatus.Select();
        ddlsource.DataSource = dtstatus;
        ddlsource.DataTextField = "SourceName";
        ddlsource.DataValueField = "SourceID";
        ddlsource.DataBind();
        ddlsource.Items.Insert(0, "--Select Source--"); 
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {

        int count = 0;
        if (Session["Data"] != null)
        {

            DataSet ds = (DataSet)Session["Data"];
            DataTable dtbl1 = ds.Tables[0];
            for (int i = 0; i < dtbl1.Rows.Count; i++)
            {
                string strLeadName = Convert.ToString(dtbl1.Rows[i]["LeadName"]);
                string strType = Convert.ToString(dtbl1.Rows[i]["Type"]);
                string strEmail1 = Convert.ToString(dtbl1.Rows[i]["Email1"]);
                string strEmail2 = Convert.ToString(dtbl1.Rows[i]["Email2"]);
                string strContact1 = Convert.ToString(dtbl1.Rows[i]["Contact1"]);
                string strContact2 = Convert.ToString(dtbl1.Rows[i]["Contact2"]);
                string strLandline1 = Convert.ToString(dtbl1.Rows[i]["Landline1"]);
                string strLandline2 = Convert.ToString(dtbl1.Rows[i]["Landline2"]);
                string strAddress1 = Convert.ToString(dtbl1.Rows[i]["Address1"]);
                string strAddress2 = Convert.ToString(dtbl1.Rows[i]["Address2"]);
                string strPincode = Convert.ToString(dtbl1.Rows[i]["Pincode"]);
                string strCity = Convert.ToString(dtbl1.Rows[i]["City"]);
                string strState = Convert.ToString(dtbl1.Rows[i]["State"]);
                string strCountry = Convert.ToString(dtbl1.Rows[i]["Country"]);
                //string strdate = ClsProject.GetMMDD_Current(DateTime.Now.ToString());
                int intSourceID = clsPrecaution.GetInt_Zero(ddlsource.SelectedItem.Value);
                string strSourceName = clsPrecaution.GetStr_Empty(ddlsource.SelectedItem.Text);

                tbl_Data obj = new tbl_Data();
                obj.WhereClause = "Contact1= '" + strContact1 + "'";
                DataTable dtd = obj.Select();
                if (dtd.Rows.Count > 0)
                {
                    count++;
                }
                else
                {
                    Hashtable hstbl = new Hashtable();

                    hstbl.Add("LeadName", strLeadName);
                    hstbl.Add("Type", strType);
                    hstbl.Add("Email1", strEmail1);
                    hstbl.Add("Email2", strEmail2);
                    hstbl.Add("Contact1", strContact1);
                    hstbl.Add("Contact2", strContact2);
                    hstbl.Add("Landline1", strLandline1);
                    hstbl.Add("Landline2", strLandline2);
                    hstbl.Add("Address1", strAddress1);
                    hstbl.Add("Address2", strAddress2);
                    hstbl.Add("Pincode", strPincode);
                    hstbl.Add("City", strCity);
                    hstbl.Add("State", strState);
                    hstbl.Add("Country", strCountry);
                    hstbl.Add("SourceID", intSourceID);
                    hstbl.Add("SourceName", strSourceName);
                    hstbl.Add("Flag", 0);

                    tbl_Data objd = new tbl_Data();
                    objd.Data = hstbl;
                    int result = objd.Add();
					string message = "Leads Import Successfully";
					ShowMessage(message);

				}
            }
            if(count>0)
            {
                Response.Write("<script>alert('" + count + " Duplicate records found and not saved')</script>");
            }
            else
            {
                Response.Write("<script>alert('" + count + " Duplicate records found and saved')</script>");
            }
            //Response.Write("<script>alert('" + count + " Duplicate records found and not saved')</script>");
            //Response.Redirect("ImportedData.aspx");
        }
        //Response.Redirect("DealerList.aspx");
    }

	public void ShowMessage(String message)
	{
		System.Text.StringBuilder sb = new System.Text.StringBuilder();

		sb.Append("<script type = 'text/javascript'>");

		sb.Append("window.onload=function(){");

		sb.Append("alert('");

		sb.Append(message);

		sb.Append("')};");

		//sb.Append("window.location.href=UpcomingCalls.aspx");

		sb.Append("</script>");


		ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
	}


	public void BindCountry()
	{
		ClsCountries.BindCountry(ddlCountry);
	}

	public void BindLeadState()
	{
		ClsState.Bindstate(ddlState);

	}

	protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
	{

		int StateId = clsPrecaution.GetInt_Zero(ddlState.SelectedItem.Value);
		ClsCities.BindCity(ddlCity, StateId);

	}

}
