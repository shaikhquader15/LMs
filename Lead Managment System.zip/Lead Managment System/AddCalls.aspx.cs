﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddCalls : System.Web.UI.Page
{
	protected void Page_PreInit(Object sender, EventArgs e)
	{
		ClsProj.GetMasterPage(this);

	}
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!Page.IsPostBack)
		{
			BindLeadState();
			BindCountry();
			//BindCity();

			if (Session["UserID"] != null)
			{
				if (Session["UserType"] != null)
				{
					if (Session["UserName"] != null)
					{
						if (Request.QueryString["LeadID"] != null)
						{

							EditCalls();




						}
					}
				}

			}

			ShowLeadStatus();
			bindUserType();
			BindSource();
			BindLabel();
			BindListView();
			lblUtype.Visible = false;
			lblUuser.Visible = false;
			lblstatus.Visible = true;

			//binduser();
		}
	}

	public void ShowLeadStatus()
	{
		ClsLead.BindLeadStatus(ddlLeadStatus);

	}


	public void bindUserType()
	{

		ClsUser.bindUserType(ddlusertype);
	}




	public void BindSource()
	{

		ClsSource.BindSource(ddlenquiry);
	}


	protected void ddlusertype_SelectedIndexChanged(object sender, EventArgs e)
	{
		int iusertype = clsPrecaution.GetInt_Zero(ddlusertype.SelectedItem.Value);
		ClsUser.binduser(ddluser, iusertype);
	}



	public void EditCalls()
	{

		tbl_Lead obj = new tbl_Lead();
		int LeadID = clsPrecaution.GetInt_Zero(Request.QueryString["LeadID"]);
		obj.WhereClause = "LeadID=" + LeadID;
		DataTable dtlead = obj.Select();
		if (dtlead.Rows.Count > 0)
		{
			ddlusertype.SelectedIndex = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["UserType"]);
			//ddluser.SelectedIndex = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["UserID"]);
			//ddluser.SelectedItem.Text = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["UserName"]);

			txtleadname.Text = clsPrecaution.GetStr_Null(dtlead.Rows[0]["LeadName"]);
			txttype.Text = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Type"]);
			txtemail1.Text = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Email1"]);
			txtemail2.Text = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Email2"]);
			txtcontact1.Text = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Contact1"]);
			txtcontact2.Text = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Contact2"]);
			txtline1.Text = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Landline1"]);
			txtline2.Text = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Landline2"]);
			txtAdd1.Text = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Address1"]);
			txtAdd2.Text = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Address2"]);
			txtPincode.Text = clsPrecaution.GetStr_Null(dtlead.Rows[0]["PinCode"]);
			ddlCountry.SelectedItem.Text = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Country"]);
			ddlState.SelectedItem.Text = clsPrecaution.GetStr_Null(dtlead.Rows[0]["State"]);
			ddlState.SelectedItem.Value = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["StateId"]);
			int StateId = clsPrecaution.GetInt_Zero(ddlState.SelectedItem.Value);
			ClsCities.BindCity(ddlCity, StateId);
			//ddlCity.SelectedItem.Value = clsPrecaution.GetStr_Empty(dtlead.Rows[0]["CityId"]);
			//String strapdate = clsPrecaution.GetStr_Null(dtlead.Rows[0]["AppointmentDate"]);
			//string straptime = clsPrecaution.GetStr_Null(dtlead.Rows[0]["AppointmentTime"]);
			////String strncaldate = clsPrecaution.GetStr_Null(dtlead.Rows[0]["NextCallDate"]);
			////String strncaltime = clsPrecaution.GetStr_Null(dtlead.Rows[0]["NextCallTime"]);
			int intsourceid = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["SourceID"]);
			ddlLeadStatus.SelectedIndex = clsPrecaution.GetInt_Zero(dtlead.Rows[0]["LStatusID"]);

			//String strprod = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Product"]);
			//String stramount = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Amount"]);
			//String straddress = clsPrecaution.GetStr_Null(dtlead.Rows[0]["Address"]);

			
		}



		tbl_ExternalFieldLeadMapping objLM = new tbl_ExternalFieldLeadMapping();
		int LeadMID = clsPrecaution.GetInt_Zero(Request.QueryString["LeadID"]);
		objLM.WhereClause = "LeadID=" + LeadMID;
		DataTable dtMlead = objLM.Select();
		if (dtMlead.Rows.Count > 0)
		{
			//hdExid.Text = clsPrecaution.GetStr_Empty();
			//foreach (ListViewItem itm in ListView2.Items)
			//{
			//	HiddenField hdext = (HiddenField)itm.FindControl("hdExid");
			//	TextBox txtextval = (TextBox)itm.FindControl("txtext");
			//	if (hdext != null)
			//	{
			//		txtextval.Text = clsPrecaution.GetStr_Empty(dtMlead.Rows[0]["FieldValues"]);


			//	}

			//}
		}
		btnSave.Text = "Update";
	}

	




	public void BindLeadState()
	{
		ClsState.Bindstate(ddlState);

	}


	public void BindCountry()
	{
		ClsCountries.BindCountry(ddlCountry);
	}

	//public void BindCity()
	//{
	//	ClsCities.BindCity(ddlCity,);
	//}

	protected void btnSave_Click(object sender, EventArgs e)
	{

		int intusertype = clsPrecaution.GetInt_Zero(Session["UserType"].ToString());
		int intuser = clsPrecaution.GetInt_Zero(Session["UserID"].ToString());
		string struser = clsPrecaution.GetStr_Empty(Session["UserName"].ToString());
		string strshtremark = clsPrecaution.GetStr_Empty(txtsremark.Text);
		string strlongremark = clsPrecaution.GetStr_Empty(txtLRemark.Text);
		//int intusertype = clsPrecaution.GetInt_Zero(ddlusertype.SelectedIndex);
		//int intuser = clsPrecaution.GetInt_Zero(ddluser.SelectedIndex);
		string struname = clsPrecaution.GetStr_Empty(ddluser.SelectedItem);
		string strleadname = clsPrecaution.GetStr_Null(txtleadname.Text);
		string strtype = clsPrecaution.GetStr_Null(txttype.Text);
		int intenquiry = clsPrecaution.GetInt_Zero(ddlenquiry.SelectedItem.Value);
		string strsource = clsPrecaution.GetStr_Empty(ddlenquiry.SelectedItem.Text);
		string stremail = clsPrecaution.GetStr_Null(txtemail1.Text);
		string stremai2 = clsPrecaution.GetStr_Null(txtemail2.Text);
		string strcontact1 = clsPrecaution.GetStr_Null(txtcontact1.Text);
		string strcontact2 = clsPrecaution.GetStr_Null(txtcontact2.Text);
		string strlandline = clsPrecaution.GetStr_Null(txtline1.Text);
		string strlandline2 = clsPrecaution.GetStr_Null(txtline2.Text);
		string stradd1 = clsPrecaution.GetStr_Null(txtAdd1.Text);
		string stradd2 = clsPrecaution.GetStr_Null(txtAdd2.Text);
		string strpincode = clsPrecaution.GetStr_Null(txtPincode.Text);

		string strcity = clsPrecaution.GetStr_Null(ddlCity.SelectedItem.Text);

		string strstate = clsPrecaution.GetStr_Null(ddlState.SelectedItem.Text);
		//int Stateid = clsPrecaution.GetInt_Zero(ddlState.SelectedIndex);
		string strcountry = clsPrecaution.GetStr_Null(ddlCountry.SelectedItem.Text);

		int intstatus = clsPrecaution.GetInt_Zero(ddlLeadStatus.SelectedIndex);
		string strstatusname = clsPrecaution.GetStr_Empty(ddlLeadStatus.SelectedItem.Text);
		string strsourcename = clsPrecaution.GetStr_Empty(ddlenquiry.SelectedItem.Text);
		string strusername = clsPrecaution.GetStr_Empty(ddluser.SelectedItem);
		int StateId = clsPrecaution.GetInt_Zero(ddlState.SelectedItem.Value);
		int CityId = clsPrecaution.GetInt_Zero(ddlCity.SelectedItem.Value);

		//string strfieldvalues = clsPrecaution.GetStr_Empty(txtexternalfield.Text);
		//int intexid = clsPrecaution.GetInt_Zero(lblextfield.Text);

		//int lmid = clsPrecaution.GetInt_Zero(Session["UserID"].ToString());
		//string lmusername = clsPrecaution.GetStr_Empty(Session["UserName"].ToString());
		int leadid = 0;
		if (btnSave.Text == "Save")

		{

			//ClsLead.AddLeads(intuser,0,"", strleadname, strtype, stremail, stremai2, strcontact1, intusertype, strcontact2, strlandline, strlandline2,
			//	stradd1, stradd2, strpincode, strcity, strstate, strcountry, intstatus, "", "", "", "", "", "", "", intenquiry, "", "", "", strstatusname, strsourcename, strusername);

			leadid = ClsLead.AddLeads(intuser, 0, strusername, struser, strleadname, strtype, stremail, stremai2, strcontact1, intusertype, strcontact2, strlandline, strlandline2,
			  stradd1, stradd2, strpincode, strcity, strstate, strcountry, intstatus, strstatusname, "", "", "", "", "", "", "", intenquiry, strsource, "", "", "", StateId, CityId, 0, "", "", 0, strshtremark, strlongremark);
			foreach (ListViewItem itm in ListView2.Items)
			{
				HiddenField hdext = (HiddenField)itm.FindControl("hdExid");
				TextBox txtextval = (TextBox)itm.FindControl("txtext");
				if (hdext != null)
				{

					ClsExternalFieldLeadMapping.AddExternalFieldsLeadMapping(txtextval.Text, int.Parse(hdext.Value), leadid);
				}
			}

			//ClsExternalFieldLeadMapping.AddExternalFieldsLeadMapping(strfieldvalues, intexid, 0);
			Response.Redirect("UpcomingCalls.aspx");
		}

		else
		{
			if (Request.QueryString["LeadID"] != null)
			{
				int id = clsPrecaution.GetInt_Zero(Request.QueryString["LeadID"]);

				//ClsLead.UpdateLeads(id, intuser, strleadname, strtype, stremail, intusertype, stremai2, strcontact1, strcontact2, strlandline, strlandline2,
				//	stradd1, stradd2, strpincode, strcity, strstate, strcountry, intstatus, "", "", "", "", "", "", "", intenquiry, "", "", "", strstatusname, strsourcename, strusername);

				ClsLead.UpdateLeads(id, 0, "", intuser, struser, strleadname, strtype, stremail, intusertype, stremai2, strcontact1, strcontact2, strlandline, strlandline2,
					stradd1, stradd2, strpincode, strcity, strstate, strcountry, intstatus, strstatusname, "", "", "", "", "", "", "", intenquiry, strsourcename, "", "", "", StateId, CityId, 0, "", "", strshtremark, strlongremark);
				foreach (ListViewItem itm in ListView2.Items)
				{
					HiddenField hdext = (HiddenField)itm.FindControl("hdExid");
					TextBox txtextval = (TextBox)itm.FindControl("txtext");
					if (hdext != null)
					{

						ClsExternalFieldLeadMapping.UpdateExternalFieldsLeadMapping(int.Parse(hdext.Value), txtextval.Text, leadid, id);
					}
				}

			}




			Response.Redirect("UpcomingCalls.aspx");

		}


	}



		protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
		{

		}

		protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
		{

			int StateId = clsPrecaution.GetInt_Zero(ddlState.SelectedItem.Value);
			ClsCities.BindCity(ddlCity, StateId);

		}

		//protected void btnSaveImage_Click(object sender, EventArgs e)
		//{
		//	string strexfn = clsPrecaution.GetStr_Empty(txtfield.Text);
		//	ClsExternalFields.AddFields(strexfn);
		//}


		public void BindLabel()
		{
			string strexname = "";
			tbl_ExternalFields obj = new tbl_ExternalFields();
			//obj.WhereClause = "ExternalID=1";
			DataTable dt = obj.Select();
			if (dt.Rows.Count > 0)
			{
				strexname = clsPrecaution.GetStr_Empty(dt.Rows[0]["ExternalFieldName"]);
			}
			//lblextfield.Text = strexname;
		}


		public void BindListView()
		{
			tbl_ExternalFields objextfld = new tbl_ExternalFields();
			//objextfld.WhereClause="ExternalID"
			DataTable dt = objextfld.Select();
			ListView2.DataSource = dt;
			ListView2.DataBind();
		}

		protected void CancelEditRecord(object sender, ListViewCancelEventArgs e)

		{

			ListView1.EditIndex = -1;

			this.BindListView();

		}

		protected void InsertRecord(object sender, ListViewInsertEventArgs e)

		{

			ListViewItem item = e.Item;

			TextBox tF = (TextBox)item.FindControl("txtFName");

			//TextBox tL = (TextBox)item.FindControl("txtLName");

			//TextBox tA = (TextBox)item.FindControl("txtAge");

			Hashtable hstbl = new Hashtable();
			hstbl.Add("ExternalFieldName", tF.Text.Trim());

			tbl_ExternalFieldLeadMapping objfeilds = new tbl_ExternalFieldLeadMapping();
			objfeilds.Data = hstbl;
			objfeilds.Add();



			//DropDownList dropEA = (DropDownList)item.FindControl("dropActive");

			//using (SqlConnection conn = new SqlConnection(_connStr))

			//{

			//	string sql = "Insert Into PersonalDetail (FirstName, LastName, Age, Active) VALUES (" + "@FirstName, @LastName, @Age, @Active)";

			//	using (SqlCommand cmd = new SqlCommand(sql, conn))

			//	{

			//		cmd.Parameters.AddWithValue("@FirstName", tF.Text.Trim());

			//		cmd.Parameters.AddWithValue("@LastName", tL.Text.Trim());

			//		cmd.Parameters.AddWithValue("@Age", tA.Text.Trim());

			//		cmd.Parameters.AddWithValue("@Active", dropEA.SelectedValue);

			//		conn.Open();

			//		cmd.ExecuteNonQuery();

			//		conn.Close();

			//	}

			//}

			lblMessage.Text = "Record inserted successfully !";

			this.BindListView();

		}


		protected void EditRecord(object sender, ListViewEditEventArgs e)

		{

			ListView1.EditIndex = e.NewEditIndex;

			this.BindListView();

		}



		//protected void UpdateRecord(object sender, ListViewUpdateEventArgs e)

		//{

		//	int autoId = int.Parse(ListView1.DataKeys[e.ItemIndex].Value.ToString());

		//	ListViewItem item = ListView1.Items[e.ItemIndex];

		//	TextBox tF = (TextBox)item.FindControl("txtEFName");

		//	TextBox tL = (TextBox)item.FindControl("txtELName");

		//	TextBox tA = (TextBox)item.FindControl("txtEAge");

		//	DropDownList dropEA = (DropDownList)item.FindControl("dropEActive");

		//	using (SqlConnection conn = new SqlConnection(_connStr))

		//	{

		//		string sql = "Update PersonalDetail set FirstName = @FirstName, LastName=@LastName, Age= @Age, Active = @Active" + " where AutoId = @AutoId";

		//		using (SqlCommand cmd = new SqlCommand(sql, conn))

		//		{

		//			cmd.Parameters.AddWithValue("@FirstName", tF.Text.Trim());

		//			cmd.Parameters.AddWithValue("@LastName", tL.Text.Trim());

		//			cmd.Parameters.AddWithValue("@Age", tA.Text.Trim());

		//			cmd.Parameters.AddWithValue("@Active", dropEA.SelectedValue);

		//			cmd.Parameters.AddWithValue("@AutoId", autoId);

		//			conn.Open();

		//			cmd.ExecuteNonQuery();

		//			conn.Close();

		//		}

		//	}

		//	lblMessage.Text = "Record updated successfully !";

		//	ListView1.EditIndex = -1;

		//	// repopulate the data

		//	this.BindListView();

		//}






		protected void DeleteRecord(object sender, ListViewDeleteEventArgs e)

		{

			var autoid = ListView1.DataKeys[e.ItemIndex].Value.ToString();

			tbl_ExternalFields dellead = new tbl_ExternalFields();
			dellead.WhereClause = "ExternalID=" + autoid;
			dellead.Delete();

			//using (SqlConnection conn = new SqlConnection(_connStr))

			//{

			//	string sql = "Delete from PersonalDetail " + " where AutoId = @AutoId";

			//	using (SqlCommand cmd = new SqlCommand(sql, conn))

			//	{

			//		cmd.Parameters.AddWithValue("@AutoId", autoid);

			//		conn.Open();

			//		cmd.ExecuteNonQuery();

			//		conn.Close();

			//	}

			//}

			lblMessage.Text = "Record delete successfully !";

			// repopulate the data

			this.BindListView();

		}
	}