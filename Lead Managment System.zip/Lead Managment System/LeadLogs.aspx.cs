﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class LeadLogs : System.Web.UI.Page
{
	protected void Page_PreInit(Object sender, EventArgs e)
	{
		ClsProj.GetMasterPage(this);

	}
	protected void Page_Load(object sender, EventArgs e)
    {
        if(!Page.IsPostBack)
        {
            ShowLog();
			BindStageDropdown();
			BindNameDetails();
		}
    }


    public void ShowLog()
    {
        int LeadID = clsPrecaution.GetInt_Zero(Request.QueryString["LeadID"]);
        int Leadname = clsPrecaution.GetInt_Zero(Request.QueryString["LeadName"]);

		tbl_LeadLog objLL = new tbl_LeadLog();
        objLL.WhereClause = "LeadID=" + LeadID;
        DataTable dtbl = objLL.Select();
		if (dtbl.Rows.Count > 0)
		{
			int stageid = clsPrecaution.GetInt_Zero(dtbl.Rows[0]["LStageID"]);
			string stagename = clsPrecaution.GetStr_Empty(dtbl.Rows[0]["LStageName"]);
			ListItem ltmitem = ddlStage.Items.FindByValue(stagename);
			if (ltmitem != null)
			{
				ddlStage.ClearSelection();
				ltmitem.Selected = true;
			}
			//if (stagename != "0" || stagename != null || stagename!="")
			//{
			//	ddlStage.ClearSelection();
			//	ListItem lstitm = ddlStage.Items.FindByText(stagename);
			//	lstitm.Selected = true;
			//}
		}
        Gridview1.DataSource = dtbl;
        Gridview1.DataBind();
    }


	public void BindStageDropdown()
	{
		ClsLeadStageMaster.StageDropdown(ddlStage);
	}





	protected void btnUpdate_Click(object sender, EventArgs e)
	{
		int intleadid = clsPrecaution.GetInt_Zero(Request.QueryString["LeadID"]);
		int intStageid = clsPrecaution.GetInt_Zero(ddlStage.SelectedValue);
		string strstagename = clsPrecaution.GetStr_Empty(ddlStage.SelectedItem.Text);
		
		Hashtable hst = new Hashtable();
		hst.Add("LStageID", intStageid);
		hst.Add("LStageName", strstagename);

		tbl_Lead obllead = new tbl_Lead();
		obllead.Data = hst;
		obllead.WhereClause = "LeadID= " + intleadid;
		obllead.Update();

		
			}


	public void BindNameDetails()
	{
		string strLname = "";
		string stremail = "";
		string strcont = "";
		string strSRemark = "";
		string strLRemark = "";

		int userid = clsPrecaution.GetInt_Zero(Request.QueryString["UserID"]);
		int leadid= clsPrecaution.GetInt_Zero(Request.QueryString["LeadID"]);

		tbl_Lead objlead = new tbl_Lead();
		objlead.WhereClause = "LeadID=" + leadid;
		DataTable dt = objlead.Select();
		if (dt.Rows.Count > 0)
		{
			 strLname = clsPrecaution.GetStr_Empty(dt.Rows[0]["LeadName"]);
			 stremail= clsPrecaution.GetStr_Empty(dt.Rows[0]["Email1"]);
			 strcont= clsPrecaution.GetStr_Empty(dt.Rows[0]["Contact1"]);
			strSRemark = clsPrecaution.GetStr_Empty(dt.Rows[0]["ShortRemark"]);
			strLRemark = clsPrecaution.GetStr_Empty(dt.Rows[0]["LongRemark"]);
		}

		lbluname.Text = strLname;
		lblcontact.Text = strcont;
		lblemail.Text = stremail;
		lblSRemark.Text = strSRemark;
		lblLRemark.Text = strLRemark;
	}
}